@echo off
cd /d "%~dp0"

rem ---- Tim Java: PATH -> JAVA_HOME -> cac thu muc cai Java pho bien (khong can them vao PATH)
set "JW="
where javaw >nul 2>nul && set "JW=javaw"
if not defined JW if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javaw.exe" set "JW=%JAVA_HOME%\bin\javaw.exe"
if not defined JW for /d %%D in ("%ProgramFiles%\Java\jdk*" "%ProgramFiles%\Java\jre*" "%ProgramFiles%\Eclipse Adoptium\*" "%ProgramFiles%\Microsoft\jdk*" "%ProgramFiles%\Amazon Corretto\*" "%ProgramFiles%\Zulu\*" "%ProgramFiles%\BellSoft\*" "%ProgramFiles%\OpenJDK\*" "%ProgramFiles(x86)%\Java\jre*") do if exist "%%~D\bin\javaw.exe" set "JW=%%~D\bin\javaw.exe"
if not defined JW (
  echo Khong tim thay Java tren may nay.
  echo.
  echo Hay cai Java 8 tro len, vi du JDK 21 hoac JDK 17 tai https://adoptium.net
  echo roi chay lai file nay. Khong can chinh PATH, file nay tu tim Java.
  pause
  exit /b 1
)
echo Dung Java: %JW%

rem ---- Kiem tra thu vien MySQL: trong thu muc lib hoac cung thu muc voi file nay
set FOUND=0
if exist lib\*.jar set FOUND=1
if exist mysql-connector*.jar set FOUND=1
if "%FOUND%"=="0" (
  echo Chua co thu vien MySQL: hay chep file mysql-connector-java-5.1.49.jar vao CUNG THU MUC voi file nay
  echo hoac vao thu muc con lib roi chay lai.
  pause
  exit /b 1
)

start "" "%JW%" -Dfile.encoding=UTF-8 -jar ChatServer.jar
