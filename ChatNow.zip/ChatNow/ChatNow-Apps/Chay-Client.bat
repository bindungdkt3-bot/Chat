@echo off
cd /d "%~dp0"

rem ---- Tim Java: PATH -> JAVA_HOME -> cac thu muc cai Java pho bien (khong can them vao PATH)
set "JW="
where javaw >nul 2>nul && set "JW=javaw"
if not defined JW if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javaw.exe" set "JW=%JAVA_HOME%\bin\javaw.exe"
if not defined JW for /d %%D in ("%ProgramFiles%\Java\jdk*" "%ProgramFiles%\Java\jre*" "%ProgramFiles%\Eclipse Adoptium\*" "%ProgramFiles%\Microsoft\jdk*" "%ProgramFiles%\Amazon Corretto\*" "%ProgramFiles%\Zulu\*" "%ProgramFiles%\BellSoft\*" "%ProgramFiles%\OpenJDK\*" "%ProgramFiles(x86)%\Java\jre*") do if exist "%%~D\bin\javaw.exe" set "JW=%%~D\bin\javaw.exe"
if not defined JW (
  echo Khong tim thay Java tren may nay.
  echo.
  echo Hay cai Java 8 tro len, vi du JDK 21 hoac JDK 17 tai https://adoptium.net
  echo roi chay lai file nay. Khong can chinh PATH, file nay tu tim Java.
  pause
  exit /b 1
)
echo Dung Java: %JW%

start "" "%JW%" -Dfile.encoding=UTF-8 -jar ChatClient.jar
