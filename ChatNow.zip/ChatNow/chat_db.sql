-- =====================================================================
--  CƠ SỞ DỮ LIỆU CHO PHẦN MỀM CHAT ONLINE (MySQL 8.0+)
--  Chạy trong MySQL Workbench hoặc NetBeans (Services -> Databases)
-- =====================================================================
DROP DATABASE IF EXISTS chat_db;
CREATE DATABASE chat_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE chat_db;

-- ---------------------------------------------------------------------
-- 1. users : tài khoản người dùng
-- ---------------------------------------------------------------------
CREATE TABLE users (
    user_id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username       VARCHAR(20)  NOT NULL,
    password_hash  CHAR(64)     NOT NULL COMMENT 'SHA-256 dạng hex, KHÔNG lưu mật khẩu thô',
    full_name      VARCHAR(100) NOT NULL,
    email          VARCHAR(100) NOT NULL,
    phone          VARCHAR(15)  NULL,
    avatar_url     VARCHAR(255) NULL,
    avatar         MEDIUMBLOB   NULL COMMENT 'ảnh đại diện 128x128 (JPEG); NULL = dùng ảnh mặc định',
    status         ENUM('online','offline','away') NOT NULL DEFAULT 'offline',
    is_active      TINYINT(1)   NOT NULL DEFAULT 1 COMMENT '0 = tài khoản bị khóa/xóa mềm',
    created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login     DATETIME     NULL,
    CONSTRAINT uq_users_username UNIQUE (username),
    CONSTRAINT uq_users_email    UNIQUE (email),
    CONSTRAINT ck_users_username CHECK (username REGEXP '^[A-Za-z0-9_.-]{1,20}$')
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. chat_rooms : phòng chat (nhóm công khai, nhóm riêng tư, chat 1-1)
--    Chat riêng 1-1 được biểu diễn là phòng room_type = 'direct' có đúng 2 thành viên
-- ---------------------------------------------------------------------
CREATE TABLE chat_rooms (
    room_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    room_name    VARCHAR(100) NULL COMMENT 'NULL với phòng direct',
    description  VARCHAR(255) NULL,
    avatar       MEDIUMBLOB   NULL COMMENT 'ảnh nhóm 128x128 (JPEG); NULL = dùng ảnh mặc định',
    room_type    ENUM('public','private','direct') NOT NULL DEFAULT 'public',
    created_by   INT UNSIGNED NOT NULL,
    created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rooms_creator FOREIGN KEY (created_by)
        REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT ck_rooms_name CHECK (room_type = 'direct' OR room_name IS NOT NULL)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 3. room_members : thành viên của phòng (quan hệ N-N giữa users và chat_rooms)
-- ---------------------------------------------------------------------
CREATE TABLE room_members (
    room_id    INT UNSIGNED NOT NULL,
    user_id    INT UNSIGNED NOT NULL,
    role       ENUM('owner','admin','member') NOT NULL DEFAULT 'member',
    is_muted   TINYINT(1)   NOT NULL DEFAULT 0,
    joined_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (room_id, user_id),
    CONSTRAINT fk_members_room FOREIGN KEY (room_id)
        REFERENCES chat_rooms(room_id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_members_user FOREIGN KEY (user_id)
        REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4. messages : tin nhắn
-- ---------------------------------------------------------------------
CREATE TABLE messages (
    message_id    BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    room_id       INT UNSIGNED NOT NULL,
    sender_id     INT UNSIGNED NOT NULL,
    content       TEXT         NULL,
    message_type  ENUM('text','image','file','system') NOT NULL DEFAULT 'text',
    reply_to_id   BIGINT UNSIGNED NULL COMMENT 'trả lời tin nhắn khác (tự tham chiếu)',
    sent_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    edited_at     DATETIME     NULL,
    is_deleted    TINYINT(1)   NOT NULL DEFAULT 0,
    CONSTRAINT fk_msg_room   FOREIGN KEY (room_id)
        REFERENCES chat_rooms(room_id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_msg_sender FOREIGN KEY (sender_id)
        REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_msg_reply  FOREIGN KEY (reply_to_id)
        REFERENCES messages(message_id) ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT ck_msg_content CHECK (message_type <> 'text' OR content IS NOT NULL),
    INDEX idx_msg_room_time (room_id, sent_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 5. message_status : trạng thái đã đọc của từng người nhận
-- ---------------------------------------------------------------------
CREATE TABLE message_status (
    message_id  BIGINT UNSIGNED NOT NULL,
    user_id     INT UNSIGNED    NOT NULL,
    is_read     TINYINT(1)      NOT NULL DEFAULT 0,
    read_at     DATETIME        NULL,
    PRIMARY KEY (message_id, user_id),
    CONSTRAINT fk_status_msg  FOREIGN KEY (message_id)
        REFERENCES messages(message_id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_status_user FOREIGN KEY (user_id)
        REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 6. attachments : file/ảnh đính kèm tin nhắn (1 tin nhắn - nhiều file)
-- ---------------------------------------------------------------------
CREATE TABLE attachments (
    attachment_id  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    message_id     BIGINT UNSIGNED NOT NULL,
    file_name      VARCHAR(255)    NOT NULL,
    file_path      VARCHAR(500)    NOT NULL,
    file_size      BIGINT UNSIGNED NOT NULL,
    mime_type      VARCHAR(100)    NULL,
    uploaded_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_att_msg FOREIGN KEY (message_id)
        REFERENCES messages(message_id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT ck_att_size CHECK (file_size > 0)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 7. friendships : kết bạn / chặn (quan hệ N-N giữa users với chính nó)
--    Không đặt ON DELETE/UPDATE hành động trên cột có CHECK (giới hạn của MySQL);
--    người dùng được "xóa mềm" bằng users.is_active nên không cần xóa cứng.
-- ---------------------------------------------------------------------
CREATE TABLE friendships (
    friendship_id  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id        INT UNSIGNED NOT NULL COMMENT 'người gửi lời mời',
    friend_id      INT UNSIGNED NOT NULL COMMENT 'người nhận lời mời',
    status         ENUM('pending','accepted','blocked') NOT NULL DEFAULT 'pending',
    created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    responded_at   DATETIME     NULL,
    CONSTRAINT fk_fr_user   FOREIGN KEY (user_id)   REFERENCES users(user_id),
    CONSTRAINT fk_fr_friend FOREIGN KEY (friend_id) REFERENCES users(user_id),
    CONSTRAINT uq_fr_pair   UNIQUE (user_id, friend_id),
    CONSTRAINT ck_fr_self   CHECK (user_id <> friend_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 8. login_history : lịch sử đăng nhập (phục vụ bảo mật/thống kê)
-- ---------------------------------------------------------------------
CREATE TABLE login_history (
    log_id       BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    ip_address   VARCHAR(45)  NOT NULL,
    login_time   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    logout_time  DATETIME     NULL,
    success      TINYINT(1)   NOT NULL DEFAULT 1,
    CONSTRAINT fk_login_user FOREIGN KEY (user_id)
        REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT ck_login_time CHECK (logout_time IS NULL OR logout_time >= login_time),
    INDEX idx_login_user (user_id, login_time)
) ENGINE=InnoDB;

-- =====================================================================
--  DỮ LIỆU MẪU
-- =====================================================================
-- password_hash dưới đây là SHA-256 của chuỗi '123456'
INSERT INTO users (username, password_hash, full_name, email, status) VALUES
('an',   '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'Nguyễn Văn An', 'an@example.com',   'online'),
('binh', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'Trần Thị Bình', 'binh@example.com', 'online'),
('chi',  '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'Lê Minh Chi',   'chi@example.com',  'offline');

INSERT INTO chat_rooms (room_name, description, room_type, created_by) VALUES
('Lớp CNTT', 'Phòng chat chung của lớp', 'public', 1),
(NULL, NULL, 'direct', 1);

INSERT INTO room_members (room_id, user_id, role) VALUES
(1, 1, 'owner'), (1, 2, 'member'), (1, 3, 'member'),
(2, 1, 'member'), (2, 2, 'member');

INSERT INTO messages (room_id, sender_id, content) VALUES
(1, 1, 'Chào cả lớp!'),
(1, 2, 'Chào An nhé'),
(2, 1, 'Bình ơi, tối nay học nhóm nhé?');

INSERT INTO message_status (message_id, user_id, is_read, read_at) VALUES
(1, 2, 1, NOW()), (1, 3, 0, NULL), (3, 2, 0, NULL);

INSERT INTO friendships (user_id, friend_id, status) VALUES (1, 2, 'accepted'), (3, 1, 'pending');

-- =====================================================================
--  TRUY VẤN MẪU
-- =====================================================================
-- Lịch sử chat của phòng 1
-- SELECT m.sent_at, u.username, m.content
--   FROM messages m JOIN users u ON u.user_id = m.sender_id
--  WHERE m.room_id = 1 AND m.is_deleted = 0 ORDER BY m.sent_at;

-- Số tin chưa đọc của từng người dùng
-- SELECT user_id, COUNT(*) AS unread FROM message_status WHERE is_read = 0 GROUP BY user_id;

-- Danh sách bạn bè đã chấp nhận của user 1
-- SELECT u.username FROM friendships f
--   JOIN users u ON u.user_id = IF(f.user_id = 1, f.friend_id, f.user_id)
--  WHERE 1 IN (f.user_id, f.friend_id) AND f.status = 'accepted';
