@echo off
rem Tao 2 ung dung .exe (kem san Java, may khac khong can cai Java).
rem Yeu cau: JDK 14 tro len (co jpackage) tren may build. Khong can cai WiX.
cd /d "%~dp0"

rem ---- 1. Tim jpackage: PATH, JAVA_HOME, roi cac thu muc cai JDK pho bien
set "JP="
where jpackage >nul 2>nul && set "JP=jpackage"
if not defined JP if defined JAVA_HOME if exist "%JAVA_HOME%\bin\jpackage.exe" set "JP=%JAVA_HOME%\bin\jpackage.exe"
if not defined JP for /d %%D in ("%ProgramFiles%\Java\jdk*" "%ProgramFiles%\Eclipse Adoptium\jdk*" "%ProgramFiles%\Microsoft\jdk*" "%ProgramFiles%\Amazon Corretto\jdk*" "%ProgramFiles%\Zulu\zulu*" "%ProgramFiles%\BellSoft\LibericaJDK*" "%ProgramFiles%\OpenJDK\jdk*") do if exist "%%~D\bin\jpackage.exe" set "JP=%%~D\bin\jpackage.exe"
if not defined JP (
  echo Khong tim thay jpackage tren may nay.
  echo.
  echo Cach xu ly:
  echo   1. Cai JDK 17 tro len, vi du Temurin tai https://adoptium.net
  echo   2. Chay lai file nay.
  echo.
  echo Neu da cai JDK roi nhung khong tim thay, mo CMD tai thu muc nay va go:
  echo   set "PATH=DUONG_DAN_JDK\bin;%%PATH%%"
  echo   Tao-EXE.bat
  echo.
  echo Luu y: JDK 8 va JDK 11 khong co jpackage. Hai file .jar van chay binh thuong bang cach nhap dup.
  pause
  exit /b 1
)
echo Dung jpackage: %JP%

rem ---- 2. Kiem tra thu vien MySQL
set FOUND=0
if exist lib\*.jar set FOUND=1
if exist mysql-connector*.jar set FOUND=1
if "%FOUND%"=="0" (
  echo Chua co thu vien MySQL: hay chep file mysql-connector-java-5.1.49.jar vao CUNG THU MUC voi file nay
  echo hoac vao thu muc con lib roi chay lai.
  pause
  exit /b 1
)

rem ---- 3. Dong goi
if exist exe rmdir /s /q exe
if exist tmp-server rmdir /s /q tmp-server
if exist tmp-client rmdir /s /q tmp-client

mkdir tmp-server\lib
copy /y ChatServer.jar tmp-server\ >nul
if exist lib\*.jar copy /y lib\*.jar tmp-server\lib\ >nul
if exist mysql-connector*.jar copy /y mysql-connector*.jar tmp-server\lib\ >nul
"%JP%" --type app-image --name ChatServer --input tmp-server --main-jar ChatServer.jar --main-class ServerApp --icon logo.ico --dest exe --java-options "-Dfile.encoding=UTF-8"
if errorlevel 1 goto loi

mkdir tmp-client
copy /y ChatClient.jar tmp-client\ >nul
"%JP%" --type app-image --name ChatClient --input tmp-client --main-jar ChatClient.jar --main-class LoginFrame --icon logo.ico --dest exe --java-options "-Dfile.encoding=UTF-8"
if errorlevel 1 goto loi

rmdir /s /q tmp-server
rmdir /s /q tmp-client
echo.
echo Xong! Mo exe\ChatServer\ChatServer.exe va exe\ChatClient\ChatClient.exe
pause
exit /b 0

:loi
echo.
echo jpackage bao loi o tren. Hay chup man hinh nay gui lai de duoc ho tro.
if exist tmp-server rmdir /s /q tmp-server
if exist tmp-client rmdir /s /q tmp-client
pause
exit /b 1
