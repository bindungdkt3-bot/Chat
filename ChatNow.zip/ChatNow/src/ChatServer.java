import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * ChatServer - động cơ máy chủ chat (không có giao diện, giao diện ở ServerApp).
 *
 * Giao thức: mỗi lệnh một dòng, các trường ngăn cách bằng '|', trường cuối là văn bản tự do.
 *  Client -> Server: LOGIN|user|pass            REGISTER|user|pass|họ tên|email
 *                    ROOMS                      HISTORY|roomId
 *                    MSG|roomId|nội dung        EDIT|msgId|nội dung       DEL|msgId
 *                    SEARCH|roomId(0=tất cả)|từ khóa
 *                    NEWROOM|public/private|tên|mô tả|user1,user2
 *                    DM|username                FINDROOMS|từ khóa         JOINROOM|roomId
 *                    LEAVE|roomId               MEMBERS|roomId            ALLUSERS|từ khóa
 *                    PROFILE|username|họ tên|email|sđt   PASSWD|cũ|mới             QUIT
 *                    AVATAR|ảnh base64  AVRESET  RAVATAR|roomId|ảnh base64  RAVRESET|roomId
 *                    FRIENDS  FSEARCH|từ khóa  FADD|user  FACCEPT|id  FDECLINE|id  FCANCEL|id  FREMOVE|user
 *  Server -> Client: OK|user|họ tên|email|sđt   ERR|lý do    INFO|nội dung   SYS|nội dung
 *                    ROOM|id|type|tên  ROOMSEND  HIST|...  HISTEND|roomId
 *                    MSG|id|roomId|người gửi|giờ|đã sửa|nội dung
 *                    EDITED|id|roomId|nội dung   DELETED|id|roomId
 *                    SRES|id|roomId|tên phòng|người gửi|giờ|nội dung   SEND
 *                    OPEN|roomId  LEFT|roomId  USERS|a,b,c  MEMBERS|roomId|a,b,c
 *                    PROOM|id|tên|mô tả|số thành viên|đã tham gia   PEND
 *                    ULIST|username|họ tên   UEND   PROFILEOK|username|họ tên|email|sđt
 *                    FSTART  FRIEND|user|họ tên  FREQ|id|user|họ tên|giờ  FSENT|id|user|họ tên|giờ  FRIENDSEND
 *                    AV|user|ảnh base64 (rỗng = ảnh mặc định)  RAV|roomId|ảnh base64 (ảnh nhóm)
 *                    FRES|user|họ tên|none/friend/sent/received  FRESEND  NOTI|thông báo
 */
public class ChatServer {

    private ServerSocket serverSocket;
    private volatile boolean running = false;
    private final Map<String, Handler> online = new ConcurrentHashMap<>();
    private Consumer<String> logger = s -> { };
    private Runnable onChange = () -> { };

    public void setLogger(Consumer<String> l) { logger = l; }
    public void setOnChange(Runnable r) { onChange = r; }
    public boolean isRunning() { return running; }
    public List<String> onlineNames() { return new ArrayList<>(new TreeSet<>(online.keySet())); }
    public boolean isOnline(String username) { return online.containsKey(username); }

    private void log(String s) { logger.accept(s); }

    public void start(int port) throws IOException {
        serverSocket = new ServerSocket(port);
        running = true;
        Dao.ensureSchema();
        Dao.resetAllOffline();
        Thread t = new Thread(() -> {
            while (running) {
                try {
                    Socket s = serverSocket.accept();
                    new Thread(new Handler(s), "client-" + s.getPort()).start();
                } catch (IOException e) {
                    if (running) log("Lỗi accept: " + e.getMessage());
                }
            }
        }, "accept-thread");
        t.setDaemon(true);
        t.start();
        log("Server khởi động tại cổng " + port + " - IP máy chủ: " + localIp());
        onChange.run();
    }

    public void stop() {
        running = false;
        for (Handler h : new ArrayList<>(online.values())) {
            h.send("SYS|Máy chủ đã dừng.");
            h.close();
        }
        online.clear();
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException ignored) { }
        Dao.resetAllOffline();
        log("Server đã dừng.");
        onChange.run();
    }

    public static String localIp() {
        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            return "127.0.0.1";
        }
    }

    // ------------------------------------------------------------ gửi tin
    public void sendToUser(String username, String line) {
        Handler h = online.get(username);
        if (h != null) h.send(line);
    }

    public void sendToRoom(long roomId, String line) {
        try {
            for (String u : Dao.memberNames(roomId)) sendToUser(u, line);
        } catch (SQLException e) {
            log("Lỗi CSDL: " + e.getMessage());
        }
    }

    private void broadcastOnline() {
        String line = "USERS|" + String.join(",", onlineNames());
        for (Handler h : online.values()) h.send(line);
        onChange.run();
    }

    // ------------------------------------------------------------ hàm cho giao diện Host
    public void kick(String username, String reason) {
        Handler h = online.get(username);
        if (h != null) {
            h.send("SYS|" + reason);
            h.close();
        }
    }

    /** Gửi thông tin phòng (tên, loại) cho tất cả thành viên đang online. */
    public void pushRoom(long roomId) {
        try {
            byte[] av = Dao.getRoomAvatar(roomId);
            String avLine = av == null ? null : "RAV|" + roomId + "|" + Base64.getEncoder().encodeToString(av);
            for (Object[] m : Dao.memberRows(roomId)) {
                String[] l = Dao.roomLabel(roomId, Dao.lng(m[0]));
                if (l == null) continue;
                sendToUser(Dao.str(m[1]), "ROOM|" + l[0] + "|" + l[1] + "|" + l[2]);
                if (avLine != null) sendToUser(Dao.str(m[1]), avLine);
            }
        } catch (SQLException e) {
            log("Lỗi CSDL: " + e.getMessage());
        }
    }

    public void pushRoomRemoved(long roomId, Collection<String> members) {
        for (String u : members) sendToUser(u, "LEFT|" + roomId);
    }

    /** Gửi lại danh sách bạn bè / lời mời cho người dùng đang online. */
    public void pushFriends(String username) {
        Handler h = online.get(username);
        if (h == null) return;
        try {
            h.sendFriendLists();
        } catch (SQLException e) {
            log("Lỗi CSDL: " + e.getMessage());
        }
    }

    /** Gửi ảnh đại diện hiện tại của một người cho tất cả người đang online (rỗng = ảnh mặc định). */
    public void pushAvatar(String username) {
        try {
            byte[] b = Dao.getAvatar(username);
            String line = "AV|" + username + "|" + (b == null ? "" : Base64.getEncoder().encodeToString(b));
            for (Handler h : online.values()) h.send(line);
        } catch (SQLException e) {
            log("Lỗi CSDL: " + e.getMessage());
        }
    }

    /** Gửi ảnh nhóm hiện tại cho các thành viên đang online (rỗng = ảnh mặc định). */
    public void pushRoomAvatar(long roomId) {
        try {
            byte[] b = Dao.getRoomAvatar(roomId);
            sendToRoom(roomId, "RAV|" + roomId + "|" + (b == null ? "" : Base64.getEncoder().encodeToString(b)));
        } catch (SQLException e) {
            log("Lỗi CSDL: " + e.getMessage());
        }
    }

    /** Xóa ảnh đang lưu ở máy người dùng cho một tên (dùng khi đổi tên đăng nhập). */
    public void clearAvatarFor(String username) {
        for (Handler h : online.values()) h.send("AV|" + username + "|");
    }

    public void pushMessageDeleted(long msgId, long roomId) {
        sendToRoom(roomId, "DELETED|" + msgId + "|" + roomId);
    }

    private static String join(Object[] row) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < row.length; i++) {
            if (i > 0) sb.append('|');
            sb.append(Dao.str(row[i]));
        }
        return sb.toString();
    }

    /** Giải mã base64, kiểm tra là ảnh hợp lệ, cắt vuông 128x128 và nén JPEG. Trả về null nếu ảnh lỗi. */
    private static byte[] normalizeAvatar(String b64) {
        if (b64.length() > 400000) return null;
        try {
            byte[] raw = Base64.getDecoder().decode(b64.trim());
            java.awt.image.BufferedImage img = ImageUtil.fromBytes(raw);
            return img == null ? null : ImageUtil.toJpeg(ImageUtil.squareScale(img, 128), 0.85f);
        } catch (IOException | IllegalArgumentException e) {
            return null;
        }
    }

    // ============================================================ xử lý từng client
    private class Handler implements Runnable {
        private final Socket socket;
        private BufferedReader in;
        private PrintWriter out;
        private long uid = -1;
        private String username;
        private long logId = -1;

        Handler(Socket socket) { this.socket = socket; }

        synchronized void send(String line) {
            if (out != null) out.println(line);
        }

        void close() {
            try {
                socket.close();
            } catch (IOException ignored) { }
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
                if (!authenticate()) return;
                String line;
                while ((line = in.readLine()) != null) {
                    if (line.equals("QUIT")) break;
                    try {
                        handle(line);
                    } catch (SQLException e) {
                        send("ERR|Lỗi CSDL: " + e.getMessage());
                        log("Lỗi CSDL (" + username + "): " + e.getMessage());
                    } catch (NumberFormatException e) {
                        send("ERR|Dữ liệu không hợp lệ");
                    }
                }
            } catch (IOException ignored) {
                // client ngắt kết nối đột ngột
            } finally {
                cleanup();
            }
        }

        private boolean authenticate() throws IOException {
            String line = in.readLine();
            if (line == null) return false;
            String[] p = line.split("\\|", -1);
            Dao.AuthResult r;
            if (p[0].equals("LOGIN") && p.length >= 3) {
                r = Dao.login(p[1].trim(), p[2]);
            } else if (p[0].equals("REGISTER") && p.length >= 5) {
                String err = Dao.register(p[1].trim(), p[2], p[3].trim(), p[4].trim(), p.length >= 6 ? p[5].trim() : "");
                if (err != null) {
                    send("ERR|" + err);
                    return false;
                }
                r = Dao.login(p[1].trim(), p[2]);
                log("Tài khoản mới: " + p[1].trim());
            } else {
                send("ERR|Giao thức không hợp lệ");
                return false;
            }
            if (r.error != null) {
                send("ERR|" + r.error);
                return false;
            }
            synchronized (online) {
                if (online.containsKey(r.username)) {
                    send("ERR|Tài khoản đang đăng nhập ở nơi khác");
                    return false;
                }
                online.put(r.username, this);
            }
            uid = r.id;
            username = r.username;
            send("OK|" + r.username + "|" + r.fullName + "|" + r.email + "|" + r.phone);
            try {
                sendFriendLists();
                for (Object[] av : Dao.allAvatars())
                    send("AV|" + Dao.str(av[0]) + "|" + Base64.getEncoder().encodeToString((byte[]) av[1]));
                for (Object[] av : Dao.roomAvatarsOf(uid))
                    send("RAV|" + av[0] + "|" + Base64.getEncoder().encodeToString((byte[]) av[1]));
            } catch (SQLException ignored) { }
            Dao.setStatus(uid, "online");
            logId = Dao.logLogin(uid, socket.getInetAddress().getHostAddress());
            log(username + " đã đăng nhập từ " + socket.getInetAddress().getHostAddress());
            broadcastOnline();
            return true;
        }

        private void cleanup() {
            if (username != null && online.get(username) == this) {
                online.remove(username);
                Dao.setStatus(uid, "offline");
                Dao.logLogout(logId);
                log(username + " đã thoát.");
                broadcastOnline();
            }
            close();
        }

        private void handle(String line) throws SQLException {
            int i = line.indexOf('|');
            String cmd = i < 0 ? line : line.substring(0, i);
            String rest = i < 0 ? "" : line.substring(i + 1);

            switch (cmd) {
                case "ROOMS": {
                    for (String[] r : Dao.roomsOfUser(uid)) send("ROOM|" + r[0] + "|" + r[1] + "|" + r[2]);
                    send("ROOMSEND");
                    break;
                }
                case "HISTORY": {
                    long room = Long.parseLong(rest.trim());
                    if (!Dao.isMember(room, uid)) { send("ERR|Bạn không thuộc phòng này"); break; }
                    for (Object[] r : Dao.history(room, 200)) send("HIST|" + join(r));
                    send("HISTEND|" + room);
                    break;
                }
                case "MSG": {
                    String[] p = rest.split("\\|", 2);
                    if (p.length < 2) break;
                    long room = Long.parseLong(p[0]);
                    String text = clean(p[1]);
                    if (text.isEmpty()) break;
                    if (!Dao.isMember(room, uid)) { send("ERR|Bạn không thuộc phòng này"); break; }
                    long id = Dao.insertMessage(room, uid, text);
                    Object[] row = Dao.msgRow(id);
                    if (row != null) sendToRoom(room, "MSG|" + join(row));
                    log("[#" + room + "] " + username + ": " + text);
                    break;
                }
                case "EDIT": {
                    String[] p = rest.split("\\|", 2);
                    if (p.length < 2) break;
                    long id = Long.parseLong(p[0]);
                    String text = clean(p[1]);
                    if (text.isEmpty()) break;
                    long room = Dao.editMessage(id, uid, text);
                    if (room < 0) send("ERR|Không thể sửa tin nhắn này");
                    else sendToRoom(room, "EDITED|" + id + "|" + room + "|" + text);
                    break;
                }
                case "DEL": {
                    long id = Long.parseLong(rest.trim());
                    long room = Dao.deleteMessage(id, uid);
                    if (room < 0) send("ERR|Không thể xóa tin nhắn này");
                    else sendToRoom(room, "DELETED|" + id + "|" + room);
                    break;
                }
                case "SEARCH": {
                    String[] p = rest.split("\\|", 2);
                    if (p.length < 2 || p[1].trim().isEmpty()) { send("SEND"); break; }
                    for (Object[] r : Dao.searchMessages(uid, Long.parseLong(p[0]), p[1].trim())) send("SRES|" + join(r));
                    send("SEND");
                    break;
                }
                case "NEWROOM": {
                    String[] p = rest.split("\\|", 4);
                    if (p.length < 4) break;
                    String type = p[0].equals("private") ? "private" : "public";
                    String name = p[1].trim();
                    if (name.isEmpty() || name.length() > 100) { send("ERR|Tên nhóm không hợp lệ"); break; }
                    List<Long> members = new ArrayList<>();
                    for (String u : p[3].split(",")) {
                        if (u.trim().isEmpty()) continue;
                        long id = Dao.userId(u.trim());
                        if (id > 0) members.add(id);
                    }
                    long room = Dao.createRoom(name, p[2].trim(), type, uid, members);
                    pushRoom(room);
                    send("OPEN|" + room);
                    log(username + " tạo nhóm \"" + name + "\"");
                    break;
                }
                case "DM": {
                    long other = Dao.userId(rest.trim());
                    if (other < 0) { send("ERR|Không tìm thấy người dùng"); break; }
                    if (other == uid) { send("ERR|Không thể nhắn cho chính mình"); break; }
                    long room = Dao.getOrCreateDirect(uid, other);
                    pushRoom(room);
                    send("OPEN|" + room);
                    break;
                }
                case "FINDROOMS": {
                    for (Object[] r : Dao.findPublicRooms(rest.trim(), uid)) {
                        send("PROOM|" + r[0] + "|" + Dao.str(r[1]) + "|" + Dao.str(r[2]).replace('|', '/') + "|" + r[3] + "|"
                                + (Dao.bool(r[4]) ? 1 : 0));
                    }
                    send("PEND");
                    break;
                }
                case "JOINROOM": {
                    long room = Long.parseLong(rest.trim());
                    if (!"public".equals(Dao.roomType(room))) { send("ERR|Phòng không tồn tại hoặc không công khai"); break; }
                    Dao.addMember(room, uid);
                    pushRoom(room);
                    send("OPEN|" + room);
                    break;
                }
                case "LEAVE": {
                    long room = Long.parseLong(rest.trim());
                    if ("direct".equals(Dao.roomType(room))) { send("ERR|Không thể rời chat riêng"); break; }
                    Dao.removeMember(room, uid);
                    send("LEFT|" + room);
                    break;
                }
                case "MEMBERS": {
                    long room = Long.parseLong(rest.trim());
                    if (!Dao.isMember(room, uid)) break;
                    send("MEMBERS|" + room + "|" + String.join(",", Dao.memberNames(room)));
                    break;
                }
                case "ALLUSERS": {
                    for (Object[] r : Dao.searchUsers(rest.trim(), username)) send("ULIST|" + Dao.str(r[0]) + "|" + Dao.str(r[1]));
                    send("UEND");
                    break;
                }
                case "PROFILE": {
                    String[] p = rest.split("\\|", -1);
                    if (p.length < 4) break;
                    String newName = p[0].trim();
                    String err = Dao.updateUser(uid, newName, p[1].trim(), p[2].trim(), p[3].trim());
                    if (err != null) { send("ERR|" + err); break; }
                    String oldName = username;
                    if (!newName.equals(oldName)) {
                        synchronized (online) {
                            online.remove(oldName);
                            online.put(newName, this);
                            username = newName;
                        }
                        log(oldName + " đã đổi tên đăng nhập thành " + newName);
                        for (String[] r : Dao.roomsOfUser(uid)) pushRoom(Long.parseLong(r[0]));
                        Set<String> names = new TreeSet<>();
                        names.add(newName);
                        for (Object[] r : Dao.friendsOf(uid)) names.add(Dao.str(r[0]));
                        for (Object[] r : Dao.incomingRequests(uid)) names.add(Dao.str(r[1]));
                        for (Object[] r : Dao.outgoingRequests(uid)) names.add(Dao.str(r[1]));
                        for (String n : names) pushFriends(n);
                        clearAvatarFor(oldName);
                        pushAvatar(newName);
                        broadcastOnline();
                    }
                    send("PROFILEOK|" + newName + "|" + p[1].trim() + "|" + p[2].trim() + "|" + p[3].trim());
                    break;
                }
                case "PASSWD": {
                    String[] p = rest.split("\\|", 2);
                    if (p.length < 2) break;
                    String err = Dao.changePassword(uid, p[0], p[1]);
                    send(err != null ? "ERR|" + err : "INFO|Đã đổi mật khẩu thành công");
                    break;
                }
                case "AVATAR": {
                    if (rest.length() > 400000) { send("ERR|Ảnh quá lớn"); break; }
                    byte[] raw;
                    try {
                        raw = Base64.getDecoder().decode(rest.trim());
                    } catch (IllegalArgumentException e) {
                        send("ERR|Dữ liệu ảnh không hợp lệ");
                        break;
                    }
                    java.awt.image.BufferedImage img = null;
                    byte[] jpg = null;
                    try {
                        img = ImageUtil.fromBytes(raw);
                        if (img != null) jpg = ImageUtil.toJpeg(ImageUtil.squareScale(img, 128), 0.85f);
                    } catch (IOException e) {
                        jpg = null;
                    }
                    if (jpg == null) { send("ERR|Không đọc được ảnh"); break; }
                    Dao.setAvatar(uid, jpg);
                    pushAvatar(username);
                    send("NOTI|Đã cập nhật ảnh đại diện");
                    break;
                }
                case "RAVATAR": {
                    String[] p = rest.split("\\|", 2);
                    if (p.length < 2) break;
                    long room = Long.parseLong(p[0].trim());
                    if (!canEditRoomAvatar(room)) break;
                    byte[] jpg = normalizeAvatar(p[1]);
                    if (jpg == null) { send("ERR|Không đọc được ảnh"); break; }
                    Dao.setRoomAvatar(room, jpg);
                    pushRoomAvatar(room);
                    send("NOTI|Đã cập nhật ảnh nhóm");
                    break;
                }
                case "RAVRESET": {
                    long room = Long.parseLong(rest.trim());
                    if (!canEditRoomAvatar(room)) break;
                    Dao.clearRoomAvatar(room);
                    pushRoomAvatar(room);
                    send("NOTI|Đã đặt lại ảnh nhóm mặc định");
                    break;
                }
                case "AVRESET":
                    Dao.clearAvatar(uid);
                    pushAvatar(username);
                    send("NOTI|Đã đặt lại ảnh đại diện mặc định");
                    break;
                case "FRIENDS":
                    sendFriendLists();
                    break;
                case "FSEARCH": {
                    for (Object[] r : Dao.searchUsersWithRelation(rest.trim(), uid))
                        send("FRES|" + Dao.str(r[0]) + "|" + Dao.str(r[1]) + "|" + Dao.str(r[2]));
                    send("FRESEND");
                    break;
                }
                case "FADD": {
                    String target = rest.trim();
                    long tid = Dao.userId(target);
                    if (tid < 0) { send("ERR|Không tìm thấy người dùng"); break; }
                    String err = Dao.sendFriendRequest(uid, tid);
                    if (err != null) { send("ERR|" + err); break; }
                    send("NOTI|Đã gửi lời mời kết bạn tới " + target);
                    sendToUser(target, "NOTI|" + username + " đã gửi cho bạn lời mời kết bạn");
                    pushFriends(username);
                    pushFriends(target);
                    log(username + " gửi lời mời kết bạn tới " + target);
                    break;
                }
                case "FACCEPT":
                case "FDECLINE": {
                    boolean acc = cmd.equals("FACCEPT");
                    long other = Dao.respondRequest(uid, Long.parseLong(rest.trim()), acc);
                    if (other < 0) {
                        send("ERR|Lời mời không còn hiệu lực");
                        sendFriendLists();
                        break;
                    }
                    String on = Dao.usernameOf(other);
                    send("NOTI|" + (acc ? "Bạn và " + on + " đã trở thành bạn bè" : "Đã từ chối lời mời của " + on));
                    if (acc && on != null) sendToUser(on, "NOTI|" + username + " đã chấp nhận lời mời kết bạn");
                    pushFriends(username);
                    if (on != null) pushFriends(on);
                    if (acc) log(username + " và " + on + " đã trở thành bạn bè");
                    break;
                }
                case "FCANCEL": {
                    long other = Dao.cancelRequest(uid, Long.parseLong(rest.trim()));
                    if (other < 0) { send("ERR|Lời mời không còn hiệu lực"); sendFriendLists(); break; }
                    String on = Dao.usernameOf(other);
                    send("NOTI|Đã thu hồi lời mời kết bạn");
                    pushFriends(username);
                    if (on != null) pushFriends(on);
                    break;
                }
                case "FREMOVE": {
                    String target = rest.trim();
                    long oid = Dao.userId(target);
                    if (oid < 0 || !Dao.unfriend(uid, oid)) { send("ERR|Không thể hủy kết bạn"); break; }
                    send("NOTI|Đã hủy kết bạn với " + target);
                    pushFriends(username);
                    pushFriends(target);
                    break;
                }
                default:
                    send("ERR|Lệnh không hợp lệ: " + cmd);
            }
        }

        void sendFriendLists() throws SQLException {
            send("FSTART");
            for (Object[] r : Dao.friendsOf(uid)) send("FRIEND|" + Dao.str(r[0]) + "|" + Dao.str(r[1]));
            for (Object[] r : Dao.incomingRequests(uid)) send("FREQ|" + join(r));
            for (Object[] r : Dao.outgoingRequests(uid)) send("FSENT|" + join(r));
            send("FRIENDSEND");
        }

        private boolean canEditRoomAvatar(long room) throws SQLException {
            String type = Dao.roomType(room);
            if (type == null || type.equals("direct")) {
                send("ERR|Chat riêng không có ảnh nhóm");
                return false;
            }
            String role = Dao.memberRole(room, uid);
            if (role == null || role.equals("member")) {
                send("ERR|Chỉ chủ nhóm hoặc quản trị viên mới được đổi ảnh nhóm");
                return false;
            }
            return true;
        }

        private String clean(String s) {
            s = s.replace('\r', ' ').replace('\n', ' ').trim();
            return s.length() > 2000 ? s.substring(0, 2000) : s;
        }
    }
}
