import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;

/** ImageUtil - xử lý ảnh đại diện: cắt vuông, thu nhỏ, nén JPEG. Dùng chung cho Client và Server. */
public class ImageUtil {

    /** Cắt vuông ở giữa ảnh rồi thu nhỏ về size x size (nền trắng nếu ảnh có độ trong suốt). */
    public static BufferedImage squareScale(BufferedImage src, int size) {
        int w = src.getWidth(), h = src.getHeight();
        int s = Math.min(w, h);
        BufferedImage cur = src.getSubimage((w - s) / 2, (h - s) / 2, s, s);
        // thu nhỏ từng bước (một nửa mỗi lần) để ảnh mượt hơn
        while (cur.getWidth() / 2 >= size) {
            cur = scale(cur, cur.getWidth() / 2);
        }
        return scale(cur, size);
    }

    private static BufferedImage scale(BufferedImage src, int size) {
        BufferedImage out = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, size, size);
        g.drawImage(src, 0, 0, size, size, null);
        g.dispose();
        return out;
    }

    public static byte[] toJpeg(BufferedImage img, float quality) throws IOException {
        ImageWriter writer = ImageIO.getImageWritersByFormatName("jpeg").next();
        ImageWriteParam param = writer.getDefaultWriteParam();
        param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        param.setCompressionQuality(quality);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ImageOutputStream ios = ImageIO.createImageOutputStream(bos)) {
            writer.setOutput(ios);
            writer.write(null, new IIOImage(img, null, null), param);
        } finally {
            writer.dispose();
        }
        return bos.toByteArray();
    }

    public static BufferedImage fromBytes(byte[] data) throws IOException {
        return ImageIO.read(new ByteArrayInputStream(data));
    }
}
