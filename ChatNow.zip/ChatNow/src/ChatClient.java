import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.Set;
import java.util.Base64;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

/**
 * ChatClient - GIAO DIỆN MÁY NGƯỜI DÙNG (kiểu Messenger / Zalo).
 * Danh sách hội thoại bên trái, khung chat bong bóng ở giữa, người đang online bên phải.
 * Chức năng: gửi / sửa / xóa tin nhắn, tìm kiếm, nhắn riêng, tạo nhóm, tham gia / rời phòng, sửa hồ sơ.
 */
public class ChatClient extends JFrame {

    static class RoomInfo {
        long id;
        String type, name;
        int unread;
        RoomInfo(long id, String type, String name) { this.id = id; this.type = type; this.name = name; }
    }

    // ------------------------------------------------------------ mạng
    private final Socket socket;
    private final BufferedReader in;
    private final PrintWriter out;
    private boolean closing = false;
    private String pendingSys = null;

    // ------------------------------------------------------------ dữ liệu
    private String username;
    private String fullName, email, phone;
    private final Map<Long, RoomInfo> rooms = new LinkedHashMap<>();
    private final Set<String> online = new TreeSet<>();
    private long currentRoom = 0;
    private long editingId = 0;
    private boolean updatingList = false;
    private final Map<Long, BubbleRow> bubbles = new HashMap<>();

    // ------------------------------------------------------------ giao diện
    private final DefaultListModel<RoomInfo> roomModel = new DefaultListModel<>();
    private final JList<RoomInfo> roomList = new JList<>(roomModel);
    private final Theme.RoundField roomSearch = new Theme.RoundField("Tìm cuộc trò chuyện...", 14);
    private final JLabel meAvatar = new JLabel();
    private final JLabel meName = new JLabel();
    private final JLabel meSub = new JLabel();

    private final JLabel headAvatar = new JLabel();
    private final JLabel roomTitle = new JLabel("ChatNow");
    private final JLabel roomSub = new JLabel("Chọn một cuộc trò chuyện ở bên trái");
    private final Theme.RoundButton searchBtn = Theme.lightButton("Tìm tin nhắn");
    private final Theme.RoundButton membersBtn = Theme.lightButton("Thành viên");
    private final Theme.RoundButton leaveBtn = Theme.lightButton("Rời nhóm");
    private final MsgContainer msgBox = new MsgContainer();
    private final JScrollPane msgScroll = new JScrollPane(msgBox);
    private final Theme.RoundField input = new Theme.RoundField("Nhập tin nhắn...", 30);
    private final Theme.RoundButton sendBtn = Theme.primaryButton("Gửi");
    private final JPanel editBanner = new JPanel(new BorderLayout());
    private final JLabel editLabel = new JLabel();

    private final DefaultListModel<String> onlineModel = new DefaultListModel<>();
    private final JList<String> onlineList = new JList<>(onlineModel);
    private final JLabel onlineTitle = new JLabel("Đang online (0)");

    private SearchDialog searchDlg;
    private FindRoomsDialog findDlg;
    private NewChatDialog newDlg;
    private FriendsDialog friendsDlg;

    // ---- bạn bè
    private final List<String[]> friends = new ArrayList<>();     // {username, họ tên}
    private final List<String[]> incoming = new ArrayList<>();    // {id, username, họ tên, giờ}
    private final List<String[]> sentReq = new ArrayList<>();
    private final List<String[]> pFriends = new ArrayList<>();
    private final List<String[]> pIncoming = new ArrayList<>();
    private final List<String[]> pSent = new ArrayList<>();
    private final Theme.RoundButton friendsBtn = Theme.lightButton("Bạn bè");
    private final JPanel notiPanel = new JPanel(new BorderLayout());
    private final JLabel notiLabel = new JLabel();
    private javax.swing.Timer notiTimer;

    public ChatClient(Socket socket, BufferedReader in, PrintWriter out,
                      String username, String fullName, String email, String phone) {
        super("ChatNow - " + fullName);
        this.socket = socket;
        this.in = in;
        this.out = out;
        this.username = username;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setIconImage(Theme.appIcon());
        setSize(1180, 740);
        setMinimumSize(new Dimension(900, 560));
        setLocationRelativeTo(null);

        add(buildLeft(), BorderLayout.WEST);
        add(buildCenter(), BorderLayout.CENTER);
        add(buildRight(), BorderLayout.EAST);
        setChatEnabled(false);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                closing = true;
                send("QUIT");
                try { socket.close(); } catch (IOException ignored) { }
                dispose();
                System.exit(0);
            }
        });

        startReader();
        send("ROOMS");
    }

    // ============================================================ DỰNG GIAO DIỆN
    private JPanel buildLeft() {
        JPanel left = new JPanel(new BorderLayout());
        left.setBackground(Theme.SURFACE);
        left.setPreferredSize(new Dimension(320, 0));
        left.setBorder(new MatteBorder(0, 0, 0, 1, Theme.BORDER));

        meAvatar.setIcon(Theme.avatar(username, fullName, 46));
        meName.setText(fullName);
        meName.setFont(Theme.H2);
        meAvatar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        meAvatar.setToolTipText("Bấm để đổi ảnh đại diện");
        meAvatar.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { showAvatarMenu(meAvatar); }
        });
        meSub.setText("@" + username);
        meSub.setFont(Theme.SMALL);
        meSub.setForeground(Theme.MUTED);
        JPanel meText = new JPanel(new GridLayout(2, 1));
        meText.setOpaque(false);
        meText.add(meName);
        meText.add(meSub);
        JPanel me = new JPanel(new BorderLayout(10, 0));
        me.setOpaque(false);
        me.add(meAvatar, BorderLayout.WEST);
        me.add(meText, BorderLayout.CENTER);

        Theme.RoundButton newChat = Theme.primaryButton("Chat mới");
        Theme.RoundButton explore = Theme.lightButton("Khám phá");
        Theme.RoundButton account = Theme.lightButton("Tài khoản");
        for (Theme.RoundButton b : new Theme.RoundButton[]{newChat, explore, friendsBtn, account}) {
            b.setFont(Theme.BOLD.deriveFont(12f));
            b.setBorder(new EmptyBorder(8, 6, 8, 6));
        }
        JPanel actions = new JPanel(new GridLayout(2, 2, 6, 6));
        actions.setOpaque(false);
        actions.add(newChat);
        actions.add(explore);
        actions.add(friendsBtn);
        actions.add(account);

        JPanel top = new JPanel();
        top.setOpaque(false);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBorder(new EmptyBorder(16, 14, 10, 14));
        for (JComponent c : new JComponent[]{me, actions, roomSearch}) {
            c.setAlignmentX(Component.LEFT_ALIGNMENT);
            top.add(c);
            top.add(Box.createVerticalStrut(10));
        }
        roomSearch.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        left.add(top, BorderLayout.NORTH);

        roomList.setCellRenderer(new RoomRenderer());
        roomList.setFixedCellHeight(64);
        roomList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        roomList.addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || updatingList) return;
            RoomInfo r = roomList.getSelectedValue();
            if (r != null && r.id != currentRoom) openRoom(r.id);
        });
        roomList.setBackground(Theme.SURFACE);
        JScrollPane sp = new JScrollPane(roomList);
        sp.getViewport().setBackground(Theme.SURFACE);
        sp.setBorder(null);
        left.add(sp, BorderLayout.CENTER);

        notiPanel.setBackground(new Color(0xFEF9C3));
        notiPanel.setBorder(new EmptyBorder(8, 14, 8, 14));
        notiLabel.setFont(Theme.SMALL);
        notiLabel.setForeground(new Color(0x713F12));
        notiPanel.add(notiLabel, BorderLayout.CENTER);
        notiPanel.setVisible(false);
        left.add(notiPanel, BorderLayout.SOUTH);

        newChat.addActionListener(e -> openNewChat());
        explore.addActionListener(e -> openFindRooms());
        account.addActionListener(e -> showAccountMenu(account));
        friendsBtn.addActionListener(e -> openFriends());
        roomSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e)  { refreshRoomList(); }
            public void removeUpdate(DocumentEvent e)  { refreshRoomList(); }
            public void changedUpdate(DocumentEvent e) { refreshRoomList(); }
        });
        return left;
    }

    private JPanel buildCenter() {
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(Theme.BG);

        // ---- thanh tiêu đề phòng
        roomTitle.setFont(Theme.H2);
        headAvatar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                RoomInfo r = rooms.get(currentRoom);
                if (r != null && !r.type.equals("direct")) showRoomAvatarMenu(headAvatar);
            }
        });
        roomSub.setFont(Theme.SMALL);
        roomSub.setForeground(Theme.MUTED);
        JPanel titleText = new JPanel(new GridLayout(2, 1));
        titleText.setOpaque(false);
        titleText.add(roomTitle);
        titleText.add(roomSub);
        JPanel titleBox = new JPanel(new BorderLayout(10, 0));
        titleBox.setOpaque(false);
        titleBox.add(headAvatar, BorderLayout.WEST);
        titleBox.add(titleText, BorderLayout.CENTER);
        JPanel headBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 6));
        headBtns.setOpaque(false);
        headBtns.add(searchBtn);
        headBtns.add(membersBtn);
        headBtns.add(leaveBtn);
        JPanel head = new JPanel(new BorderLayout());
        head.setBackground(Theme.SURFACE);
        head.setBorder(new CompoundBorder(new MatteBorder(0, 0, 1, 0, Theme.BORDER), new EmptyBorder(8, 16, 8, 10)));
        head.add(titleBox, BorderLayout.WEST);
        head.add(headBtns, BorderLayout.EAST);
        center.add(head, BorderLayout.NORTH);

        // ---- vùng tin nhắn
        msgScroll.setBorder(null);
        msgScroll.getVerticalScrollBar().setUnitIncrement(18);
        msgScroll.getViewport().setBackground(Theme.BG);
        center.add(msgScroll, BorderLayout.CENTER);

        // ---- thanh nhập
        editBanner.setBackground(new Color(0xFEF3C7));
        editBanner.setBorder(new EmptyBorder(6, 16, 6, 16));
        editLabel.setForeground(new Color(0x92400E));
        JButton cancelEdit = new JButton("Hủy (Esc)");
        cancelEdit.setBorderPainted(false);
        cancelEdit.setContentAreaFilled(false);
        cancelEdit.setForeground(new Color(0x92400E));
        cancelEdit.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        cancelEdit.addActionListener(e -> cancelEdit());
        editBanner.add(editLabel, BorderLayout.CENTER);
        editBanner.add(cancelEdit, BorderLayout.EAST);
        editBanner.setVisible(false);

        Theme.RoundButton emojiBtn = Theme.lightButton("😊");
        emojiBtn.setFont(new Font(Font.DIALOG, Font.PLAIN, 16));
        input.setFont(new Font(Font.DIALOG, Font.PLAIN, 14));
        emojiBtn.setBorder(new EmptyBorder(8, 12, 8, 12));
        JPanel bar = new JPanel(new BorderLayout(8, 0));
        bar.setOpaque(false);
        bar.setBorder(new EmptyBorder(10, 14, 12, 14));
        bar.add(emojiBtn, BorderLayout.WEST);
        bar.add(input, BorderLayout.CENTER);
        bar.add(sendBtn, BorderLayout.EAST);
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(Theme.SURFACE);
        bottom.setBorder(new MatteBorder(1, 0, 0, 0, Theme.BORDER));
        bottom.add(editBanner, BorderLayout.NORTH);
        bottom.add(bar, BorderLayout.CENTER);
        center.add(bottom, BorderLayout.SOUTH);

        sendBtn.addActionListener(e -> sendCurrent());
        input.addActionListener(e -> sendCurrent());
        emojiBtn.addActionListener(e -> showEmojiPopup(emojiBtn));
        searchBtn.addActionListener(e -> openSearch());
        membersBtn.addActionListener(e -> { if (currentRoom != 0) send("MEMBERS|" + currentRoom); });
        leaveBtn.addActionListener(e -> {
            RoomInfo r = rooms.get(currentRoom);
            if (r != null && Theme.confirm(this, "Rời khỏi nhóm \"" + r.name + "\"?")) send("LEAVE|" + currentRoom);
        });
        input.getInputMap().put(KeyStroke.getKeyStroke("ESCAPE"), "cancelEdit");
        input.getActionMap().put("cancelEdit", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { cancelEdit(); }
        });
        return center;
    }

    private JPanel buildRight() {
        JPanel right = new JPanel(new BorderLayout());
        right.setBackground(Theme.SURFACE);
        right.setPreferredSize(new Dimension(210, 0));
        right.setBorder(new MatteBorder(0, 1, 0, 0, Theme.BORDER));
        onlineTitle.setFont(Theme.BOLD);
        onlineTitle.setBorder(new EmptyBorder(16, 14, 4, 14));
        JLabel hint = new JLabel("Nhấp đúp để nhắn riêng");
        hint.setFont(Theme.SMALL);
        hint.setForeground(Theme.MUTED);
        hint.setBorder(new EmptyBorder(0, 14, 8, 14));
        JPanel t = new JPanel(new GridLayout(2, 1));
        t.setOpaque(false);
        t.add(onlineTitle);
        t.add(hint);
        right.add(t, BorderLayout.NORTH);

        onlineList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean sel, boolean foc) {
                super.getListCellRendererComponent(l, v, i, sel, false);
                String n = String.valueOf(v);
                setText("● " + n + (n.equals(username) ? "  (Bạn)" : ""));
                setForeground(Theme.TEXT);
                setIcon(null);
                setBorder(new EmptyBorder(8, 14, 8, 14));
                setBackground(sel ? Theme.SELECT : Theme.SURFACE);
                return this;
            }
        });
        onlineList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    String u = onlineList.getSelectedValue();
                    if (u != null && !u.equals(username)) send("DM|" + u);
                }
            }
        });
        onlineList.setBackground(Theme.SURFACE);
        JScrollPane sp = new JScrollPane(onlineList);
        sp.getViewport().setBackground(Theme.SURFACE);
        sp.setBorder(null);
        right.add(sp, BorderLayout.CENTER);
        return right;
    }

    // ------------------------------------------------------------ thành phần tùy biến
    private static class MsgContainer extends JPanel implements Scrollable {
        MsgContainer() {
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            setBackground(Theme.BG);
            setBorder(new EmptyBorder(10, 6, 10, 6));
        }
        public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 20; }
        public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return 200; }
        public boolean getScrollableTracksViewportWidth() { return true; }
        public boolean getScrollableTracksViewportHeight() {
            return getParent() instanceof JViewport && getParent().getHeight() > getPreferredSize().height;
        }
    }

    private static class Bubble extends JPanel {
        private final boolean mine;
        Bubble(boolean mine) { this.mine = mine; setOpaque(false); }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(mine ? Theme.PRIMARY : Theme.BUBBLE_OTHER);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 22, 22);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private static class Badge extends JLabel {
        Badge() {
            setForeground(Color.WHITE);
            setFont(Theme.SMALL.deriveFont(Font.BOLD));
            setHorizontalAlignment(CENTER);
            setBorder(new EmptyBorder(2, 8, 2, 8));
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Theme.DANGER);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private class RoomRenderer extends JPanel implements ListCellRenderer<RoomInfo> {
        private final JLabel avatar = new JLabel();
        private final JLabel name = new JLabel();
        private final JLabel sub = new JLabel();
        private final Badge badge = new Badge();

        RoomRenderer() {
            setLayout(new BorderLayout(12, 0));
            setBorder(new EmptyBorder(9, 14, 9, 14));
            JPanel text = new JPanel(new GridLayout(2, 1));
            text.setOpaque(false);
            name.setFont(Theme.BOLD);
            sub.setFont(Theme.SMALL);
            text.add(name);
            text.add(sub);
            JPanel east = new JPanel(new GridBagLayout());
            east.setOpaque(false);
            east.add(badge);
            add(avatar, BorderLayout.WEST);
            add(text, BorderLayout.CENTER);
            add(east, BorderLayout.EAST);
        }

        @Override
        public Component getListCellRendererComponent(JList<? extends RoomInfo> l, RoomInfo r, int i, boolean sel, boolean foc) {
            avatar.setIcon(r.type.equals("direct") ? Theme.avatar(r.name, 44) : Theme.roomAvatar(r.id, r.name, 44));
            name.setText(r.name);
            name.setForeground(Theme.TEXT);
            if (r.type.equals("direct")) {
                boolean on = online.contains(r.name);
                sub.setText(on ? "● Đang online" : "Chat riêng");
                sub.setForeground(on ? Theme.SUCCESS : Theme.MUTED);
            } else {
                sub.setText(r.type.equals("public") ? "Nhóm công khai" : "Nhóm riêng tư");
                sub.setForeground(Theme.MUTED);
            }
            badge.setVisible(r.unread > 0);
            badge.setText(r.unread > 99 ? "99+" : String.valueOf(r.unread));
            setBackground(sel ? Theme.SELECT : Theme.SURFACE);
            return this;
        }
    }

    /** Một dòng tin nhắn dạng bong bóng. */
    private class BubbleRow extends JPanel {
        final long id;
        final String sender;
        final String time;
        final boolean mine;
        String content;
        final JLabel textLabel = new JLabel();
        final JLabel timeLabel = new JLabel();

        BubbleRow(long id, String sender, String time, boolean edited, String content, boolean group) {
            this.id = id;
            this.sender = sender;
            this.time = time;
            this.mine = sender.equals(username);
            setOpaque(false);
            setLayout(new BorderLayout());
            setBorder(new EmptyBorder(3, 10, 3, 10));

            Bubble bubble = new Bubble(mine);
            bubble.setLayout(new BoxLayout(bubble, BoxLayout.Y_AXIS));
            bubble.setBorder(new EmptyBorder(8, 14, 6, 14));
            if (!mine && group) {
                JLabel n = new JLabel(sender);
                n.setFont(Theme.SMALL.deriveFont(Font.BOLD));
                n.setForeground(Theme.avatarColor(sender));
                n.setAlignmentX(Component.LEFT_ALIGNMENT);
                bubble.add(n);
                bubble.add(Box.createVerticalStrut(2));
            }
            textLabel.setFont(new Font(Font.DIALOG, Font.PLAIN, 14));
            textLabel.setForeground(mine ? Color.WHITE : Theme.TEXT);
            textLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            timeLabel.setFont(Theme.SMALL.deriveFont(11f));
            timeLabel.setForeground(mine ? new Color(0xDCE8FF) : Theme.MUTED);
            timeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            bubble.add(textLabel);
            bubble.add(Box.createVerticalStrut(2));
            bubble.add(timeLabel);
            setContent(content, edited);

            JPanel holder = new JPanel(new BorderLayout(8, 0));
            holder.setOpaque(false);
            if (!mine) {
                JPanel av = new JPanel(new BorderLayout());
                av.setOpaque(false);
                av.add(new JLabel(Theme.avatar(sender, 32)), BorderLayout.NORTH);
                holder.add(av, BorderLayout.WEST);
            }
            holder.add(bubble, BorderLayout.CENTER);
            add(holder, mine ? BorderLayout.EAST : BorderLayout.WEST);

            bubble.addMouseListener(new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e)  { if (e.isPopupTrigger()) showMenu(e); }
                @Override public void mouseReleased(MouseEvent e) { if (e.isPopupTrigger()) showMenu(e); }
            });
            bubble.setToolTipText(mine ? "Chuột phải để sửa / xóa" : "Chuột phải để sao chép");
        }

        @Override
        public Dimension getMaximumSize() {
            return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
        }

        void setContent(String c, boolean edited) {
            this.content = c;
            FontMetrics fm = textLabel.getFontMetrics(textLabel.getFont());
            int maxW = Math.max(260, (int) (msgScroll.getWidth() * 0.6));
            int w = Math.max(40, Math.min(maxW, fm.stringWidth(c) + 16));
            textLabel.setText("<html><body style='width:" + w + "px'>" + esc(c) + "</body></html>");
            timeLabel.setText(time + (edited ? "  ·  đã sửa" : ""));
        }

        void showMenu(MouseEvent e) {
            JPopupMenu menu = new JPopupMenu();
            JMenuItem copy = new JMenuItem("Sao chép");
            copy.addActionListener(a -> Toolkit.getDefaultToolkit().getSystemClipboard()
                    .setContents(new StringSelection(content), null));
            menu.add(copy);
            if (mine) {
                menu.addSeparator();
                JMenuItem edit = new JMenuItem("Sửa tin nhắn");
                edit.addActionListener(a -> startEdit(id, content));
                JMenuItem del = new JMenuItem("Xóa tin nhắn");
                del.addActionListener(a -> {
                    if (Theme.confirm(ChatClient.this, "Xóa tin nhắn này?")) send("DEL|" + id);
                });
                menu.add(edit);
                menu.add(del);
            }
            menu.show(e.getComponent(), e.getX(), e.getY());
        }
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    // ============================================================ MẠNG
    private void send(String line) {
        out.println(line);
    }

    private void startReader() {
        Thread t = new Thread(() -> {
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    final String l = line;
                    SwingUtilities.invokeLater(() -> handle(l));
                }
            } catch (IOException ignored) { }
            SwingUtilities.invokeLater(this::onDisconnected);
        }, "reader-thread");
        t.setDaemon(true);
        t.start();
    }

    private void onDisconnected() {
        if (closing) return;
        closing = true;
        String msg = pendingSys != null ? pendingSys : "Mất kết nối tới máy chủ.";
        Theme.info(this, msg);
        dispose();
        new LoginFrame().setVisible(true);
    }

    private void logout() {
        closing = true;
        send("QUIT");
        try { socket.close(); } catch (IOException ignored) { }
        dispose();
        new LoginFrame().setVisible(true);
    }

    private void handle(String line) {
        int i = line.indexOf('|');
        String cmd = i < 0 ? line : line.substring(0, i);
        String rest = i < 0 ? "" : line.substring(i + 1);
        try {
            switch (cmd) {
                case "ROOM": {
                    String[] f = rest.split("\\|", 3);
                    long id = Long.parseLong(f[0]);
                    RoomInfo r = rooms.get(id);
                    if (r == null) rooms.put(id, new RoomInfo(id, f[1], f[2]));
                    else { r.type = f[1]; r.name = f[2]; }
                    refreshRoomList();
                    if (id == currentRoom) updateHeader();
                    break;
                }
                case "ROOMSEND":
                    if (currentRoom == 0 && !rooms.isEmpty()) openRoom(rooms.keySet().iterator().next());
                    break;
                case "HIST": {
                    String[] f = rest.split("\\|", 6);
                    if (f.length == 6) addMessage(f, false);
                    break;
                }
                case "HISTEND":
                    scrollBottom();
                    break;
                case "MSG": {
                    String[] f = rest.split("\\|", 6);
                    if (f.length == 6) addMessage(f, true);
                    break;
                }
                case "EDITED": {
                    String[] f = rest.split("\\|", 3);
                    BubbleRow b = bubbles.get(Long.parseLong(f[0]));
                    if (b != null) {
                        b.setContent(f[2], true);
                        msgBox.revalidate();
                        msgBox.repaint();
                    }
                    break;
                }
                case "DELETED": {
                    String[] f = rest.split("\\|", 2);
                    BubbleRow b = bubbles.remove(Long.parseLong(f[0]));
                    if (b != null) {
                        msgBox.remove(b);
                        msgBox.revalidate();
                        msgBox.repaint();
                    }
                    break;
                }
                case "SRES":
                    if (searchDlg != null) searchDlg.addResult(rest.split("\\|", 6));
                    break;
                case "SEND":
                    if (searchDlg != null) searchDlg.finish();
                    break;
                case "OPEN":
                    openRoom(Long.parseLong(rest.trim()));
                    break;
                case "LEFT": {
                    long id = Long.parseLong(rest.trim());
                    rooms.remove(id);
                    if (id == currentRoom) {
                        currentRoom = 0;
                        clearMessages();
                        cancelEdit();
                        updateHeader();
                    }
                    refreshRoomList();
                    if (currentRoom == 0 && !rooms.isEmpty()) openRoom(rooms.keySet().iterator().next());
                    break;
                }
                case "USERS": {
                    online.clear();
                    onlineModel.clear();
                    for (String u : rest.split(",")) {
                        if (!u.isEmpty()) {
                            online.add(u);
                            onlineModel.addElement(u);
                        }
                    }
                    onlineTitle.setText("Đang online (" + online.size() + ")");
                    if (friendsDlg != null) friendsDlg.refresh(false);
                    roomList.repaint();
                    updateHeader();
                    break;
                }
                case "MEMBERS": {
                    String[] f = rest.split("\\|", 2);
                    if (f.length == 2) showMembers(f[1].split(","));
                    break;
                }
                case "PROOM":
                    if (findDlg != null) findDlg.addRoom(rest.split("\\|", 5));
                    break;
                case "ULIST": {
                    String[] f = rest.split("\\|", 2);
                    if (newDlg != null && f.length == 2) newDlg.addUser(f[0], f[1]);
                    break;
                }
                case "UEND":
                    if (newDlg != null) newDlg.finish();
                    break;
                case "PROFILEOK": {
                    String[] f = rest.split("\\|", -1);
                    username = f[0];
                    fullName = f[1];
                    email = f[2];
                    phone = f[3];
                    meName.setText(fullName);
                    meSub.setText("@" + username);
                    meAvatar.setIcon(Theme.avatar(username, fullName, 46));
                    setTitle("ChatNow - " + fullName);
                    Theme.info(this, "Đã cập nhật hồ sơ.");
                    break;
                }
                case "AV": {
                    String[] f = rest.split("\\|", 2);
                    if (f[0].isEmpty()) break;
                    if (f.length < 2 || f[1].isEmpty()) {
                        Theme.AVATARS.remove(f[0]);
                    } else {
                        try {
                            BufferedImage img = ImageIO.read(new ByteArrayInputStream(Base64.getDecoder().decode(f[1])));
                            if (img != null) Theme.AVATARS.put(f[0], img);
                        } catch (IOException | IllegalArgumentException e) {
                            // bỏ qua ảnh lỗi
                        }
                    }
                    getContentPane().repaint();
                    break;
                }
                case "RAV": {
                    String[] f = rest.split("\\|", 2);
                    if (f[0].isEmpty()) break;
                    String key = "#" + f[0];
                    if (f.length < 2 || f[1].isEmpty()) {
                        Theme.AVATARS.remove(key);
                    } else {
                        try {
                            BufferedImage img = ImageIO.read(new ByteArrayInputStream(Base64.getDecoder().decode(f[1])));
                            if (img != null) Theme.AVATARS.put(key, img);
                        } catch (IOException | IllegalArgumentException e) {
                            // bỏ qua ảnh lỗi
                        }
                    }
                    getContentPane().repaint();
                    break;
                }
                case "FSTART":
                    pFriends.clear();
                    pIncoming.clear();
                    pSent.clear();
                    break;
                case "FRIEND":
                    pFriends.add(rest.split("\\|", 2));
                    break;
                case "FREQ":
                    pIncoming.add(rest.split("\\|", 4));
                    break;
                case "FSENT":
                    pSent.add(rest.split("\\|", 4));
                    break;
                case "FRIENDSEND":
                    friends.clear();
                    friends.addAll(pFriends);
                    incoming.clear();
                    incoming.addAll(pIncoming);
                    sentReq.clear();
                    sentReq.addAll(pSent);
                    friendsBtn.setText(incoming.isEmpty() ? "Bạn bè" : "Bạn bè (" + incoming.size() + ")");
                    if (friendsDlg != null) friendsDlg.refresh(true);
                    break;
                case "FRES":
                    if (friendsDlg != null) friendsDlg.addResult(rest.split("\\|", 3));
                    break;
                case "NOTI":
                    notifyUser(rest);
                    break;
                case "INFO":
                    Theme.info(this, rest);
                    break;
                case "SYS":
                    pendingSys = rest;
                    break;
                case "ERR":
                    Theme.error(this, rest);
                    break;
                default:
                    break;
            }
        } catch (RuntimeException ex) {
            // bỏ qua dòng dữ liệu lỗi, không làm treo giao diện
        }
    }

    // ============================================================ HỘI THOẠI
    private void refreshRoomList() {
        String f = roomSearch.getText().trim().toLowerCase();
        updatingList = true;
        roomModel.clear();
        for (RoomInfo r : rooms.values()) {
            if (f.isEmpty() || r.name.toLowerCase().contains(f)) roomModel.addElement(r);
        }
        for (int i = 0; i < roomModel.size(); i++) {
            if (roomModel.get(i).id == currentRoom) roomList.setSelectedIndex(i);
        }
        updatingList = false;
    }

    private void openRoom(long id) {
        RoomInfo r = rooms.get(id);
        if (r == null) return;
        currentRoom = id;
        r.unread = 0;
        cancelEdit();
        clearMessages();
        updateHeader();
        refreshRoomList();
        send("HISTORY|" + id);
        input.requestFocusInWindow();
    }

    private void clearMessages() {
        msgBox.removeAll();
        msgBox.add(Box.createVerticalGlue());
        bubbles.clear();
        msgBox.revalidate();
        msgBox.repaint();
    }

    private void setChatEnabled(boolean on) {
        input.setEnabled(on);
        sendBtn.setEnabled(on);
        searchBtn.setEnabled(on);
        membersBtn.setEnabled(on);
        leaveBtn.setEnabled(on);
    }

    private void updateHeader() {
        RoomInfo r = rooms.get(currentRoom);
        if (r == null) {
            roomTitle.setText("ChatNow");
            roomSub.setText("Chọn một cuộc trò chuyện ở bên trái");
            headAvatar.setIcon(null);
            setChatEnabled(false);
            return;
        }
        setChatEnabled(true);
        roomTitle.setText(r.name);
        headAvatar.setIcon(r.type.equals("direct") ? Theme.avatar(r.name, 40) : Theme.roomAvatar(r.id, r.name, 40));
        boolean group = !r.type.equals("direct");
        headAvatar.setToolTipText(group ? "Bấm để đổi ảnh nhóm" : null);
        headAvatar.setCursor(Cursor.getPredefinedCursor(group ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
        if (r.type.equals("direct")) {
            roomSub.setText(online.contains(r.name) ? "● Đang online" : "Ngoại tuyến");
            roomSub.setForeground(online.contains(r.name) ? Theme.SUCCESS : Theme.MUTED);
        } else {
            roomSub.setText(r.type.equals("public") ? "Nhóm công khai" : "Nhóm riêng tư");
            roomSub.setForeground(Theme.MUTED);
        }
        leaveBtn.setVisible(!r.type.equals("direct"));
        membersBtn.setVisible(!r.type.equals("direct"));
    }

    private void addMessage(String[] f, boolean live) {
        long id = Long.parseLong(f[0]);
        long room = Long.parseLong(f[1]);
        String sender = f[2];
        if (room != currentRoom) {
            if (live) {
                RoomInfo r = rooms.get(room);
                if (r == null) {
                    send("ROOMS");
                } else {
                    r.unread++;
                    refreshRoomList();
                    if (!sender.equals(username)) Toolkit.getDefaultToolkit().beep();
                }
            }
            return;
        }
        if (bubbles.containsKey(id)) return;
        RoomInfo ri = rooms.get(room);
        boolean group = ri != null && !ri.type.equals("direct");
        BubbleRow row = new BubbleRow(id, sender, f[3], "1".equals(f[4]), f[5], group);
        bubbles.put(id, row);
        msgBox.add(row);
        msgBox.revalidate();
        if (live) scrollBottom();
    }

    private void scrollBottom() {
        javax.swing.Timer t = new javax.swing.Timer(60, e -> {
            msgBox.revalidate();
            JScrollBar sb = msgScroll.getVerticalScrollBar();
            sb.setValue(sb.getMaximum());
        });
        t.setRepeats(false);
        t.start();
    }

    // ============================================================ GỬI / SỬA TIN
    private void sendCurrent() {
        String t = input.getText().trim();
        if (t.isEmpty() || currentRoom == 0) return;
        if (editingId != 0) send("EDIT|" + editingId + "|" + t);
        else send("MSG|" + currentRoom + "|" + t);
        cancelEdit();
    }

    private void startEdit(long id, String content) {
        editingId = id;
        editLabel.setText("Đang sửa tin nhắn: " + (content.length() > 60 ? content.substring(0, 60) + "..." : content));
        editBanner.setVisible(true);
        input.setText(content);
        input.requestFocusInWindow();
        input.setCaretPosition(content.length());
    }

    private void cancelEdit() {
        editingId = 0;
        editBanner.setVisible(false);
        input.setText("");
    }

    private void showEmojiPopup(Component anchor) {
        String[] emojis = {"😀", "😁", "😂", "🤣", "😊", "😍", "😘", "😎", "🤔", "😢", "😭", "😡",
                "👍", "👎", "👏", "🙏", "💪", "🎉", "❤", "🔥", "✨", "💯", "😴", "🤝"};
        JPopupMenu pop = new JPopupMenu();
        JPanel grid = new JPanel(new GridLayout(0, 6, 2, 2));
        grid.setBorder(new EmptyBorder(6, 6, 6, 6));
        for (String e : emojis) {
            JButton b = new JButton(e);
            b.setFont(new Font(Font.DIALOG, Font.PLAIN, 20));
            b.setBorderPainted(false);
            b.setContentAreaFilled(false);
            b.setFocusPainted(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.addActionListener(a -> {
                input.replaceSelection(e);
                pop.setVisible(false);
                input.requestFocusInWindow();
            });
            grid.add(b);
        }
        pop.add(grid);
        pop.show(anchor, 0, -pop.getPreferredSize().height - 4);
    }

    // ============================================================ TÀI KHOẢN
    private void showAccountMenu(Component anchor) {
        JPopupMenu m = new JPopupMenu();
        JMenuItem profile = new JMenuItem("Sửa hồ sơ");
        JMenuItem pass = new JMenuItem("Đổi mật khẩu");
        JMenuItem logout = new JMenuItem("Đăng xuất");
        profile.addActionListener(e -> {
            String[] v = Theme.form(this, "Hồ sơ cá nhân",
                    new String[]{"Tên đăng nhập", "Họ tên", "Email", "Số điện thoại"},
                    new String[]{username, fullName, email, phone}, null);
            if (v == null) return;
            if (!v[0].matches("[A-Za-z0-9_.-]{1,20}")) {
                Theme.error(this, "Tên đăng nhập chỉ gồm chữ không dấu, số, _ . - (tối đa 20 ký tự).");
                return;
            }
            send("PROFILE|" + v[0] + "|" + v[1] + "|" + v[2] + "|" + v[3]);
        });
        pass.addActionListener(e -> {
            String[] v = Theme.form(this, "Đổi mật khẩu",
                    new String[]{"Mật khẩu hiện tại", "Mật khẩu mới", "Nhập lại mật khẩu mới"}, null,
                    new boolean[]{true, true, true});
            if (v == null) return;
            if (!v[1].equals(v[2])) {
                Theme.error(this, "Mật khẩu nhập lại không khớp.");
                return;
            }
            send("PASSWD|" + v[0] + "|" + v[1]);
        });
        logout.addActionListener(e -> logout());
        JMenuItem themeItem = new JMenuItem(Theme.dark ? "Chuyển sang giao diện sáng" : "Chuyển sang giao diện tối");
        themeItem.addActionListener(e -> Theme.toggleDark());
        m.add(profile);
        m.add(pass);
        m.add(themeItem);
        m.addSeparator();
        m.add(logout);
        m.show(anchor, 0, anchor.getHeight());
    }

    private void showMembers(String[] names) {
        DefaultListModel<String> model = new DefaultListModel<>();
        for (String n : names) if (!n.isEmpty()) model.addElement(n);
        JList<String> list = new JList<>(model);
        list.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean sel, boolean foc) {
                super.getListCellRendererComponent(l, v, i, sel, false);
                String n = String.valueOf(v);
                setIcon(Theme.avatar(n, 28));
                setText("  " + n + (online.contains(n) ? "   ● online" : ""));
                setForeground(online.contains(n) ? Theme.SUCCESS : Theme.TEXT);
                setBorder(new EmptyBorder(4, 8, 4, 8));
                return this;
            }
        });
        JScrollPane sp = new JScrollPane(list);
        sp.setPreferredSize(new Dimension(300, 280));
        int r = JOptionPane.showOptionDialog(this, sp, "Thành viên (" + model.size() + ")",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null,
                new String[]{"Nhắn riêng", "Đóng"}, "Đóng");
        if (r == 0 && list.getSelectedValue() != null && !list.getSelectedValue().equals(username))
            send("DM|" + list.getSelectedValue());
    }

    // ============================================================ HỘP THOẠI PHỤ
    private void openSearch() {
        if (searchDlg == null) searchDlg = new SearchDialog();
        searchDlg.setVisible(true);
        searchDlg.toFront();
    }

    private void openFindRooms() {
        if (findDlg == null) findDlg = new FindRoomsDialog();
        findDlg.setVisible(true);
        findDlg.request();
    }

    private void openNewChat() {
        if (newDlg == null) newDlg = new NewChatDialog();
        newDlg.setVisible(true);
        newDlg.request();
    }

    private JPanel dialogRoot() {
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.setBorder(new EmptyBorder(14, 14, 14, 14));
        p.setBackground(Theme.SURFACE);
        return p;
    }

    /** Tìm tin nhắn trong phòng hiện tại hoặc tất cả phòng. */
    private class SearchDialog extends JDialog {
        final Theme.RoundField kw = new Theme.RoundField("Nhập từ khóa cần tìm...", 22);
        final JCheckBox all = new JCheckBox("Tìm trong tất cả cuộc trò chuyện");
        final DefaultTableModel model = new DefaultTableModel(new String[]{"Phòng", "Người gửi", "Thời gian", "Nội dung"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        final JTable table = new JTable(model);
        final List<Long> roomIds = new ArrayList<>();
        final JLabel status = new JLabel(" ");

        SearchDialog() {
            super(ChatClient.this, "Tìm kiếm tin nhắn", false);
            setSize(640, 460);
            setLocationRelativeTo(ChatClient.this);
            setDefaultCloseOperation(HIDE_ON_CLOSE);
            Theme.styleTable(table);
            table.setAutoCreateRowSorter(false);
            table.getColumnModel().getColumn(3).setPreferredWidth(300);
            JPanel top = new JPanel(new BorderLayout(8, 6));
            top.setOpaque(false);
            Theme.RoundButton go = Theme.primaryButton("Tìm");
            top.add(kw, BorderLayout.CENTER);
            top.add(go, BorderLayout.EAST);
            all.setOpaque(false);
            top.add(all, BorderLayout.SOUTH);
            JPanel root = dialogRoot();
            root.add(top, BorderLayout.NORTH);
            root.add(Theme.scroll(table), BorderLayout.CENTER);
            status.setForeground(Theme.MUTED);
            JPanel st = new JPanel(new BorderLayout());
            st.setOpaque(false);
            st.add(status, BorderLayout.WEST);
            JLabel tip = new JLabel("Nhấp đúp vào kết quả để mở cuộc trò chuyện");
            tip.setForeground(Theme.MUTED);
            tip.setFont(Theme.SMALL);
            st.add(tip, BorderLayout.EAST);
            root.add(st, BorderLayout.SOUTH);
            setContentPane(root);
            go.addActionListener(e -> search());
            kw.addActionListener(e -> search());
            table.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int r = table.getSelectedRow();
                    if (e.getClickCount() == 2 && r >= 0 && r < roomIds.size()) {
                        openRoom(roomIds.get(r));
                        setVisible(false);
                    }
                }
            });
        }

        void search() {
            String k = kw.getText().trim();
            if (k.isEmpty()) return;
            model.setRowCount(0);
            roomIds.clear();
            status.setText("Đang tìm...");
            send("SEARCH|" + (all.isSelected() ? 0 : currentRoom) + "|" + k);
        }

        void addResult(String[] f) {
            if (f.length < 6) return;
            roomIds.add(Long.parseLong(f[1]));
            model.addRow(new Object[]{f[2], f[3], f[4], f[5]});
        }

        void finish() {
            status.setText("Tìm thấy " + model.getRowCount() + " tin nhắn");
        }
    }

    /** Khám phá và tham gia các phòng công khai. */
    private class FindRoomsDialog extends JDialog {
        final Theme.RoundField kw = new Theme.RoundField("Tìm phòng công khai theo tên...", 22);
        final DefaultTableModel model = new DefaultTableModel(new String[]{"Tên phòng", "Mô tả", "Thành viên", "Trạng thái"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        final JTable table = new JTable(model);
        final List<Long> ids = new ArrayList<>();
        final List<Boolean> joined = new ArrayList<>();

        FindRoomsDialog() {
            super(ChatClient.this, "Khám phá phòng công khai", false);
            setSize(620, 440);
            setLocationRelativeTo(ChatClient.this);
            setDefaultCloseOperation(HIDE_ON_CLOSE);
            Theme.styleTable(table);
            table.setAutoCreateRowSorter(false);
            Theme.RoundButton join = Theme.successButton("Tham gia phòng đã chọn");
            JPanel root = dialogRoot();
            root.add(kw, BorderLayout.NORTH);
            root.add(Theme.scroll(table), BorderLayout.CENTER);
            root.add(join, BorderLayout.SOUTH);
            setContentPane(root);
            kw.getDocument().addDocumentListener(new DocumentListener() {
                public void insertUpdate(DocumentEvent e)  { request(); }
                public void removeUpdate(DocumentEvent e)  { request(); }
                public void changedUpdate(DocumentEvent e) { request(); }
            });
            join.addActionListener(e -> {
                int r = table.getSelectedRow();
                if (r < 0 || r >= ids.size()) {
                    Theme.info(this, "Hãy chọn một phòng.");
                    return;
                }
                if (joined.get(r)) {
                    openRoom(ids.get(r));
                } else {
                    send("JOINROOM|" + ids.get(r));
                }
                setVisible(false);
            });
        }

        void request() {
            model.setRowCount(0);
            ids.clear();
            joined.clear();
            send("FINDROOMS|" + kw.getText().trim());
        }

        void addRoom(String[] f) {
            if (f.length < 5) return;
            ids.add(Long.parseLong(f[0]));
            boolean j = "1".equals(f[4]);
            joined.add(j);
            model.addRow(new Object[]{f[1], f[2], f[3], j ? "Đã tham gia" : "Chưa tham gia"});
        }
    }

    /** Tạo chat riêng hoặc nhóm mới. */
    private class NewChatDialog extends JDialog {
        final Theme.RoundField kw = new Theme.RoundField("Tìm người dùng theo tên...", 22);
        final Theme.RoundField groupName = new Theme.RoundField("Tên nhóm (chỉ cần khi tạo nhóm)", 22);
        final JComboBox<String> type = new JComboBox<>(new String[]{"Nhóm công khai", "Nhóm riêng tư"});
        final DefaultListModel<String> model = new DefaultListModel<>();
        final JList<String> list = new JList<>(model);
        final List<String> names = new ArrayList<>();
        final List<String> pendingNames = new ArrayList<>();
        final List<String> pendingLabels = new ArrayList<>();

        NewChatDialog() {
            super(ChatClient.this, "Cuộc trò chuyện mới", false);
            setSize(440, 560);
            setLocationRelativeTo(ChatClient.this);
            setDefaultCloseOperation(HIDE_ON_CLOSE);
            list.setCellRenderer(new DefaultListCellRenderer() {
                @Override
                public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean sel, boolean foc) {
                    super.getListCellRendererComponent(l, v, i, sel, false);
                    String n = i < names.size() ? names.get(i) : "?";
                    setIcon(Theme.avatar(n, 30));
                    setText("  " + v);
                    setBorder(new EmptyBorder(5, 8, 5, 8));
                    setBackground(sel ? Theme.SELECT : Theme.SURFACE);
                    return this;
                }
            });
            JLabel hint = new JLabel("Giữ Ctrl để chọn nhiều người khi tạo nhóm");
            hint.setFont(Theme.SMALL);
            hint.setForeground(Theme.MUTED);
            JPanel top = new JPanel(new BorderLayout(0, 4));
            top.setOpaque(false);
            top.add(kw, BorderLayout.CENTER);
            top.add(hint, BorderLayout.SOUTH);

            JPanel bottom = new JPanel(new GridLayout(0, 1, 0, 8));
            bottom.setOpaque(false);
            bottom.add(groupName);
            bottom.add(type);
            Theme.RoundButton dm = Theme.primaryButton("Nhắn riêng với người đã chọn");
            Theme.RoundButton grp = Theme.successButton("Tạo nhóm với những người đã chọn");
            bottom.add(dm);
            bottom.add(grp);

            JPanel root = dialogRoot();
            root.add(top, BorderLayout.NORTH);
            root.add(Theme.scroll(list), BorderLayout.CENTER);
            root.add(bottom, BorderLayout.SOUTH);
            setContentPane(root);

            kw.getDocument().addDocumentListener(new DocumentListener() {
                public void insertUpdate(DocumentEvent e)  { request(); }
                public void removeUpdate(DocumentEvent e)  { request(); }
                public void changedUpdate(DocumentEvent e) { request(); }
            });
            dm.addActionListener(e -> {
                int[] sel = list.getSelectedIndices();
                if (sel.length != 1) {
                    Theme.info(this, "Hãy chọn đúng một người để nhắn riêng.");
                    return;
                }
                send("DM|" + names.get(sel[0]));
                setVisible(false);
            });
            grp.addActionListener(e -> {
                int[] sel = list.getSelectedIndices();
                String gn = groupName.getText().trim();
                if (gn.isEmpty() || gn.contains("|")) {
                    Theme.info(this, "Hãy nhập tên nhóm hợp lệ (không chứa dấu |).");
                    return;
                }
                if (sel.length == 0) {
                    Theme.info(this, "Hãy chọn ít nhất một thành viên.");
                    return;
                }
                StringBuilder sb = new StringBuilder();
                for (int i : sel) {
                    if (sb.length() > 0) sb.append(',');
                    sb.append(names.get(i));
                }
                String t = type.getSelectedIndex() == 0 ? "public" : "private";
                send("NEWROOM|" + t + "|" + gn + "||" + sb);
                groupName.setText("");
                setVisible(false);
            });
        }

        void request() {
            send("ALLUSERS|" + kw.getText().trim());
        }

        void addUser(String u, String full) {
            pendingNames.add(u);
            pendingLabels.add(u + "   —   " + full);
        }

        void finish() {
            names.clear();
            names.addAll(pendingNames);
            model.clear();
            for (String s : pendingLabels) model.addElement(s);
            pendingNames.clear();
            pendingLabels.clear();
        }
    }

    // ============================================================ ẢNH ĐẠI DIỆN
    private void showAvatarMenu(Component anchor) {
        JPopupMenu m = new JPopupMenu();
        JMenuItem change = new JMenuItem("Đổi ảnh đại diện...");
        JMenuItem reset = new JMenuItem("Đặt lại ảnh mặc định");
        change.addActionListener(e -> chooseAvatar("AVATAR|"));
        reset.addActionListener(e -> {
            if (!Theme.AVATARS.containsKey(username)) {
                Theme.info(this, "Bạn đang dùng ảnh mặc định rồi.");
            } else if (Theme.confirm(this, "Đặt lại ảnh đại diện về mặc định?")) {
                send("AVRESET");
            }
        });
        m.add(change);
        m.add(reset);
        m.show(anchor, 0, anchor.getHeight());
    }

    private void showRoomAvatarMenu(Component anchor) {
        final long room = currentRoom;
        JPopupMenu m = new JPopupMenu();
        JMenuItem change = new JMenuItem("Đổi ảnh nhóm...");
        JMenuItem reset = new JMenuItem("Đặt lại ảnh nhóm mặc định");
        change.addActionListener(e -> chooseAvatar("RAVATAR|" + room + "|"));
        reset.addActionListener(e -> {
            if (!Theme.AVATARS.containsKey("#" + room)) {
                Theme.info(this, "Nhóm này đang dùng ảnh mặc định rồi.");
            } else if (Theme.confirm(this, "Đặt lại ảnh nhóm về mặc định?")) {
                send("RAVRESET|" + room);
            }
        });
        m.add(change);
        m.add(reset);
        m.show(anchor, 0, anchor.getHeight());
    }

    /** Chọn ảnh từ máy, xem trước rồi gửi lên server với tiền tố lệnh (AVATAR| hoặc RAVATAR|id|). */
    private void chooseAvatar(String commandPrefix) {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Chọn ảnh đại diện");
        fc.setFileFilter(new FileNameExtensionFilter("Ảnh (png, jpg, jpeg, gif, bmp)", "png", "jpg", "jpeg", "gif", "bmp"));
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try {
            BufferedImage img = ImageIO.read(fc.getSelectedFile());
            if (img == null) {
                Theme.error(this, "Không đọc được ảnh. Hãy chọn file png, jpg, gif hoặc bmp.");
                return;
            }
            BufferedImage sq = ImageUtil.squareScale(img, 128);
            JPanel p = new JPanel(new BorderLayout(0, 10));
            p.setBorder(new EmptyBorder(8, 20, 4, 20));
            JLabel preview = new JLabel(Theme.imageIcon(sq, 120), SwingConstants.CENTER);
            JLabel ask = new JLabel("Dùng ảnh này làm ảnh " + (commandPrefix.startsWith("R") ? "nhóm" : "đại diện") + "?", SwingConstants.CENTER);
            p.add(preview, BorderLayout.CENTER);
            p.add(ask, BorderLayout.SOUTH);
            if (JOptionPane.showConfirmDialog(this, p, "Xem trước ảnh đại diện", JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE) != JOptionPane.OK_OPTION) return;
            send(commandPrefix + Base64.getEncoder().encodeToString(ImageUtil.toJpeg(sq, 0.85f)));
        } catch (IOException ex) {
            Theme.error(this, "Không đọc được ảnh: " + ex.getMessage());
        }
    }

    // ============================================================ BẠN BÈ
    private static DefaultTableModel ro(String... cols) {
        return new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
    }

    private static String relText(String rel) {
        switch (rel) {
            case "friend": return "Bạn bè";
            case "sent": return "Đã gửi lời mời";
            case "received": return "Đã nhận lời mời";
            default: return "Chưa kết bạn";
        }
    }

    private void openFriends() {
        if (friendsDlg == null) friendsDlg = new FriendsDialog();
        friendsDlg.setVisible(true);
        friendsDlg.toFront();
        friendsDlg.refresh(true);
        send("FRIENDS");
    }

    private void notifyUser(String msg) {
        notiLabel.setText("<html>" + esc(msg) + "</html>");
        notiPanel.setVisible(true);
        Toolkit.getDefaultToolkit().beep();
        if (notiTimer != null) notiTimer.stop();
        notiTimer = new javax.swing.Timer(7000, e -> notiPanel.setVisible(false));
        notiTimer.setRepeats(false);
        notiTimer.start();
        if (notiPanel.getParent() != null) notiPanel.getParent().revalidate();
    }

    /** Quản lý bạn bè: danh sách bạn, lời mời đã nhận / đã gửi, tìm và kết bạn. */
    private class FriendsDialog extends JDialog {
        final DefaultTableModel friendModel = ro("Tên đăng nhập", "Họ tên", "Trạng thái");
        final DefaultTableModel inModel = ro("Tên đăng nhập", "Họ tên", "Thời gian");
        final DefaultTableModel outModel = ro("Tên đăng nhập", "Họ tên", "Thời gian");
        final DefaultTableModel resModel = ro("Tên đăng nhập", "Họ tên", "Quan hệ");
        final JTable friendTable = new JTable(friendModel);
        final JTable inTable = new JTable(inModel);
        final JTable outTable = new JTable(outModel);
        final JTable resTable = new JTable(resModel);
        final List<String> resUsers = new ArrayList<>();
        final List<String> resRel = new ArrayList<>();
        final Theme.RoundField kw = new Theme.RoundField("Tìm người để kết bạn theo tên...", 22);
        final JTabbedPane tabs = new JTabbedPane();

        FriendsDialog() {
            super(ChatClient.this, "Bạn bè", false);
            setSize(660, 540);
            setLocationRelativeTo(ChatClient.this);
            setDefaultCloseOperation(HIDE_ON_CLOSE);
            for (JTable t : new JTable[]{friendTable, inTable, outTable, resTable}) {
                Theme.styleTable(t);
                t.setAutoCreateRowSorter(false);
            }

            // ---- tab 1: danh sách bạn bè
            Theme.RoundButton dm = Theme.primaryButton("Nhắn tin");
            Theme.RoundButton unf = Theme.dangerButton("Hủy kết bạn");
            JPanel p1 = dialogRoot();
            p1.add(Theme.scroll(friendTable), BorderLayout.CENTER);
            p1.add(buttons(dm, unf), BorderLayout.SOUTH);

            // ---- tab 2: lời mời
            Theme.RoundButton acc = Theme.successButton("Chấp nhận");
            Theme.RoundButton dec = Theme.dangerButton("Từ chối");
            Theme.RoundButton cancel = Theme.lightButton("Thu hồi lời mời");
            JPanel top = new JPanel(new BorderLayout(0, 6));
            top.setOpaque(false);
            JLabel l1 = new JLabel("Lời mời đã nhận");
            l1.setFont(Theme.BOLD);
            top.add(l1, BorderLayout.NORTH);
            top.add(Theme.scroll(inTable), BorderLayout.CENTER);
            top.add(buttons(acc, dec), BorderLayout.SOUTH);
            JPanel bot = new JPanel(new BorderLayout(0, 6));
            bot.setOpaque(false);
            JLabel l2 = new JLabel("Lời mời đã gửi (đang chờ phản hồi)");
            l2.setFont(Theme.BOLD);
            bot.add(l2, BorderLayout.NORTH);
            bot.add(Theme.scroll(outTable), BorderLayout.CENTER);
            bot.add(buttons(cancel), BorderLayout.SOUTH);
            JPanel p2 = dialogRoot();
            JPanel both = new JPanel(new GridLayout(2, 1, 0, 12));
            both.setOpaque(false);
            both.add(top);
            both.add(bot);
            p2.add(both, BorderLayout.CENTER);

            // ---- tab 3: thêm bạn
            Theme.RoundButton add = Theme.primaryButton("Gửi lời mời kết bạn");
            JPanel p3 = dialogRoot();
            p3.add(kw, BorderLayout.NORTH);
            p3.add(Theme.scroll(resTable), BorderLayout.CENTER);
            p3.add(buttons(add), BorderLayout.SOUTH);

            tabs.addTab("Bạn bè", p1);
            tabs.addTab("Lời mời", p2);
            tabs.addTab("Thêm bạn", p3);
            setContentPane(tabs);

            dm.addActionListener(e -> messageFriend());
            unf.addActionListener(e -> {
                int r = pick(friendTable);
                if (r < 0) return;
                String n = friends.get(r)[0];
                if (Theme.confirm(this, "Hủy kết bạn với \"" + n + "\"?")) send("FREMOVE|" + n);
            });
            acc.addActionListener(e -> {
                int r = pick(inTable);
                if (r >= 0) send("FACCEPT|" + incoming.get(r)[0]);
            });
            dec.addActionListener(e -> {
                int r = pick(inTable);
                if (r >= 0) send("FDECLINE|" + incoming.get(r)[0]);
            });
            cancel.addActionListener(e -> {
                int r = pick(outTable);
                if (r >= 0) send("FCANCEL|" + sentReq.get(r)[0]);
            });
            add.addActionListener(e -> {
                int r = pick(resTable);
                if (r < 0) return;
                if (!resRel.get(r).equals("none")) {
                    Theme.info(this, "Trạng thái hiện tại: " + relText(resRel.get(r)) + ".");
                    return;
                }
                send("FADD|" + resUsers.get(r));
            });
            friendTable.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2) messageFriend();
                }
            });
            kw.getDocument().addDocumentListener(new DocumentListener() {
                public void insertUpdate(DocumentEvent e)  { requestSearch(); }
                public void removeUpdate(DocumentEvent e)  { requestSearch(); }
                public void changedUpdate(DocumentEvent e) { requestSearch(); }
            });
        }

        private JPanel buttons(JComponent... bs) {
            JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
            p.setOpaque(false);
            for (JComponent b : bs) p.add(b);
            return p;
        }

        private int pick(JTable t) {
            int r = t.getSelectedRow();
            if (r < 0) Theme.info(this, "Hãy chọn một dòng trong bảng.");
            return r;
        }

        private void messageFriend() {
            int r = friendTable.getSelectedRow();
            if (r < 0 || r >= friends.size()) {
                Theme.info(this, "Hãy chọn một người bạn.");
                return;
            }
            send("DM|" + friends.get(r)[0]);
            setVisible(false);
        }

        void refresh(boolean search) {
            friendModel.setRowCount(0);
            for (String[] f : friends) friendModel.addRow(new Object[]{f[0], f[1], online.contains(f[0]) ? "● Online" : "Offline"});
            inModel.setRowCount(0);
            for (String[] f : incoming) inModel.addRow(new Object[]{f[1], f[2], f[3]});
            outModel.setRowCount(0);
            for (String[] f : sentReq) outModel.addRow(new Object[]{f[1], f[2], f[3]});
            tabs.setTitleAt(0, "Bạn bè (" + friends.size() + ")");
            tabs.setTitleAt(1, "Lời mời (" + incoming.size() + ")");
            if (search && isVisible()) requestSearch();
        }

        void requestSearch() {
            resModel.setRowCount(0);
            resUsers.clear();
            resRel.clear();
            send("FSEARCH|" + kw.getText().trim());
        }

        void addResult(String[] f) {
            if (f.length < 3) return;
            resUsers.add(f[0]);
            resRel.add(f[2]);
            resModel.addRow(new Object[]{f[0], f[1], relText(f[2])});
        }
    }

    public static void main(String[] args) {
        Theme.init();
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
