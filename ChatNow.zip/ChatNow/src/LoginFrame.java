import java.awt.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/** LoginFrame - màn hình đăng nhập / đăng ký của máy người dùng. */
public class LoginFrame extends JFrame {

    static String lastHost = "localhost";
    static String lastPort = "5000";

    private final CardLayout cards = new CardLayout();
    private final JPanel formArea = new JPanel(cards);

    private final Theme.RoundField lUser = new Theme.RoundField("Tên đăng nhập", 20);
    private final Theme.RoundPassword lPass = new Theme.RoundPassword("Mật khẩu", 20);
    private final Theme.RoundField rUser = new Theme.RoundField("Tên đăng nhập (chữ không dấu, số)", 20);
    private final Theme.RoundField rFull = new Theme.RoundField("Họ và tên", 20);
    private final Theme.RoundField rEmail = new Theme.RoundField("Email", 20);
    private final Theme.RoundField rPhone = new Theme.RoundField("Số điện thoại (không bắt buộc)", 20);
    private final JCheckBox showLogin = new JCheckBox("Hiện mật khẩu");
    private final JCheckBox showReg = new JCheckBox("Hiện mật khẩu");
    private final Theme.RoundPassword rPass = new Theme.RoundPassword("Mật khẩu (tối thiểu 4 ký tự)", 20);
    private final Theme.RoundPassword rPass2 = new Theme.RoundPassword("Nhập lại mật khẩu", 20);
    private final Theme.RoundField hostF = new Theme.RoundField("IP máy chủ", 12);
    private final Theme.RoundField portF = new Theme.RoundField("Cổng", 5);
    private final JLabel lMsg = msgLabel();
    private final JLabel rMsg = msgLabel();
    private final Theme.RoundButton loginBtn = Theme.primaryButton("Đăng nhập");
    private final Theme.RoundButton regBtn = Theme.primaryButton("Tạo tài khoản");

    public LoginFrame() {
        super("ChatNow - Đăng nhập");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setIconImage(Theme.appIcon());
        setSize(440, 600);
        setResizable(false);
        setLocationRelativeTo(null);

        hostF.setText(lastHost);
        showLogin.setOpaque(false);
        showReg.setOpaque(false);
        showLogin.addActionListener(e -> lPass.setEchoChar(showLogin.isSelected() ? (char) 0 : '\u2022'));
        showReg.addActionListener(e -> {
            char c = showReg.isSelected() ? (char) 0 : '\u2022';
            rPass.setEchoChar(c);
            rPass2.setEchoChar(c);
        });
        portF.setText(lastPort);

        // ---- tiêu đề có màu nền
        JPanel header = new JPanel(new GridLayout(2, 1)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, Theme.PRIMARY, getWidth(), getHeight(), new Color(0x9B51E0)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        header.setPreferredSize(new Dimension(0, 110));
        header.setBorder(new EmptyBorder(22, 0, 8, 0));
        JLabel logo = new JLabel("ChatNow", Theme.logoIcon(46), SwingConstants.CENTER);
        logo.setIconTextGap(12);
        logo.setFont(Theme.TITLE.deriveFont(30f));
        logo.setForeground(Color.WHITE);
        JLabel slogan = new JLabel("Kết nối mọi người, trò chuyện mọi lúc", SwingConstants.CENTER);
        slogan.setForeground(new Color(0xE0E7FF));
        header.add(logo);
        header.add(slogan);

        formArea.setOpaque(false);
        formArea.add(buildLogin(), "login");
        formArea.add(buildRegister(), "register");

        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(Theme.BG);
        center.setBorder(new EmptyBorder(18, 26, 6, 26));
        JPanel card = Theme.card();
        card.setLayout(new BorderLayout());
        card.add(formArea, BorderLayout.CENTER);
        center.add(card, BorderLayout.CENTER);

        JPanel server = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 8));
        server.setBackground(Theme.BG);
        JLabel sl = new JLabel("Máy chủ:");
        sl.setForeground(Theme.MUTED);
        server.add(sl);
        server.add(hostF);
        server.add(portF);
        final JButton[] themeBtn = new JButton[1];
        themeBtn[0] = linkButton(themeLabel(), () -> {
            Theme.toggleDark();
            themeBtn[0].setText(themeLabel());
        });
        server.add(themeBtn[0]);
        JPanel south = new JPanel(new BorderLayout());
        south.setBackground(Theme.BG);
        south.setBorder(new EmptyBorder(0, 26, 12, 26));
        south.add(server, BorderLayout.CENTER);

        add(header, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);

        loginBtn.addActionListener(e -> submit(false));
        regBtn.addActionListener(e -> submit(true));

        // Nhấn Enter: chuyển sang ô kế tiếp; ở ô cuối thì gửi form
        lUser.addActionListener(e -> lPass.requestFocusInWindow());
        lPass.addActionListener(e -> submit(false));
        rUser.addActionListener(e -> rFull.requestFocusInWindow());
        rFull.addActionListener(e -> rEmail.requestFocusInWindow());
        rEmail.addActionListener(e -> rPhone.requestFocusInWindow());
        rPhone.addActionListener(e -> rPass.requestFocusInWindow());
        rPass.addActionListener(e -> rPass2.requestFocusInWindow());
        rPass2.addActionListener(e -> submit(true));
        getRootPane().setDefaultButton(loginBtn);
        SwingUtilities.invokeLater(() -> lUser.requestFocusInWindow());
    }

    /** Biểu tượng bong bóng chat vẽ bằng code (không phụ thuộc font emoji). */
    private static class BubbleIcon implements Icon {
        private final int size;
        BubbleIcon(int size) { this.size = size; }
        @Override public int getIconWidth() { return size; }
        @Override public int getIconHeight() { return size; }
        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.WHITE);
            int h = size * 3 / 4;
            g2.fillRoundRect(x, y, size, h, size / 2, size / 2);
            int[] px = {x + size / 5, x + size / 5 + size / 5, x + size / 10};
            int[] py = {y + h - 2, y + h - 2, y + size};
            g2.fillPolygon(px, py, 3);
            g2.setColor(Theme.PRIMARY);
            int d = size / 8;
            for (int i = 0; i < 3; i++) g2.fillOval(x + size / 4 + i * (size / 4) - d / 2, y + h / 2 - d / 2, d, d);
            g2.dispose();
        }
    }

    private static String themeLabel() {
        return Theme.dark ? "Chế độ sáng" : "Chế độ tối";
    }

    private static JLabel msgLabel() {
        JLabel l = new JLabel(" ");
        l.setForeground(Theme.DANGER);
        l.setFont(Theme.SMALL);
        return l;
    }

    private JPanel column() {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        return p;
    }

    private void addRow(JPanel p, JComponent c) {
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, c.getPreferredSize().height + 4));
        p.add(c);
        p.add(Box.createVerticalStrut(10));
    }

    private JButton linkButton(String text, Runnable r) {
        JButton b = new JButton(text);
        b.setBorderPainted(false);
        b.setContentAreaFilled(false);
        b.setFocusPainted(false);
        b.setForeground(Theme.PRIMARY);
        b.setFont(Theme.BOLD);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e -> r.run());
        return b;
    }

    private JPanel buildLogin() {
        JPanel p = column();
        JLabel t = new JLabel("Chào mừng trở lại");
        t.setFont(Theme.H2.deriveFont(20f));
        addRow(p, t);
        addRow(p, lUser);
        addRow(p, lPass);
        addRow(p, showLogin);
        addRow(p, lMsg);
        addRow(p, loginBtn);
        JPanel sw = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        sw.setOpaque(false);
        sw.add(new JLabel("Chưa có tài khoản?"));
        sw.add(linkButton("Đăng ký ngay", () -> { cards.show(formArea, "register"); setTitle("ChatNow - Đăng ký"); setSize(440, 750); getRootPane().setDefaultButton(regBtn); rUser.requestFocusInWindow(); }));
        addRow(p, sw);
        return p;
    }

    private JPanel buildRegister() {
        JPanel p = column();
        JLabel t = new JLabel("Tạo tài khoản mới");
        t.setFont(Theme.H2.deriveFont(20f));
        addRow(p, t);
        addRow(p, rUser);
        addRow(p, rFull);
        addRow(p, rEmail);
        addRow(p, rPhone);
        addRow(p, rPass);
        addRow(p, rPass2);
        addRow(p, showReg);
        addRow(p, rMsg);
        addRow(p, regBtn);
        JPanel sw = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        sw.setOpaque(false);
        sw.add(new JLabel("Đã có tài khoản?"));
        sw.add(linkButton("Đăng nhập", () -> { cards.show(formArea, "login"); setTitle("ChatNow - Đăng nhập"); setSize(440, 600); getRootPane().setDefaultButton(loginBtn); lUser.requestFocusInWindow(); }));
        addRow(p, sw);
        return p;
    }

    private void fail(boolean register, String msg) {
        (register ? rMsg : lMsg).setForeground(Theme.DANGER);
        (register ? rMsg : lMsg).setText("<html>" + msg + "</html>");
        loginBtn.setEnabled(true);
        regBtn.setEnabled(true);
    }

    private void submit(boolean register) {
        final String host = hostF.getText().trim();
        final int port;
        try {
            port = Integer.parseInt(portF.getText().trim());
        } catch (NumberFormatException ex) {
            fail(register, "Cổng không hợp lệ");
            return;
        }
        final String cmd;
        if (register) {
            String u = rUser.getText().trim(), fn = rFull.getText().trim();
            String em = rEmail.getText().trim(), ph = rPhone.getText().trim();
            String pw = new String(rPass.getPassword());
            String err = null;
            if (u.isEmpty() || fn.isEmpty() || em.isEmpty() || pw.isEmpty()) err = "Vui lòng điền đầy đủ các mục bắt buộc";
            else if (!u.matches("[A-Za-z0-9_.-]{1,20}")) err = "Tên đăng nhập chỉ gồm chữ không dấu, số, _ . - (tối đa 20 ký tự)";
            else if (fn.length() > 100 || fn.contains("|")) err = "Họ tên không hợp lệ (không chứa dấu |)";
            else if (!em.matches("^[^@\\s|]+@[^@\\s|]+\\.[^@\\s|]+$")) err = "Email không hợp lệ (ví dụ: ten@gmail.com)";
            else if (!ph.isEmpty() && !ph.matches("[0-9+ ]{8,15}")) err = "Số điện thoại không hợp lệ (8-15 chữ số)";
            else if (pw.length() < 4 || pw.length() > 50) err = "Mật khẩu phải từ 4 đến 50 ký tự";
            else if (pw.contains("|")) err = "Mật khẩu không được chứa dấu |";
            else if (!pw.equals(new String(rPass2.getPassword()))) err = "Mật khẩu nhập lại không khớp";
            if (err != null) {
                fail(true, err);
                return;
            }
            cmd = "REGISTER|" + u + "|" + pw + "|" + fn + "|" + em + "|" + ph;
        } else {
            if (lUser.getText().trim().isEmpty() || lPass.getPassword().length == 0) {
                fail(false, "Vui lòng nhập tên đăng nhập và mật khẩu");
                return;
            }
            cmd = "LOGIN|" + lUser.getText().trim() + "|" + new String(lPass.getPassword());
        }
        lMsg.setText(" ");
        rMsg.setText(" ");
        loginBtn.setEnabled(false);
        regBtn.setEnabled(false);
        (register ? rMsg : lMsg).setForeground(Theme.MUTED);
        (register ? rMsg : lMsg).setText("Đang kết nối...");

        new Thread(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(host, port), 5000);
                s.setSoTimeout(10000);
                BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                PrintWriter out = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8), true);
                out.println(cmd);
                String reply = in.readLine();
                if (reply == null) throw new IOException("Máy chủ đóng kết nối");
                if (reply.startsWith("OK|")) {
                    s.setSoTimeout(0);
                    final String[] f = reply.split("\\|", 5);
                    lastHost = host;
                    lastPort = String.valueOf(port);
                    SwingUtilities.invokeLater(() -> {
                        new ChatClient(s, in, out, f[1], f[2], f[3], f.length > 4 ? f[4] : "").setVisible(true);
                        dispose();
                    });
                } else {
                    s.close();
                    final String err = reply.startsWith("ERR|") ? reply.substring(4) : reply;
                    SwingUtilities.invokeLater(() -> {
                        (register ? rMsg : lMsg).setForeground(Theme.DANGER);
                        fail(register, err);
                    });
                }
            } catch (IOException ex) {
                SwingUtilities.invokeLater(() -> {
                    (register ? rMsg : lMsg).setForeground(Theme.DANGER);
                    fail(register, "Không kết nối được máy chủ: " + ex.getMessage());
                });
            }
        }, "login-thread").start();
    }

    public static void main(String[] args) {
        Theme.init();
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
