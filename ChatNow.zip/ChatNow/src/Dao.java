import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.*;
import java.util.*;

/** Dao - toàn bộ thao tác với cơ sở dữ liệu chat_db (JDBC + MySQL). */
public class Dao {

    // ------------------------------------------------------------ Cấu hình kết nối
    public static String url = "jdbc:mysql://localhost:3306/chat_db?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Ho_Chi_Minh";
    public static String dbUser = "root";
    public static String dbPass = "";

    // ------------------------------------------------------------ nạp JDBC driver khi chạy bằng file .jar
    static {
        loadDriversFromLib();
    }

    /**
     * Khi chạy bằng ChatServer.jar (không qua NetBeans), tự tìm file mysql-connector (.jar) trong thư mục
     * "lib" cạnh file .jar (hoặc cạnh thư mục chạy) rồi đăng ký driver. Nếu driver đã có sẵn trong classpath
     * (chạy trong NetBeans) thì không làm gì.
     */
    private static void loadDriversFromLib() {
        String[] names = {"com.mysql.cj.jdbc.Driver", "com.mysql.jdbc.Driver", "org.mariadb.jdbc.Driver"};
        for (String n : names) {
            try {
                Class.forName(n);
                return;
            } catch (Throwable ignored) { }
        }
        List<URL> urls = new ArrayList<>();
        try {
            File here = new File(Dao.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            File base = here.isFile() ? here.getParentFile() : here;
            collectJars(new File(base, "lib"), urls);
            collectJars(base, urls);
        } catch (Exception ignored) { }
        collectJars(new File("lib"), urls);
        collectJars(new File("."), urls);
        if (urls.isEmpty()) return;
        URLClassLoader loader = new URLClassLoader(urls.toArray(new URL[0]), Dao.class.getClassLoader());
        for (String n : names) {
            try {
                Driver d = (Driver) Class.forName(n, true, loader).getDeclaredConstructor().newInstance();
                DriverManager.registerDriver(new DriverShim(d));
                return;
            } catch (Throwable ignored) { }
        }
    }

    private static void collectJars(File dir, List<URL> out) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            try {
                if (f.isFile() && f.getName().toLowerCase().endsWith(".jar") && !out.contains(f.toURI().toURL()))
                    out.add(f.toURI().toURL());
            } catch (Exception ignored) { }
        }
    }

    /** DriverManager chỉ chấp nhận driver do cùng class loader nạp, nên bọc driver nạp từ thư mục lib. */
    private static class DriverShim implements Driver {
        private final Driver d;
        DriverShim(Driver d) { this.d = d; }
        @Override public Connection connect(String url, Properties info) throws SQLException { return d.connect(url, info); }
        @Override public boolean acceptsURL(String url) throws SQLException { return d.acceptsURL(url); }
        @Override public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) throws SQLException { return d.getPropertyInfo(url, info); }
        @Override public int getMajorVersion() { return d.getMajorVersion(); }
        @Override public int getMinorVersion() { return d.getMinorVersion(); }
        @Override public boolean jdbcCompliant() { return d.jdbcCompliant(); }
        @Override public java.util.logging.Logger getParentLogger() throws SQLFeatureNotSupportedException { return d.getParentLogger(); }
    }

    public static Connection conn() throws SQLException {
        return DriverManager.getConnection(url, dbUser, dbPass);
    }

    /** Trả về null nếu kết nối được, ngược lại trả về thông báo lỗi. */
    public static String testConnection() {
        try (Connection c = conn()) {
            // ok
        } catch (SQLException e) {
            String m = String.valueOf(e.getMessage());
            if (m.contains("No suitable driver"))
                return "Chưa có MySQL JDBC Driver. Chạy bằng .jar: đặt file mysql-connector-java-x.jar vào thư mục \"lib\" cạnh ChatServer.jar. "
                        + "Chạy bằng NetBeans: Libraries -> Add JAR/Folder.";
            return m;
        }
        ensureSchema();
        return null;
    }

    /** Tự thêm các cột ảnh đại diện (users.avatar, chat_rooms.avatar) nếu CSDL cũ chưa có. */
    public static void ensureSchema() {
        addColumnIfMissing("users", "avatar", "ALTER TABLE users ADD COLUMN avatar MEDIUMBLOB NULL AFTER avatar_url");
        addColumnIfMissing("chat_rooms", "avatar", "ALTER TABLE chat_rooms ADD COLUMN avatar MEDIUMBLOB NULL AFTER description");
    }

    private static void addColumnIfMissing(String table, String column, String ddl) {
        try {
            List<Object[]> r = query("SELECT COUNT(*) FROM information_schema.COLUMNS "
                    + "WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?", table, column);
            if (lng(r.get(0)[0]) == 0) update(ddl);
        } catch (SQLException ignored) { }
    }

    // ------------------------------------------------------------ Tiện ích
    public static String hash(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static void bind(PreparedStatement ps, Object[] p) throws SQLException {
        for (int i = 0; i < p.length; i++) ps.setObject(i + 1, p[i]);
    }

    public static List<Object[]> query(String sql, Object... p) throws SQLException {
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, p);
            try (ResultSet rs = ps.executeQuery()) {
                int n = rs.getMetaData().getColumnCount();
                List<Object[]> out = new ArrayList<>();
                while (rs.next()) {
                    Object[] r = new Object[n];
                    for (int i = 0; i < n; i++) r[i] = rs.getObject(i + 1);
                    out.add(r);
                }
                return out;
            }
        }
    }

    public static int update(String sql, Object... p) throws SQLException {
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, p);
            return ps.executeUpdate();
        }
    }

    public static long insert(String sql, Object... p) throws SQLException {
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(ps, p);
            ps.executeUpdate();
            try (ResultSet k = ps.getGeneratedKeys()) {
                return k.next() ? k.getLong(1) : -1;
            }
        }
    }

    public static String str(Object o) { return o == null ? "" : o.toString(); }
    public static long lng(Object o) { return ((Number) o).longValue(); }
    public static boolean bool(Object o) {
        if (o instanceof Boolean) return (Boolean) o;
        return o instanceof Number && ((Number) o).intValue() != 0;
    }

    private static String dbError(SQLException e) {
        if (e instanceof SQLIntegrityConstraintViolationException) {
            String m = String.valueOf(e.getMessage());
            if (m.contains("uq_users_username")) return "Tên đăng nhập đã tồn tại";
            if (m.contains("uq_users_email")) return "Email đã được sử dụng";
            return "Vi phạm ràng buộc dữ liệu: " + m;
        }
        return "Lỗi CSDL: " + e.getMessage();
    }

    // ============================================================ NGƯỜI DÙNG
    public static class AuthResult {
        public long id;
        public String username = "", fullName = "", email = "", phone = "", error;
    }

    public static AuthResult login(String username, String password) {
        AuthResult r = new AuthResult();
        try {
            List<Object[]> rows = query("SELECT user_id, username, full_name, email, IFNULL(phone,''), password_hash, is_active "
                    + "FROM users WHERE username=?", username);
            if (rows.isEmpty() || !str(rows.get(0)[5]).equals(hash(password))) {
                r.error = "Sai tên đăng nhập hoặc mật khẩu";
                return r;
            }
            Object[] u = rows.get(0);
            if (!bool(u[6])) {
                r.error = "Tài khoản đã bị khóa";
                return r;
            }
            r.id = lng(u[0]);
            r.username = str(u[1]);
            r.fullName = str(u[2]);
            r.email = str(u[3]);
            r.phone = str(u[4]);
            update("UPDATE users SET last_login=NOW() WHERE user_id=?", r.id);
        } catch (SQLException e) {
            r.error = "Lỗi CSDL: " + e.getMessage();
        }
        return r;
    }

    private static String validateProfile(String fullName, String email, String phone) {
        if (fullName.trim().isEmpty() || fullName.length() > 100 || fullName.contains("|"))
            return "Họ tên không hợp lệ (không được để trống, không chứa dấu |)";
        if (!email.matches("^[^@\\s|]+@[^@\\s|]+\\.[^@\\s|]+$")) return "Email không hợp lệ";
        if (phone != null && !phone.isEmpty() && !phone.matches("[0-9+ ]{8,15}")) return "Số điện thoại không hợp lệ";
        return null;
    }

    /** Thêm người dùng mới (dùng cho đăng ký và cho Host). Trả về null nếu thành công. */
    public static String register(String username, String password, String fullName, String email, String phone) {
        if (!username.matches("[A-Za-z0-9_.-]{1,20}"))
            return "Tên đăng nhập chỉ gồm chữ không dấu, số, _ . - (tối đa 20 ký tự)";
        if (password.length() < 4 || password.length() > 50) return "Mật khẩu phải từ 4 đến 50 ký tự";
        if (password.contains("|")) return "Mật khẩu không được chứa dấu |";
        String err = validateProfile(fullName, email, phone);
        if (err != null) return err;
        try {
            long id = insert("INSERT INTO users(username, password_hash, full_name, email, phone) VALUES(?,?,?,?,?)",
                    username, hash(password), fullName, email, phone == null || phone.isEmpty() ? null : phone);
            // tự động vào phòng công khai đầu tiên
            update("INSERT IGNORE INTO room_members(room_id, user_id, role) "
                    + "SELECT room_id, ?, 'member' FROM chat_rooms WHERE room_type='public' ORDER BY room_id LIMIT 1", id);
            return null;
        } catch (SQLException e) {
            return dbError(e);
        }
    }

    public static List<Object[]> listUsers(String kw) throws SQLException {
        String k = "%" + kw + "%";
        return query("SELECT user_id, username, full_name, email, IFNULL(phone,''), is_active, "
                + "DATE_FORMAT(created_at,'%d/%m/%Y %H:%i'), (avatar IS NOT NULL) FROM users "
                + "WHERE username LIKE ? OR full_name LIKE ? OR email LIKE ? ORDER BY user_id", k, k, k);
    }

    public static List<Object[]> searchUsers(String kw, String exclude) throws SQLException {
        String k = "%" + kw + "%";
        return query("SELECT username, full_name FROM users WHERE is_active=1 AND username<>? "
                + "AND (username LIKE ? OR full_name LIKE ?) ORDER BY username LIMIT 50", exclude, k, k);
    }

    public static String updateUser(long id, String fullName, String email, String phone) {
        String err = validateProfile(fullName, email, phone);
        if (err != null) return err;
        try {
            update("UPDATE users SET full_name=?, email=?, phone=? WHERE user_id=?",
                    fullName, email, phone.isEmpty() ? null : phone, id);
            return null;
        } catch (SQLException e) {
            return dbError(e);
        }
    }

    // ------------------------------------------------------------ ảnh đại diện
    public static void setAvatar(long uid, byte[] data) throws SQLException {
        update("UPDATE users SET avatar=? WHERE user_id=?", data, uid);
    }

    public static void clearAvatar(long uid) throws SQLException {
        update("UPDATE users SET avatar=NULL WHERE user_id=?", uid);
    }

    public static byte[] getAvatar(String username) throws SQLException {
        List<Object[]> r = query("SELECT avatar FROM users WHERE username=?", username);
        if (r.isEmpty() || !(r.get(0)[0] instanceof byte[])) return null;
        return (byte[]) r.get(0)[0];
    }

    /** {username, byte[] ảnh} của những người có ảnh đại diện tùy chỉnh. */
    public static List<Object[]> allAvatars() throws SQLException {
        return query("SELECT username, avatar FROM users WHERE avatar IS NOT NULL AND is_active=1 LIMIT 300");
    }

    /** Sửa thông tin người dùng, bao gồm cả tên đăng nhập. Trả về null nếu thành công. */
    public static String updateUser(long id, String username, String fullName, String email, String phone) {
        if (!username.matches("[A-Za-z0-9_.-]{1,20}"))
            return "Tên đăng nhập chỉ gồm chữ không dấu, số, _ . - (tối đa 20 ký tự)";
        String err = validateProfile(fullName, email, phone);
        if (err != null) return err;
        try {
            update("UPDATE users SET username=?, full_name=?, email=?, phone=? WHERE user_id=?",
                    username, fullName, email, phone.isEmpty() ? null : phone, id);
            return null;
        } catch (SQLException e) {
            return dbError(e);
        }
    }

    /** @return 1 = đã xóa hẳn, 2 = người dùng đã có dữ liệu nên chỉ bị khóa, 0 = lỗi */
    public static int deleteUser(long id) {
        try {
            update("DELETE FROM users WHERE user_id=?", id);
            return 1;
        } catch (SQLIntegrityConstraintViolationException e) {
            try {
                update("UPDATE users SET is_active=0, status='offline' WHERE user_id=?", id);
                return 2;
            } catch (SQLException e2) {
                return 0;
            }
        } catch (SQLException e) {
            return 0;
        }
    }

    public static void setActive(long id, boolean active) throws SQLException {
        update("UPDATE users SET is_active=? WHERE user_id=?", active ? 1 : 0, id);
    }

    public static String resetPassword(long id, String newPass) {
        if (newPass.length() < 4 || newPass.length() > 50) return "Mật khẩu phải từ 4 đến 50 ký tự";
        if (newPass.contains("|")) return "Mật khẩu không được chứa dấu |";
        try {
            update("UPDATE users SET password_hash=? WHERE user_id=?", hash(newPass), id);
            return null;
        } catch (SQLException e) {
            return dbError(e);
        }
    }

    public static String changePassword(long id, String oldPass, String newPass) {
        try {
            List<Object[]> r = query("SELECT password_hash FROM users WHERE user_id=?", id);
            if (r.isEmpty() || !str(r.get(0)[0]).equals(hash(oldPass))) return "Mật khẩu hiện tại không đúng";
        } catch (SQLException e) {
            return dbError(e);
        }
        return resetPassword(id, newPass);
    }

    public static long userId(String username) throws SQLException {
        List<Object[]> r = query("SELECT user_id FROM users WHERE username=? AND is_active=1", username);
        return r.isEmpty() ? -1 : lng(r.get(0)[0]);
    }

    public static void setStatus(long id, String status) {
        try {
            update("UPDATE users SET status=? WHERE user_id=?", status, id);
        } catch (SQLException ignored) { }
    }

    public static void resetAllOffline() {
        try {
            update("UPDATE users SET status='offline'");
        } catch (SQLException ignored) { }
    }

    public static long logLogin(long uid, String ip) {
        try {
            return insert("INSERT INTO login_history(user_id, ip_address) VALUES(?,?)", uid, ip);
        } catch (SQLException e) {
            return -1;
        }
    }

    public static void logLogout(long logId) {
        if (logId < 0) return;
        try {
            update("UPDATE login_history SET logout_time=NOW() WHERE log_id=?", logId);
        } catch (SQLException ignored) { }
    }

    public static long count(String table) {
        if (!Arrays.asList("users", "chat_rooms", "messages").contains(table)) return 0;
        try {
            String extra = table.equals("messages") ? " WHERE is_deleted=0" : "";
            return lng(query("SELECT COUNT(*) FROM " + table + extra).get(0)[0]);
        } catch (SQLException e) {
            return -1;
        }
    }

    // ============================================================ PHÒNG CHAT
    public static String otherMember(long roomId, long uid) throws SQLException {
        List<Object[]> r = query("SELECT u.username FROM room_members m JOIN users u ON u.user_id=m.user_id "
                + "WHERE m.room_id=? AND m.user_id<>? LIMIT 1", roomId, uid);
        return r.isEmpty() ? "(đã rời)" : str(r.get(0)[0]);
    }

    /** {id, type, tên hiển thị} của phòng đối với người xem. */
    public static String[] roomLabel(long roomId, long viewerId) throws SQLException {
        List<Object[]> r = query("SELECT room_type, IFNULL(room_name,'') FROM chat_rooms WHERE room_id=?", roomId);
        if (r.isEmpty()) return null;
        String type = str(r.get(0)[0]), name = str(r.get(0)[1]);
        if (type.equals("direct")) name = otherMember(roomId, viewerId);
        return new String[]{String.valueOf(roomId), type, name};
    }

    public static List<String[]> roomsOfUser(long uid) throws SQLException {
        List<String[]> out = new ArrayList<>();
        for (Object[] r : query("SELECT r.room_id FROM chat_rooms r JOIN room_members m ON m.room_id=r.room_id "
                + "WHERE m.user_id=? ORDER BY r.room_id", uid)) {
            String[] label = roomLabel(lng(r[0]), uid);
            if (label != null) out.add(label);
        }
        return out;
    }

    public static long createRoom(String name, String desc, String type, long creator, Collection<Long> members) throws SQLException {
        try (Connection c = conn()) {
            c.setAutoCommit(false);
            try {
                long id;
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO chat_rooms(room_name, description, room_type, created_by) VALUES(?,?,?,?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, name);
                    ps.setString(2, desc == null || desc.isEmpty() ? null : desc);
                    ps.setString(3, type);
                    ps.setLong(4, creator);
                    ps.executeUpdate();
                    try (ResultSet k = ps.getGeneratedKeys()) {
                        k.next();
                        id = k.getLong(1);
                    }
                }
                Set<Long> all = new LinkedHashSet<>();
                all.add(creator);
                all.addAll(members);
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT IGNORE INTO room_members(room_id, user_id, role) VALUES(?,?,?)")) {
                    for (long u : all) {
                        ps.setLong(1, id);
                        ps.setLong(2, u);
                        ps.setString(3, u == creator ? "owner" : "member");
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
                c.commit();
                return id;
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    public static long getOrCreateDirect(long a, long b) throws SQLException {
        List<Object[]> r = query("SELECT r.room_id FROM chat_rooms r WHERE r.room_type='direct' "
                + "AND EXISTS(SELECT 1 FROM room_members WHERE room_id=r.room_id AND user_id=?) "
                + "AND EXISTS(SELECT 1 FROM room_members WHERE room_id=r.room_id AND user_id=?) LIMIT 1", a, b);
        if (!r.isEmpty()) return lng(r.get(0)[0]);
        return createRoom(null, null, "direct", a, Collections.singletonList(b));
    }

    public static boolean isMember(long roomId, long uid) throws SQLException {
        return !query("SELECT 1 FROM room_members WHERE room_id=? AND user_id=?", roomId, uid).isEmpty();
    }

    public static String roomType(long roomId) throws SQLException {
        List<Object[]> r = query("SELECT room_type FROM chat_rooms WHERE room_id=?", roomId);
        return r.isEmpty() ? null : str(r.get(0)[0]);
    }

    public static List<Object[]> findPublicRooms(String kw, long uid) throws SQLException {
        return query("SELECT r.room_id, r.room_name, IFNULL(r.description,''), "
                + "(SELECT COUNT(*) FROM room_members WHERE room_id=r.room_id), "
                + "EXISTS(SELECT 1 FROM room_members WHERE room_id=r.room_id AND user_id=?) "
                + "FROM chat_rooms r WHERE r.room_type='public' AND r.room_name LIKE ? ORDER BY r.room_name",
                uid, "%" + kw + "%");
    }

    public static List<Object[]> adminRooms(String kw) throws SQLException {
        String k = "%" + kw + "%";
        return query("SELECT r.room_id, IFNULL(r.room_name,'(chat riêng)'), r.room_type, u.username, "
                + "(SELECT COUNT(*) FROM room_members m WHERE m.room_id=r.room_id), IFNULL(r.description,''), "
                + "DATE_FORMAT(r.created_at,'%d/%m/%Y %H:%i'), (r.avatar IS NOT NULL) FROM chat_rooms r JOIN users u ON u.user_id=r.created_by "
                + "WHERE IFNULL(r.room_name,'') LIKE ? OR u.username LIKE ? OR IFNULL(r.description,'') LIKE ? "
                + "ORDER BY r.room_id", k, k, k);
    }

    // ---- ảnh nhóm chat
    public static String memberRole(long roomId, long uid) throws SQLException {
        List<Object[]> r = query("SELECT role FROM room_members WHERE room_id=? AND user_id=?", roomId, uid);
        return r.isEmpty() ? null : str(r.get(0)[0]);
    }

    public static void setRoomAvatar(long roomId, byte[] data) throws SQLException {
        update("UPDATE chat_rooms SET avatar=? WHERE room_id=?", data, roomId);
    }

    public static void clearRoomAvatar(long roomId) throws SQLException {
        update("UPDATE chat_rooms SET avatar=NULL WHERE room_id=?", roomId);
    }

    public static byte[] getRoomAvatar(long roomId) throws SQLException {
        List<Object[]> r = query("SELECT avatar FROM chat_rooms WHERE room_id=?", roomId);
        if (r.isEmpty() || !(r.get(0)[0] instanceof byte[])) return null;
        return (byte[]) r.get(0)[0];
    }

    /** {room_id, byte[] ảnh} của các phòng mà người dùng tham gia và có ảnh nhóm. */
    public static List<Object[]> roomAvatarsOf(long uid) throws SQLException {
        return query("SELECT r.room_id, r.avatar FROM chat_rooms r JOIN room_members m ON m.room_id=r.room_id "
                + "WHERE m.user_id=? AND r.avatar IS NOT NULL", uid);
    }

    public static void updateRoom(long id, String name, String desc) throws SQLException {
        update("UPDATE chat_rooms SET room_name=?, description=? WHERE room_id=?", name,
                desc == null || desc.isEmpty() ? null : desc, id);
    }

    public static void deleteRoom(long id) throws SQLException {
        update("DELETE FROM chat_rooms WHERE room_id=?", id);
    }

    public static List<Object[]> memberRows(long roomId) throws SQLException {
        return query("SELECT u.user_id, u.username, m.role, DATE_FORMAT(m.joined_at,'%d/%m/%Y %H:%i') "
                + "FROM room_members m JOIN users u ON u.user_id=m.user_id WHERE m.room_id=? "
                + "ORDER BY m.joined_at, u.username", roomId);
    }

    public static List<String> memberNames(long roomId) throws SQLException {
        List<String> out = new ArrayList<>();
        for (Object[] r : memberRows(roomId)) out.add(str(r[1]));
        return out;
    }

    public static void addMember(long roomId, long uid) throws SQLException {
        update("INSERT IGNORE INTO room_members(room_id, user_id, role) VALUES(?,?, 'member')", roomId, uid);
    }

    public static void removeMember(long roomId, long uid) throws SQLException {
        update("DELETE FROM room_members WHERE room_id=? AND user_id=?", roomId, uid);
        // phòng không còn ai thì xóa luôn
        update("DELETE FROM chat_rooms WHERE room_id=? AND NOT EXISTS (SELECT 1 FROM room_members WHERE room_id=?)",
                roomId, roomId);
    }

    // ============================================================ TIN NHẮN
    private static final String MSG_SELECT =
            "SELECT m.message_id, m.room_id, u.username, DATE_FORMAT(m.sent_at,'%H:%i %d/%m'), "
            + "IF(m.edited_at IS NULL,0,1), m.content FROM messages m JOIN users u ON u.user_id=m.sender_id ";

    public static long insertMessage(long roomId, long senderId, String content) throws SQLException {
        return insert("INSERT INTO messages(room_id, sender_id, content) VALUES(?,?,?)", roomId, senderId, content);
    }

    /** {id, roomId, người gửi, giờ, đã sửa(0/1), nội dung} */
    public static Object[] msgRow(long id) throws SQLException {
        List<Object[]> r = query(MSG_SELECT + "WHERE m.message_id=?", id);
        return r.isEmpty() ? null : r.get(0);
    }

    public static List<Object[]> history(long roomId, int limit) throws SQLException {
        List<Object[]> r = query(MSG_SELECT + "WHERE m.room_id=? AND m.is_deleted=0 ORDER BY m.message_id DESC LIMIT ?",
                roomId, limit);
        Collections.reverse(r);
        return r;
    }

    public static long roomOfMessage(long msgId) throws SQLException {
        List<Object[]> r = query("SELECT room_id FROM messages WHERE message_id=?", msgId);
        return r.isEmpty() ? -1 : lng(r.get(0)[0]);
    }

    /** Sửa tin nhắn của chính mình. Trả về room_id hoặc -1 nếu không sửa được. */
    public static long editMessage(long msgId, long uid, String content) throws SQLException {
        int n = update("UPDATE messages SET content=?, edited_at=NOW() "
                + "WHERE message_id=? AND sender_id=? AND is_deleted=0", content, msgId, uid);
        return n == 0 ? -1 : roomOfMessage(msgId);
    }

    /** Xóa (mềm) tin nhắn của chính mình. Trả về room_id hoặc -1. */
    public static long deleteMessage(long msgId, long uid) throws SQLException {
        long room = roomOfMessage(msgId);
        int n = update("UPDATE messages SET is_deleted=1 WHERE message_id=? AND sender_id=? AND is_deleted=0", msgId, uid);
        return n == 0 ? -1 : room;
    }

    /** {id, roomId, tên phòng, người gửi, giờ, nội dung} - chỉ trong các phòng người dùng tham gia. */
    public static List<Object[]> searchMessages(long uid, long roomId, String kw) throws SQLException {
        return query("SELECT m.message_id, m.room_id, IFNULL(r.room_name,'(chat riêng)'), u.username, "
                + "DATE_FORMAT(m.sent_at,'%H:%i %d/%m/%Y'), m.content FROM messages m "
                + "JOIN users u ON u.user_id=m.sender_id JOIN chat_rooms r ON r.room_id=m.room_id "
                + "WHERE m.is_deleted=0 AND m.content LIKE ? "
                + "AND m.room_id IN (SELECT room_id FROM room_members WHERE user_id=?) "
                + "AND (?=0 OR m.room_id=?) ORDER BY m.message_id DESC LIMIT 100",
                "%" + kw + "%", uid, roomId, roomId);
    }

    public static List<Object[]> adminMessages(String kw) throws SQLException {
        String k = "%" + kw + "%";
        return query("SELECT m.message_id, IFNULL(r.room_name,'(chat riêng)'), u.username, "
                + "DATE_FORMAT(m.sent_at,'%d/%m/%Y %H:%i:%s'), IFNULL(m.content,''), "
                + "IF(m.is_deleted=1,'Đã xóa','') FROM messages m JOIN users u ON u.user_id=m.sender_id "
                + "JOIN chat_rooms r ON r.room_id=m.room_id WHERE m.content LIKE ? OR u.username LIKE ? "
                + "ORDER BY m.message_id DESC LIMIT 500", k, k);
    }

    public static void adminDeleteMessage(long id) throws SQLException {
        update("DELETE FROM messages WHERE message_id=?", id);
    }

    // ============================================================ BẠN BÈ
    public static String usernameOf(long id) throws SQLException {
        List<Object[]> r = query("SELECT username FROM users WHERE user_id=?", id);
        return r.isEmpty() ? null : str(r.get(0)[0]);
    }

    /** Gửi lời mời kết bạn. Trả về null nếu thành công, ngược lại là thông báo lỗi. */
    public static String sendFriendRequest(long from, long to) throws SQLException {
        if (from == to) return "Không thể kết bạn với chính mình";
        List<Object[]> ex = query("SELECT user_id, status FROM friendships "
                + "WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)", from, to, to, from);
        if (!ex.isEmpty()) {
            String st = str(ex.get(0)[1]);
            if (st.equals("accepted")) return "Hai bạn đã là bạn bè";
            if (st.equals("blocked")) return "Không thể gửi lời mời cho người dùng này";
            return lng(ex.get(0)[0]) == from
                    ? "Bạn đã gửi lời mời trước đó, hãy chờ phản hồi"
                    : "Người này đã gửi lời mời cho bạn - hãy vào tab Lời mời để chấp nhận";
        }
        update("INSERT INTO friendships(user_id, friend_id, status) VALUES(?,?, 'pending')", from, to);
        return null;
    }

    /** Chấp nhận / từ chối lời mời đã nhận. Trả về id người gửi hoặc -1 nếu lời mời không hợp lệ. */
    public static long respondRequest(long me, long reqId, boolean accept) throws SQLException {
        List<Object[]> r = query("SELECT user_id FROM friendships WHERE friendship_id=? AND friend_id=? AND status='pending'",
                reqId, me);
        if (r.isEmpty()) return -1;
        if (accept) update("UPDATE friendships SET status='accepted', responded_at=NOW() WHERE friendship_id=?", reqId);
        else update("DELETE FROM friendships WHERE friendship_id=?", reqId);
        return lng(r.get(0)[0]);
    }

    /** Thu hồi lời mời đã gửi. Trả về id người nhận hoặc -1. */
    public static long cancelRequest(long me, long reqId) throws SQLException {
        List<Object[]> r = query("SELECT friend_id FROM friendships WHERE friendship_id=? AND user_id=? AND status='pending'",
                reqId, me);
        if (r.isEmpty()) return -1;
        update("DELETE FROM friendships WHERE friendship_id=?", reqId);
        return lng(r.get(0)[0]);
    }

    public static boolean unfriend(long a, long b) throws SQLException {
        return update("DELETE FROM friendships WHERE status='accepted' "
                + "AND ((user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?))", a, b, b, a) > 0;
    }

    /** {username, họ tên} */
    public static List<Object[]> friendsOf(long uid) throws SQLException {
        return query("SELECT u.username, u.full_name FROM friendships f "
                + "JOIN users u ON u.user_id = IF(f.user_id=?, f.friend_id, f.user_id) "
                + "WHERE f.status='accepted' AND (f.user_id=? OR f.friend_id=?) AND u.is_active=1 ORDER BY u.username",
                uid, uid, uid);
    }

    /** Lời mời đã nhận: {id lời mời, username, họ tên, thời gian} */
    public static List<Object[]> incomingRequests(long uid) throws SQLException {
        return query("SELECT f.friendship_id, u.username, u.full_name, DATE_FORMAT(f.created_at,'%d/%m/%Y %H:%i') "
                + "FROM friendships f JOIN users u ON u.user_id=f.user_id "
                + "WHERE f.friend_id=? AND f.status='pending' ORDER BY f.friendship_id DESC", uid);
    }

    /** Lời mời đã gửi: {id lời mời, username, họ tên, thời gian} */
    public static List<Object[]> outgoingRequests(long uid) throws SQLException {
        return query("SELECT f.friendship_id, u.username, u.full_name, DATE_FORMAT(f.created_at,'%d/%m/%Y %H:%i') "
                + "FROM friendships f JOIN users u ON u.user_id=f.friend_id "
                + "WHERE f.user_id=? AND f.status='pending' ORDER BY f.friendship_id DESC", uid);
    }

    /** Tìm người dùng kèm quan hệ với mình: {username, họ tên, none|friend|sent|received} */
    public static List<Object[]> searchUsersWithRelation(String kw, long uid) throws SQLException {
        String k = "%" + kw + "%";
        return query("SELECT u.username, u.full_name, IFNULL((SELECT CASE WHEN f.status='accepted' THEN 'friend' "
                + "WHEN f.user_id=? THEN 'sent' ELSE 'received' END FROM friendships f "
                + "WHERE (f.user_id=? AND f.friend_id=u.user_id) OR (f.user_id=u.user_id AND f.friend_id=?) LIMIT 1),'none') "
                + "FROM users u WHERE u.is_active=1 AND u.user_id<>? AND (u.username LIKE ? OR u.full_name LIKE ?) "
                + "ORDER BY u.username LIMIT 50", uid, uid, uid, uid, k, k);
    }

    // ---- dành cho Host quản trị
    public static List<Object[]> adminFriendships(String kw) throws SQLException {
        String k = "%" + kw + "%";
        return query("SELECT f.friendship_id, a.username, b.username, f.status, "
                + "DATE_FORMAT(f.created_at,'%d/%m/%Y %H:%i'), IFNULL(DATE_FORMAT(f.responded_at,'%d/%m/%Y %H:%i'),'') "
                + "FROM friendships f JOIN users a ON a.user_id=f.user_id JOIN users b ON b.user_id=f.friend_id "
                + "WHERE a.username LIKE ? OR b.username LIKE ? OR a.full_name LIKE ? OR b.full_name LIKE ? "
                + "ORDER BY f.friendship_id DESC", k, k, k, k);
    }

    public static String adminAddFriendship(String u1, String u2, String status) throws SQLException {
        if (!Arrays.asList("pending", "accepted", "blocked").contains(status))
            return "Trạng thái phải là pending, accepted hoặc blocked";
        long a = userId(u1), b = userId(u2);
        if (a < 0) return "Không tìm thấy người dùng \"" + u1 + "\"";
        if (b < 0) return "Không tìm thấy người dùng \"" + u2 + "\"";
        if (a == b) return "Không thể kết bạn với chính mình";
        if (!query("SELECT 1 FROM friendships WHERE (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)",
                a, b, b, a).isEmpty()) return "Quan hệ giữa hai người này đã tồn tại";
        update("INSERT INTO friendships(user_id, friend_id, status, responded_at) VALUES(?,?,?, IF(?='pending', NULL, NOW()))",
                a, b, status, status);
        return null;
    }

    public static void setFriendStatus(long id, String status) throws SQLException {
        update("UPDATE friendships SET status=?, responded_at=NOW() WHERE friendship_id=?", status, id);
    }

    public static void deleteFriendship(long id) throws SQLException {
        update("DELETE FROM friendships WHERE friendship_id=?", id);
    }
}
