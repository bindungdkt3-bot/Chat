import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;

/**
 * ServerApp - GIAO DIỆN MÁY HOST (quản trị).
 * Gồm: Tổng quan (bật/tắt server, cấu hình CSDL, nhật ký), Người dùng, Phòng chat, Tin nhắn.
 * Mỗi mục đều có Thêm / Sửa / Xóa / Tìm kiếm kết nối trực tiếp với MySQL.
 */
public class ServerApp extends JFrame {

    private final ChatServer server = new ChatServer();
    private final CardLayout cards = new CardLayout();
    private final JPanel content = new JPanel(cards);
    private final List<NavButton> navs = new ArrayList<>();
    private final JLabel sideStatus = new JLabel("● Server đang dừng");
    private String currentCard = "dashboard";
    private boolean dbOk = false;

    private DashboardPanel dashboard;
    private UsersPanel usersPanel;
    private RoomsPanel roomsPanel;
    private MessagesPanel messagesPanel;
    private FriendsPanel friendsPanel;

    public ServerApp() {
        super("Chat Host - Quản trị máy chủ");
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setIconImage(Theme.appIcon());
        setSize(1180, 740);
        setMinimumSize(new Dimension(980, 620));
        setLocationRelativeTo(null);

        dashboard = new DashboardPanel();
        usersPanel = new UsersPanel();
        roomsPanel = new RoomsPanel();
        messagesPanel = new MessagesPanel();
        friendsPanel = new FriendsPanel();
        content.add(dashboard, "dashboard");
        content.add(usersPanel, "users");
        content.add(friendsPanel, "friends");
        content.add(roomsPanel, "rooms");
        content.add(messagesPanel, "messages");

        add(buildSidebar(), BorderLayout.WEST);
        add(content, BorderLayout.CENTER);
        navs.get(0).selected = true;

        server.setLogger(msg -> SwingUtilities.invokeLater(() -> dashboard.appendLog(msg)));
        server.setOnChange(() -> SwingUtilities.invokeLater(this::onServerChange));

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (server.isRunning() && !Theme.confirm(ServerApp.this, "Server đang chạy. Dừng server và thoát?")) return;
                if (server.isRunning()) server.stop();
                dispose();
                System.exit(0);
            }
        });
    }

    // ------------------------------------------------------------ khung chung
    private JPanel buildSidebar() {
        JPanel side = new JPanel();
        side.setBackground(Theme.SIDEBAR);
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setPreferredSize(new Dimension(230, 0));
        side.setBorder(new EmptyBorder(22, 14, 18, 14));

        JLabel title = new JLabel("Chat Host", Theme.logoIcon(34), SwingConstants.LEFT);
        title.setIconTextGap(10);
        title.setFont(Theme.TITLE);
        title.setForeground(Color.WHITE);
        Theme.fixed(title);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel sub = new JLabel("  Bảng điều khiển máy chủ");
        sub.setFont(Theme.SMALL);
        sub.setForeground(new Color(0x9CA3AF));
        Theme.fixed(sub);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);
        side.add(title);
        side.add(sub);
        side.add(Box.createVerticalStrut(26));

        side.add(nav("Tổng quan", "dashboard"));
        side.add(Box.createVerticalStrut(4));
        side.add(nav("Người dùng", "users"));
        side.add(Box.createVerticalStrut(4));
        side.add(nav("Bạn bè", "friends"));
        side.add(Box.createVerticalStrut(4));
        side.add(nav("Phòng chat", "rooms"));
        side.add(Box.createVerticalStrut(4));
        side.add(nav("Tin nhắn", "messages"));
        side.add(Box.createVerticalGlue());

        final Theme.RoundButton themeBtn = new Theme.RoundButton(Theme.dark ? "Chế độ sáng" : "Chế độ tối",
                new Color(0x374151), Color.WHITE);
        themeBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        themeBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        themeBtn.addActionListener(e -> {
            Theme.toggleDark();
            themeBtn.setText(Theme.dark ? "Chế độ sáng" : "Chế độ tối");
        });
        side.add(themeBtn);
        side.add(Box.createVerticalStrut(14));

        sideStatus.setForeground(new Color(0xF87171));
        Theme.fixed(sideStatus);
        sideStatus.setFont(Theme.BOLD);
        sideStatus.setAlignmentX(Component.LEFT_ALIGNMENT);
        side.add(sideStatus);
        return side;
    }

    private NavButton nav(String text, String card) {
        NavButton b = new NavButton(text, card);
        navs.add(b);
        return b;
    }

    private class NavButton extends JButton {
        boolean selected, over;

        NavButton(String text, String card) {
            super(text);
            setHorizontalAlignment(LEFT);
            setFont(Theme.BOLD);
            setForeground(new Color(0xE5E7EB));
            putClientProperty(Theme.FIXED_COLORS, Boolean.TRUE);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setBorder(new EmptyBorder(11, 16, 11, 16));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
            setAlignmentX(Component.LEFT_ALIGNMENT);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { over = true; repaint(); }
                @Override public void mouseExited(MouseEvent e)  { over = false; repaint(); }
            });
            addActionListener(e -> showCard(card, this));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (selected) {
                g2.setColor(Theme.SIDEBAR_SEL);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            } else if (over) {
                g2.setColor(new Color(0x374151));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private void showCard(String card, NavButton btn) {
        for (NavButton n : navs) { n.selected = (n == btn); n.repaint(); }
        currentCard = card;
        cards.show(content, card);
        refreshCurrent();
    }

    private void refreshCurrent() {
        switch (currentCard) {
            case "dashboard": dashboard.refreshStats(); break;
            case "users": usersPanel.reload(true); break;
            case "friends": friendsPanel.reload(true); break;
            case "rooms": roomsPanel.reload(true); break;
            case "messages": messagesPanel.reload(true); break;
        }
    }

    private void onServerChange() {
        boolean run = server.isRunning();
        sideStatus.setText(run ? "● Server đang chạy" : "● Server đang dừng");
        sideStatus.setForeground(run ? new Color(0x4ADE80) : new Color(0xF87171));
        dashboard.updateRunningState();
        dashboard.refreshStats();
        if (currentCard.equals("users")) usersPanel.reload(false);
    }

    /** Đảm bảo đã kết nối được CSDL (dùng cấu hình ở trang Tổng quan). */
    private boolean ensureDb(boolean showError) {
        if (dbOk) return true;
        dashboard.applyConfig();
        String err = Dao.testConnection();
        if (err != null) {
            if (showError) Theme.error(this, "Chưa kết nối được CSDL:\n" + err
                    + "\n\nHãy kiểm tra cấu hình ở trang Tổng quan.");
            return false;
        }
        dbOk = true;
        return true;
    }

    private static long idOf(JTable t) {
        int r = t.getSelectedRow();
        return r < 0 ? -1 : Long.parseLong(t.getValueAt(r, 0).toString());
    }

    private static String cell(JTable t, int col) {
        int r = t.getSelectedRow();
        return r < 0 ? "" : String.valueOf(t.getValueAt(r, col));
    }

    // ============================================================ TỔNG QUAN
    private class DashboardPanel extends JPanel {
        final JLabel onlineVal = new JLabel("0"), usersVal = new JLabel("-"), roomsVal = new JLabel("-"), msgsVal = new JLabel("-");
        final Theme.RoundField urlF = new Theme.RoundField(null, 30);
        final Theme.RoundField userF = new Theme.RoundField(null, 10);
        final Theme.RoundPassword passF = new Theme.RoundPassword(null, 10);
        final Theme.RoundField portF = new Theme.RoundField(null, 6);
        final Theme.RoundButton toggleBtn = Theme.successButton("Khởi động server");
        final Theme.RoundButton testBtn = Theme.lightButton("Kiểm tra CSDL");
        final JLabel info = new JLabel(" ");
        final JTextArea logArea = new JTextArea();

        DashboardPanel() {
            setLayout(new BorderLayout(0, 14));
            setBorder(new EmptyBorder(20, 24, 20, 24));
            setBackground(Theme.BG);

            JLabel t = new JLabel("Tổng quan");
            t.setFont(Theme.TITLE);
            JLabel s = new JLabel("Bật/tắt máy chủ chat và theo dõi hoạt động");
            s.setForeground(Theme.MUTED);
            JPanel head = new JPanel(new GridLayout(2, 1));
            head.setOpaque(false);
            head.add(t);
            head.add(s);

            JPanel stats = new JPanel(new GridLayout(1, 4, 14, 0));
            stats.setOpaque(false);
            stats.add(statCard("Đang online", onlineVal, Theme.SUCCESS));
            stats.add(statCard("Người dùng", usersVal, Theme.PRIMARY));
            stats.add(statCard("Phòng chat", roomsVal, new Color(0x9B51E0)));
            stats.add(statCard("Tin nhắn", msgsVal, new Color(0xF2994A)));

            urlF.setText(Dao.url);
            userF.setText(Dao.dbUser);
            portF.setText("5000");
            JPanel cfg = Theme.card();
            cfg.setLayout(new GridBagLayout());
            GridBagConstraints gc = new GridBagConstraints();
            gc.insets = new Insets(4, 4, 4, 4);
            gc.fill = GridBagConstraints.HORIZONTAL;
            gc.gridx = 0; gc.gridy = 0; gc.weightx = 0; cfg.add(label("Chuỗi kết nối MySQL"), gc);
            gc.gridx = 1; gc.gridwidth = 5; gc.weightx = 1; cfg.add(urlF, gc);
            gc.gridwidth = 1;
            gc.gridx = 0; gc.gridy = 1; gc.weightx = 0; cfg.add(label("Tài khoản"), gc);
            gc.gridx = 1; gc.weightx = 0.3; cfg.add(userF, gc);
            gc.gridx = 2; gc.weightx = 0; cfg.add(label("Mật khẩu"), gc);
            gc.gridx = 3; gc.weightx = 0.3; cfg.add(passF, gc);
            gc.gridx = 4; gc.weightx = 0; cfg.add(label("Cổng server"), gc);
            gc.gridx = 5; gc.weightx = 0.1; cfg.add(portF, gc);
            JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            btns.setOpaque(false);
            btns.add(toggleBtn);
            btns.add(testBtn);
            btns.add(info);
            gc.gridx = 1; gc.gridy = 2; gc.gridwidth = 5; gc.weightx = 1; gc.insets = new Insets(10, 4, 0, 4);
            cfg.add(btns, gc);

            logArea.setEditable(false);
            logArea.setBackground(new Color(0x111827));
            logArea.setForeground(new Color(0xD1FAE5));
            logArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
            logArea.setBorder(new EmptyBorder(8, 10, 8, 10));
            JScrollPane sp = new JScrollPane(logArea);
            sp.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
            JLabel logTitle = new JLabel("Nhật ký hoạt động");
            logTitle.setFont(Theme.H2);
            JPanel logBox = new JPanel(new BorderLayout(0, 8));
            logBox.setOpaque(false);
            logBox.add(logTitle, BorderLayout.NORTH);
            logBox.add(sp, BorderLayout.CENTER);

            JPanel top = new JPanel();
            top.setOpaque(false);
            top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
            head.setAlignmentX(LEFT_ALIGNMENT);
            stats.setAlignmentX(LEFT_ALIGNMENT);
            cfg.setAlignmentX(LEFT_ALIGNMENT);
            top.add(head);
            top.add(Box.createVerticalStrut(14));
            top.add(stats);
            top.add(Box.createVerticalStrut(14));
            top.add(cfg);
            add(top, BorderLayout.NORTH);
            add(logBox, BorderLayout.CENTER);

            toggleBtn.addActionListener(e -> toggle());
            testBtn.addActionListener(e -> testDb());
        }

        private JLabel label(String s) {
            JLabel l = new JLabel(s);
            l.setFont(Theme.BOLD);
            return l;
        }

        private JPanel statCard(String caption, JLabel value, Color color) {
            JPanel c = Theme.card();
            c.setLayout(new BorderLayout());
            value.setFont(Theme.TITLE.deriveFont(30f));
            value.setForeground(color);
            JLabel cap = new JLabel(caption);
            cap.setForeground(Theme.MUTED);
            c.add(value, BorderLayout.CENTER);
            c.add(cap, BorderLayout.SOUTH);
            return c;
        }

        void applyConfig() {
            Dao.url = urlF.getText().trim();
            Dao.dbUser = userF.getText().trim();
            Dao.dbPass = new String(passF.getPassword());
        }

        void appendLog(String msg) {
            logArea.append("[" + new SimpleDateFormat("HH:mm:ss").format(new Date()) + "] " + msg + "\n");
            logArea.setCaretPosition(logArea.getDocument().getLength());
        }

        void updateRunningState() {
            boolean run = server.isRunning();
            toggleBtn.setText(run ? "Dừng server" : "Khởi động server");
            urlF.setEnabled(!run);
            userF.setEnabled(!run);
            passF.setEnabled(!run);
            portF.setEnabled(!run);
            info.setText(run ? "  Máy khác kết nối tới IP: " + ChatServer.localIp() + "  |  cổng " + portF.getText() : " ");
        }

        void refreshStats() {
            onlineVal.setText(String.valueOf(server.onlineNames().size()));
            if (!dbOk) return;
            new Thread(() -> {
                long u = Dao.count("users"), r = Dao.count("chat_rooms"), m = Dao.count("messages");
                SwingUtilities.invokeLater(() -> {
                    usersVal.setText(u < 0 ? "-" : String.valueOf(u));
                    roomsVal.setText(r < 0 ? "-" : String.valueOf(r));
                    msgsVal.setText(m < 0 ? "-" : String.valueOf(m));
                });
            }).start();
        }

        void testDb() {
            applyConfig();
            testBtn.setEnabled(false);
            new Thread(() -> {
                String err = Dao.testConnection();
                SwingUtilities.invokeLater(() -> {
                    testBtn.setEnabled(true);
                    dbOk = err == null;
                    if (err == null) {
                        Theme.info(ServerApp.this, "Kết nối CSDL thành công!");
                        refreshStats();
                    } else {
                        Theme.error(ServerApp.this, "Không kết nối được CSDL:\n" + err);
                    }
                });
            }).start();
        }

        void toggle() {
            if (server.isRunning()) {
                server.stop();
                return;
            }
            final int port;
            try {
                port = Integer.parseInt(portF.getText().trim());
            } catch (NumberFormatException ex) {
                Theme.error(ServerApp.this, "Cổng không hợp lệ!");
                return;
            }
            applyConfig();
            toggleBtn.setEnabled(false);
            info.setText("  Đang kết nối CSDL...");
            new Thread(() -> {
                String err = Dao.testConnection();
                SwingUtilities.invokeLater(() -> {
                    toggleBtn.setEnabled(true);
                    if (err != null) {
                        dbOk = false;
                        info.setText(" ");
                        Theme.error(ServerApp.this, "Không kết nối được CSDL:\n" + err);
                        return;
                    }
                    dbOk = true;
                    try {
                        server.start(port);
                    } catch (IOException ex) {
                        Theme.error(ServerApp.this, "Không mở được cổng " + port + ": " + ex.getMessage());
                    }
                    updateRunningState();
                });
            }).start();
        }
    }

    // ============================================================ KHUNG BẢNG CRUD DÙNG CHUNG
    private abstract class CrudPanel extends JPanel {
        final Theme.RoundField search = new Theme.RoundField("Tìm kiếm...", 22);
        final DefaultTableModel model;
        final JTable table;
        final JScrollPane tableScroll;
        final JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));

        CrudPanel(String title, String subtitle, String[] cols) {
            setLayout(new BorderLayout(0, 12));
            setBorder(new EmptyBorder(20, 24, 20, 24));
            setBackground(Theme.BG);

            JLabel t = new JLabel(title);
            t.setFont(Theme.TITLE);
            JLabel s = new JLabel(subtitle);
            s.setForeground(Theme.MUTED);
            JPanel tl = new JPanel(new GridLayout(2, 1));
            tl.setOpaque(false);
            tl.add(t);
            tl.add(s);
            search.setPreferredSize(new Dimension(300, 40));
            JPanel head = new JPanel(new BorderLayout());
            head.setOpaque(false);
            head.add(tl, BorderLayout.WEST);
            head.add(search, BorderLayout.EAST);

            toolbar.setOpaque(false);
            JPanel north = new JPanel(new BorderLayout(0, 12));
            north.setOpaque(false);
            north.add(head, BorderLayout.NORTH);
            north.add(toolbar, BorderLayout.CENTER);
            add(north, BorderLayout.NORTH);

            model = new DefaultTableModel(cols, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
            table = new JTable(model);
            Theme.styleTable(table);
            tableScroll = Theme.scroll(table);
            add(tableScroll, BorderLayout.CENTER);

            search.getDocument().addDocumentListener(new DocumentListener() {
                public void insertUpdate(DocumentEvent e)  { reload(false); }
                public void removeUpdate(DocumentEvent e)  { reload(false); }
                public void changedUpdate(DocumentEvent e) { reload(false); }
            });
        }

        void add(JButton b) { toolbar.add(b); }
        abstract void reload(boolean showError);

        void dbError(SQLException e) { Theme.error(ServerApp.this, "Lỗi CSDL: " + e.getMessage()); }
    }

    // ============================================================ NGƯỜI DÙNG
    private class UsersPanel extends CrudPanel {
        UsersPanel() {
            super("Quản lý người dùng", "Thêm, sửa, xóa, khóa tài khoản và tìm kiếm",
                    new String[]{"ID", "Tên đăng nhập", "Họ tên", "Email", "Điện thoại", "Trực tuyến", "Trạng thái", "Avatar", "Ngày tạo"});
            Theme.RoundButton add = Theme.successButton("+ Thêm");
            Theme.RoundButton edit = Theme.primaryButton("Sửa");
            Theme.RoundButton del = Theme.dangerButton("Xóa");
            Theme.RoundButton lock = Theme.lightButton("Khóa / Mở khóa");
            Theme.RoundButton reset = Theme.lightButton("Đặt lại mật khẩu");
            Theme.RoundButton resetAv = Theme.lightButton("Reset avatar");
            Theme.RoundButton refresh = Theme.lightButton("Làm mới");
            add(add); add(edit); add(del); add(lock); add(reset); add(resetAv); add(refresh);
            resetAv.addActionListener(e -> resetAvatar());
            add.addActionListener(e -> addUser());
            edit.addActionListener(e -> editUser());
            del.addActionListener(e -> deleteUser());
            lock.addActionListener(e -> toggleLock());
            reset.addActionListener(e -> resetPass());
            refresh.addActionListener(e -> reload(true));
            table.getColumnModel().getColumn(0).setMaxWidth(60);
        }

        @Override
        void reload(boolean showError) {
            if (!ensureDb(showError)) return;
            long keep = idOf(table);
            try {
                List<Object[]> rows = Dao.listUsers(search.getText().trim());
                model.setRowCount(0);
                for (Object[] r : rows) {
                    String uname = Dao.str(r[1]);
                    model.addRow(new Object[]{r[0], uname, r[2], r[3], r[4],
                            server.isOnline(uname) ? "Online" : "Offline",
                            Dao.bool(r[5]) ? "Hoạt động" : "Bị khóa",
                            Dao.bool(r[7]) ? "Tùy chỉnh" : "Mặc định", r[6]});
                }
                for (int i = 0; i < table.getRowCount(); i++)
                    if (Long.parseLong(table.getValueAt(i, 0).toString()) == keep) table.setRowSelectionInterval(i, i);
            } catch (SQLException e) {
                if (showError) dbError(e);
            }
        }

        private boolean needSelection() {
            if (table.getSelectedRow() < 0) {
                Theme.info(ServerApp.this, "Hãy chọn một người dùng trong bảng.");
                return false;
            }
            return true;
        }

        void addUser() {
            if (!ensureDb(true)) return;
            String[] v = Theme.form(ServerApp.this, "Thêm người dùng",
                    new String[]{"Tên đăng nhập", "Mật khẩu", "Họ tên", "Email", "Số điện thoại"}, null,
                    new boolean[]{false, true, false, false, false});
            if (v == null) return;
            String err = Dao.register(v[0], v[1], v[2], v[3], v[4]);
            if (err != null) Theme.error(ServerApp.this, err);
            else reload(true);
        }

        void editUser() {
            if (!needSelection()) return;
            long id = idOf(table);
            String oldName = cell(table, 1);
            String[] v = Theme.form(ServerApp.this, "Sửa thông tin: " + oldName,
                    new String[]{"Tên đăng nhập", "Họ tên", "Email", "Số điện thoại"},
                    new String[]{oldName, cell(table, 2), cell(table, 3), cell(table, 4)}, null);
            if (v == null) return;
            String err = Dao.updateUser(id, v[0], v[1], v[2], v[3]);
            if (err != null) {
                Theme.error(ServerApp.this, err);
                return;
            }
            if (!v[0].equals(oldName)) {
                afterRename(id, oldName, v[0]);
                Theme.info(ServerApp.this, "Đã đổi tên đăng nhập \"" + oldName + "\" thành \"" + v[0] + "\".\n"
                        + "Nếu người dùng đang online, họ sẽ bị ngắt kết nối và cần đăng nhập lại bằng tên mới.");
            }
            reload(true);
        }

        /** Đổi tên xong: ngắt phiên cũ và cập nhật tên hiển thị cho những người liên quan đang online. */
        private void afterRename(long id, String oldName, String newName) {
            server.kick(oldName, "Tên đăng nhập của bạn đã được đổi thành \"" + newName + "\". Hãy đăng nhập lại bằng tên mới.");
            server.clearAvatarFor(oldName);
            server.pushAvatar(newName);
            try {
                for (String[] r : Dao.roomsOfUser(id)) server.pushRoom(Long.parseLong(r[0]));
                java.util.Set<String> names = new java.util.TreeSet<>();
                for (Object[] r : Dao.friendsOf(id)) names.add(Dao.str(r[0]));
                for (Object[] r : Dao.incomingRequests(id)) names.add(Dao.str(r[1]));
                for (Object[] r : Dao.outgoingRequests(id)) names.add(Dao.str(r[1]));
                for (String n : names) server.pushFriends(n);
            } catch (SQLException e) {
                dbError(e);
            }
        }

        void deleteUser() {
            if (!needSelection()) return;
            long id = idOf(table);
            String name = cell(table, 1);
            if (!Theme.confirm(ServerApp.this, "Xóa người dùng \"" + name + "\"?")) return;
            int r = Dao.deleteUser(id);
            if (r == 1) {
                server.kick(name, "Tài khoản của bạn đã bị xóa.");
                Theme.info(ServerApp.this, "Đã xóa người dùng.");
            } else if (r == 2) {
                server.kick(name, "Tài khoản của bạn đã bị khóa.");
                Theme.info(ServerApp.this, "Người dùng này đã có dữ liệu chat nên không thể xóa hẳn.\n"
                        + "Tài khoản được chuyển sang trạng thái BỊ KHÓA để giữ lịch sử tin nhắn.");
            } else {
                Theme.error(ServerApp.this, "Không xóa được người dùng.");
            }
            reload(true);
        }

        void toggleLock() {
            if (!needSelection()) return;
            long id = idOf(table);
            String name = cell(table, 1);
            boolean active = cell(table, 6).equals("Hoạt động");
            try {
                Dao.setActive(id, !active);
                if (active) server.kick(name, "Tài khoản của bạn đã bị khóa bởi quản trị viên.");
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }

        void resetAvatar() {
            if (!needSelection()) return;
            String name = cell(table, 1);
            if (cell(table, 7).equals("Mặc định")) {
                Theme.info(ServerApp.this, "\"" + name + "\" đang dùng ảnh mặc định.");
                return;
            }
            if (!Theme.confirm(ServerApp.this, "Đặt lại ảnh đại diện của \"" + name + "\" về mặc định?")) return;
            try {
                Dao.clearAvatar(idOf(table));
                server.pushAvatar(name);
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }

        void resetPass() {
            if (!needSelection()) return;
            String[] v = Theme.form(ServerApp.this, "Đặt lại mật khẩu: " + cell(table, 1),
                    new String[]{"Mật khẩu mới"}, null, new boolean[]{true});
            if (v == null) return;
            String err = Dao.resetPassword(idOf(table), v[0]);
            if (err != null) Theme.error(ServerApp.this, err);
            else Theme.info(ServerApp.this, "Đã đặt lại mật khẩu.");
        }
    }

    // ============================================================ PHÒNG CHAT
    private class RoomsPanel extends CrudPanel {
        final DefaultTableModel memberModel = new DefaultTableModel(
                new String[]{"ID", "Tên đăng nhập", "Vai trò", "Ngày tham gia"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        final JTable memberTable = new JTable(memberModel);

        RoomsPanel() {
            super("Quản lý phòng chat", "Tạo phòng, đổi tên, xóa phòng và quản lý thành viên",
                    new String[]{"ID", "Tên phòng", "Loại", "Chủ phòng", "Thành viên", "Mô tả", "Ngày tạo", "Avatar"});
            Theme.RoundButton add = Theme.successButton("+ Thêm phòng");
            Theme.RoundButton edit = Theme.primaryButton("Sửa");
            Theme.RoundButton del = Theme.dangerButton("Xóa");
            Theme.RoundButton refresh = Theme.lightButton("Làm mới");
            Theme.RoundButton resetAv = Theme.lightButton("Reset avatar nhóm");
            add(add); add(edit); add(del); add(resetAv); add(refresh);
            resetAv.addActionListener(e -> resetRoomAvatar());
            add.addActionListener(e -> addRoom());
            edit.addActionListener(e -> editRoom());
            del.addActionListener(e -> deleteRoom());
            refresh.addActionListener(e -> reload(true));
            table.getColumnModel().getColumn(0).setMaxWidth(60);

            Theme.styleTable(memberTable);
            Theme.RoundButton addM = Theme.successButton("+ Thêm thành viên");
            Theme.RoundButton delM = Theme.dangerButton("Xóa khỏi phòng");
            JLabel ml = new JLabel("Thành viên của phòng đang chọn");
            ml.setFont(Theme.H2);
            JPanel mt = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            mt.setOpaque(false);
            mt.add(ml);
            mt.add(addM);
            mt.add(delM);
            JPanel mp = new JPanel(new BorderLayout(0, 8));
            mp.setOpaque(false);
            mp.setBorder(new EmptyBorder(10, 0, 0, 0));
            mp.add(mt, BorderLayout.NORTH);
            mp.add(Theme.scroll(memberTable), BorderLayout.CENTER);

            remove(tableScroll);
            JSplitPane sp = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tableScroll, mp);
            sp.setResizeWeight(0.55);
            sp.setBorder(null);
            sp.setOpaque(false);
            add(sp, BorderLayout.CENTER);

            table.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting()) loadMembers();
            });
            addM.addActionListener(e -> addMember());
            delM.addActionListener(e -> removeMember());
        }

        @Override
        void reload(boolean showError) {
            if (!ensureDb(showError)) return;
            long keep = idOf(table);
            try {
                List<Object[]> rows = Dao.adminRooms(search.getText().trim());
                model.setRowCount(0);
                for (Object[] r : rows) {
                    r[7] = Dao.bool(r[7]) ? "Tùy chỉnh" : "Mặc định";
                    model.addRow(r);
                }
                for (int i = 0; i < table.getRowCount(); i++)
                    if (Long.parseLong(table.getValueAt(i, 0).toString()) == keep) table.setRowSelectionInterval(i, i);
            } catch (SQLException e) {
                if (showError) dbError(e);
            }
            loadMembers();
        }

        void loadMembers() {
            memberModel.setRowCount(0);
            long id = idOf(table);
            if (id < 0) return;
            try {
                for (Object[] r : Dao.memberRows(id)) memberModel.addRow(r);
            } catch (SQLException ignored) { }
        }

        private boolean needSelection() {
            if (table.getSelectedRow() < 0) {
                Theme.info(ServerApp.this, "Hãy chọn một phòng trong bảng.");
                return false;
            }
            return true;
        }

        void addRoom() {
            if (!ensureDb(true)) return;
            String[] v = Theme.form(ServerApp.this, "Thêm phòng chat",
                    new String[]{"Tên phòng", "Mô tả", "Loại (public / private)", "Chủ phòng (username)"},
                    new String[]{"", "", "public", ""}, null);
            if (v == null) return;
            if (v[0].isEmpty() || v[0].length() > 100 || v[0].contains("|")) {
                Theme.error(ServerApp.this, "Tên phòng không hợp lệ.");
                return;
            }
            if (!v[2].equals("public") && !v[2].equals("private")) {
                Theme.error(ServerApp.this, "Loại phòng phải là public hoặc private.");
                return;
            }
            try {
                long owner = Dao.userId(v[3]);
                if (owner < 0) {
                    Theme.error(ServerApp.this, "Không tìm thấy chủ phòng \"" + v[3] + "\".");
                    return;
                }
                long id = Dao.createRoom(v[0], v[1], v[2], owner, new ArrayList<Long>());
                server.pushRoom(id);
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }

        void editRoom() {
            if (!needSelection()) return;
            if (cell(table, 2).equals("direct")) {
                Theme.info(ServerApp.this, "Chat riêng 1-1 không có tên để sửa.");
                return;
            }
            long id = idOf(table);
            String[] v = Theme.form(ServerApp.this, "Sửa phòng",
                    new String[]{"Tên phòng", "Mô tả"}, new String[]{cell(table, 1), cell(table, 5)}, null);
            if (v == null) return;
            if (v[0].isEmpty() || v[0].length() > 100 || v[0].contains("|")) {
                Theme.error(ServerApp.this, "Tên phòng không hợp lệ.");
                return;
            }
            try {
                Dao.updateRoom(id, v[0], v[1]);
                server.pushRoom(id);
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }

        void resetRoomAvatar() {
            if (!needSelection()) return;
            if (cell(table, 2).equals("direct")) {
                Theme.info(ServerApp.this, "Chat riêng không có ảnh nhóm.");
                return;
            }
            if (cell(table, 7).equals("Mặc định")) {
                Theme.info(ServerApp.this, "Phòng này đang dùng ảnh mặc định.");
                return;
            }
            long id = idOf(table);
            if (!Theme.confirm(ServerApp.this, "Đặt lại ảnh nhóm \"" + cell(table, 1) + "\" về mặc định?")) return;
            try {
                Dao.clearRoomAvatar(id);
                server.pushRoomAvatar(id);
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }

        void deleteRoom() {
            if (!needSelection()) return;
            long id = idOf(table);
            if (!Theme.confirm(ServerApp.this, "Xóa phòng \"" + cell(table, 1) + "\" cùng toàn bộ tin nhắn trong phòng?")) return;
            try {
                List<String> members = Dao.memberNames(id);
                Dao.deleteRoom(id);
                server.pushRoomRemoved(id, members);
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }

        void addMember() {
            if (!needSelection()) return;
            if (cell(table, 2).equals("direct")) {
                Theme.info(ServerApp.this, "Không thể thêm thành viên vào chat riêng.");
                return;
            }
            long room = idOf(table);
            String[] v = Theme.form(ServerApp.this, "Thêm thành viên", new String[]{"Tên đăng nhập"}, null, null);
            if (v == null) return;
            try {
                long uid = Dao.userId(v[0]);
                if (uid < 0) {
                    Theme.error(ServerApp.this, "Không tìm thấy người dùng \"" + v[0] + "\".");
                    return;
                }
                Dao.addMember(room, uid);
                server.pushRoom(room);
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }

        void removeMember() {
            if (!needSelection()) return;
            int r = memberTable.getSelectedRow();
            if (r < 0) {
                Theme.info(ServerApp.this, "Hãy chọn một thành viên trong bảng bên dưới.");
                return;
            }
            long room = idOf(table);
            long uid = Long.parseLong(memberTable.getValueAt(r, 0).toString());
            String name = String.valueOf(memberTable.getValueAt(r, 1));
            if (!Theme.confirm(ServerApp.this, "Xóa \"" + name + "\" khỏi phòng?")) return;
            try {
                Dao.removeMember(room, uid);
                server.sendToUser(name, "LEFT|" + room);
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }
    }

    // ============================================================ TIN NHẮN
    private class MessagesPanel extends CrudPanel {
        MessagesPanel() {
            super("Quản lý tin nhắn", "Tìm kiếm theo nội dung hoặc người gửi, xóa tin nhắn vi phạm",
                    new String[]{"ID", "Phòng", "Người gửi", "Thời gian", "Nội dung", "Trạng thái"});
            Theme.RoundButton del = Theme.dangerButton("Xóa tin nhắn");
            Theme.RoundButton refresh = Theme.lightButton("Làm mới");
            add(del); add(refresh);
            del.addActionListener(e -> deleteMessage());
            refresh.addActionListener(e -> reload(true));
            table.getColumnModel().getColumn(0).setMaxWidth(70);
            table.getColumnModel().getColumn(4).setPreferredWidth(480);
        }

        @Override
        void reload(boolean showError) {
            if (!ensureDb(showError)) return;
            try {
                List<Object[]> rows = Dao.adminMessages(search.getText().trim());
                model.setRowCount(0);
                for (Object[] r : rows) model.addRow(r);
            } catch (SQLException e) {
                if (showError) dbError(e);
            }
        }

        void deleteMessage() {
            if (table.getSelectedRow() < 0) {
                Theme.info(ServerApp.this, "Hãy chọn một tin nhắn trong bảng.");
                return;
            }
            long id = idOf(table);
            if (!Theme.confirm(ServerApp.this, "Xóa vĩnh viễn tin nhắn #" + id + "?")) return;
            try {
                long room = Dao.roomOfMessage(id);
                Dao.adminDeleteMessage(id);
                server.pushMessageDeleted(id, room);
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }
    }

    // ============================================================ BẠN BÈ
    private class FriendsPanel extends CrudPanel {
        FriendsPanel() {
            super("Quản lý quan hệ bạn bè", "Xem, thêm, đổi trạng thái và xóa quan hệ kết bạn giữa các người dùng",
                    new String[]{"ID", "Người gửi lời mời", "Người nhận", "Trạng thái", "Ngày gửi", "Ngày phản hồi"});
            Theme.RoundButton add = Theme.successButton("+ Thêm quan hệ");
            Theme.RoundButton edit = Theme.primaryButton("Đổi trạng thái");
            Theme.RoundButton del = Theme.dangerButton("Xóa");
            Theme.RoundButton refresh = Theme.lightButton("Làm mới");
            add(add); add(edit); add(del); add(refresh);
            add.addActionListener(e -> addFriendship());
            edit.addActionListener(e -> changeStatus());
            del.addActionListener(e -> deleteFriendship());
            refresh.addActionListener(e -> reload(true));
            table.getColumnModel().getColumn(0).setMaxWidth(60);
        }

        @Override
        void reload(boolean showError) {
            if (!ensureDb(showError)) return;
            try {
                List<Object[]> rows = Dao.adminFriendships(search.getText().trim());
                model.setRowCount(0);
                for (Object[] r : rows) model.addRow(r);
            } catch (SQLException e) {
                if (showError) dbError(e);
            }
        }

        private boolean needSelection() {
            if (table.getSelectedRow() < 0) {
                Theme.info(ServerApp.this, "Hãy chọn một quan hệ trong bảng.");
                return false;
            }
            return true;
        }

        private void pushBoth(String a, String b) {
            server.pushFriends(a);
            server.pushFriends(b);
        }

        void addFriendship() {
            if (!ensureDb(true)) return;
            String[] v = Theme.form(ServerApp.this, "Thêm quan hệ bạn bè",
                    new String[]{"Người dùng 1 (username)", "Người dùng 2 (username)", "Trạng thái (pending / accepted / blocked)"},
                    new String[]{"", "", "accepted"}, null);
            if (v == null) return;
            try {
                String err = Dao.adminAddFriendship(v[0], v[1], v[2]);
                if (err != null) {
                    Theme.error(ServerApp.this, err);
                    return;
                }
                pushBoth(v[0], v[1]);
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }

        void changeStatus() {
            if (!needSelection()) return;
            long id = idOf(table);
            String a = cell(table, 1), b = cell(table, 2);
            String[] v = Theme.form(ServerApp.this, "Đổi trạng thái: " + a + " - " + b,
                    new String[]{"Trạng thái (pending / accepted / blocked)"}, new String[]{cell(table, 3)}, null);
            if (v == null) return;
            if (!v[0].equals("pending") && !v[0].equals("accepted") && !v[0].equals("blocked")) {
                Theme.error(ServerApp.this, "Trạng thái phải là pending, accepted hoặc blocked.");
                return;
            }
            try {
                Dao.setFriendStatus(id, v[0]);
                pushBoth(a, b);
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }

        void deleteFriendship() {
            if (!needSelection()) return;
            long id = idOf(table);
            String a = cell(table, 1), b = cell(table, 2);
            if (!Theme.confirm(ServerApp.this, "Xóa quan hệ giữa \"" + a + "\" và \"" + b + "\"?")) return;
            try {
                Dao.deleteFriendship(id);
                pushBoth(a, b);
                reload(true);
            } catch (SQLException e) {
                dbError(e);
            }
        }
    }

    public static void main(String[] args) {
        Theme.init();
        SwingUtilities.invokeLater(() -> new ServerApp().setVisible(true));
    }
}
