import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.util.Map;
import javax.imageio.ImageIO;
import java.util.concurrent.ConcurrentHashMap;
import javax.swing.*;
import java.util.prefs.Preferences;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.metal.DefaultMetalTheme;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.text.JTextComponent;

/** Theme - màu sắc, font và các thành phần giao diện dùng chung cho cả Host lẫn Client. */
public class Theme {

    // ---- màu cố định (giống nhau ở cả hai giao diện)
    public static final Color PRIMARY      = new Color(0x2F80ED);
    public static final Color PRIMARY_DARK = new Color(0x1C63C4);
    public static final Color SIDEBAR_SEL  = new Color(0x2F80ED);
    public static final Color DANGER       = new Color(0xE5484D);
    public static final Color SUCCESS      = new Color(0x16A34A);

    /** Bảng màu của một giao diện (sáng hoặc tối). */
    public static class Palette {
        final Color bg, surface, sidebar, text, muted, border, bubbleOther, select, neutral, headerBg, rowAlt, inputBg, disabled, thumb;

        Palette(int bg, int surface, int sidebar, int text, int muted, int border, int bubbleOther, int select,
                int neutral, int headerBg, int rowAlt, int inputBg, int disabled, int thumb) {
            this.bg = new Color(bg);
            this.surface = new Color(surface);
            this.sidebar = new Color(sidebar);
            this.text = new Color(text);
            this.muted = new Color(muted);
            this.border = new Color(border);
            this.bubbleOther = new Color(bubbleOther);
            this.select = new Color(select);
            this.neutral = new Color(neutral);
            this.headerBg = new Color(headerBg);
            this.rowAlt = new Color(rowAlt);
            this.inputBg = new Color(inputBg);
            this.disabled = new Color(disabled);
            this.thumb = new Color(thumb);
        }
    }

    public static final Palette LIGHT = new Palette(0xF4F6FA, 0xFFFFFF, 0x1F2937, 0x1F2937, 0x6B7280, 0xE5E7EB,
            0xE9ECF2, 0xDBEAFE, 0xE5E7EB, 0xF3F4F6, 0xF9FAFB, 0xFFFFFF, 0xD1D5DB, 0xC7CBD3);
    public static final Palette DARK = new Palette(0x12151C, 0x1B1F28, 0x0D1017, 0xE5E7EB, 0x9CA3AF, 0x2D3340,
            0x2B303B, 0x24354F, 0x2F3542, 0x232832, 0x1F232C, 0x252A35, 0x3A4150, 0x4A5163);

    // ---- màu theo giao diện hiện tại (đổi khi chuyển sáng / tối)
    public static boolean dark = false;
    public static Palette current = LIGHT;
    public static Color BG           = LIGHT.bg;
    public static Color SURFACE      = LIGHT.surface;
    public static Color SIDEBAR      = LIGHT.sidebar;
    public static Color TEXT         = LIGHT.text;
    public static Color MUTED        = LIGHT.muted;
    public static Color BORDER       = LIGHT.border;
    public static Color BUBBLE_OTHER = LIGHT.bubbleOther;
    public static Color SELECT       = LIGHT.select;
    public static Color NEUTRAL      = LIGHT.neutral;
    public static Color HEADER_BG    = LIGHT.headerBg;
    public static Color ROW_ALT      = LIGHT.rowAlt;
    public static Color INPUT_BG     = LIGHT.inputBg;
    public static Color DISABLED     = LIGHT.disabled;
    public static Color SCROLL_THUMB = LIGHT.thumb;

    public static final Font FONT  = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font BOLD  = FONT.deriveFont(Font.BOLD);
    public static final Font TITLE = FONT.deriveFont(Font.BOLD, 22f);
    public static final Font H2    = FONT.deriveFont(Font.BOLD, 16f);
    public static final Font SMALL = FONT.deriveFont(12f);

    private static final Color[] PALETTE = {
        new Color(0x2F80ED), new Color(0x9B51E0), new Color(0xEB5757), new Color(0xF2994A),
        new Color(0x27AE60), new Color(0x00A3BF), new Color(0xD6336C), new Color(0x5C6BC0)
    };

    private static boolean lafReady = false;

    /** Khởi tạo giao diện: nạp lựa chọn sáng / tối đã lưu lần trước. */
    public static void init() {
        System.setProperty("swing.boldMetal", "false");
        boolean d = false;
        try {
            d = Preferences.userRoot().node("ChatNowApp").getBoolean("dark", false);
        } catch (Exception ignored) { }
        applyPalette(d);
        installLookAndFeel();
        lafReady = true;
    }

    private static void applyPalette(boolean d) {
        dark = d;
        current = d ? DARK : LIGHT;
        BG = current.bg;
        SURFACE = current.surface;
        SIDEBAR = current.sidebar;
        TEXT = current.text;
        MUTED = current.muted;
        BORDER = current.border;
        BUBBLE_OTHER = current.bubbleOther;
        SELECT = current.select;
        NEUTRAL = current.neutral;
        HEADER_BG = current.headerBg;
        ROW_ALT = current.rowAlt;
        INPUT_BG = current.inputBg;
        DISABLED = current.disabled;
        SCROLL_THUMB = current.thumb;
    }

    private static void installLookAndFeel() {
        MetalLookAndFeel.setCurrentTheme(new ThemeColors(dark));
        try {
            UIManager.setLookAndFeel(new MetalLookAndFeel());
        } catch (Exception ignored) { }
        java.util.List<Object> keys = new java.util.ArrayList<>();
        java.util.Enumeration<Object> en = UIManager.getLookAndFeelDefaults().keys();
        while (en.hasMoreElements()) keys.add(en.nextElement());
        for (Object k : keys) {
            if (UIManager.getLookAndFeelDefaults().get(k) instanceof javax.swing.plaf.FontUIResource) {
                UIManager.put(k, new javax.swing.plaf.FontUIResource(FONT));
            }
        }
        UIManager.put("OptionPane.okButtonText", "Đồng ý");
        UIManager.put("OptionPane.cancelButtonText", "Hủy");
        UIManager.put("OptionPane.yesButtonText", "Có");
        UIManager.put("OptionPane.noButtonText", "Không");
        UIManager.put("ScrollBarUI", ModernScrollBarUI.class.getName());
    }

    /** Chuyển sang giao diện sáng / tối và làm mới tất cả cửa sổ đang mở. Lựa chọn được ghi nhớ cho lần sau. */
    public static void setDark(boolean d) {
        if (d == dark && lafReady) return;
        Palette old = current;
        applyPalette(d);
        installLookAndFeel();
        lafReady = true;
        try {
            Preferences.userRoot().node("ChatNowApp").putBoolean("dark", d);
        } catch (Exception ignored) { }
        for (Window w : Window.getWindows()) {
            SwingUtilities.updateComponentTreeUI(w);
            recolor(w, old);
            w.invalidate();
            w.validate();
            w.repaint();
        }
    }

    public static void toggleDark() {
        setDark(!dark);
    }

    // ------------------------------------------------------------------ Đổi màu các thành phần đã đặt màu thủ công
    private static Color mapBg(Color c, Palette p) {
        if (c.equals(p.bg)) return current.bg;
        if (c.equals(p.surface)) return current.surface;
        if (c.equals(p.sidebar)) return current.sidebar;
        return null;
    }

    private static Color mapFg(Color c, Palette p) {
        if (c.equals(p.text)) return current.text;
        if (c.equals(p.muted)) return current.muted;
        return null;
    }

    private static Border mapBorder(Border b, Palette p) {
        if (b instanceof MatteBorder) {
            MatteBorder m = (MatteBorder) b;
            if (p.border.equals(m.getMatteColor())) return new MatteBorder(m.getBorderInsets(), current.border);
            return b;
        }
        if (b instanceof LineBorder) {
            LineBorder l = (LineBorder) b;
            if (p.border.equals(l.getLineColor()))
                return new LineBorder(current.border, l.getThickness(), l.getRoundedCorners());
            return b;
        }
        if (b instanceof CompoundBorder) {
            CompoundBorder cb = (CompoundBorder) b;
            Border o = mapBorder(cb.getOutsideBorder(), p), i = mapBorder(cb.getInsideBorder(), p);
            if (o != cb.getOutsideBorder() || i != cb.getInsideBorder()) return new CompoundBorder(o, i);
        }
        return b;
    }

    /** Đổi các màu nền / chữ / viền đang dùng màu của bảng màu cũ sang màu của giao diện hiện tại. */
    public static void recolor(Component c, Palette from) {
        if (c.isBackgroundSet()) {
            Color m = mapBg(c.getBackground(), from);
            if (m != null) c.setBackground(m);
        }
        if (c.isForegroundSet()) {
            Color m = mapFg(c.getForeground(), from);
            if (m != null) {
                c.setForeground(m);
                if (c instanceof JTextComponent) ((JTextComponent) c).setCaretColor(m);
            }
        }
        if (c instanceof JComponent) {
            JComponent jc = (JComponent) c;
            Border b = jc.getBorder();
            Border nb = mapBorder(b, from);
            if (nb != b) jc.setBorder(nb);
        }
        if (c instanceof Container) {
            for (Component ch : ((Container) c).getComponents()) recolor(ch, from);
        }
    }

    /** Màu nền chuẩn của Swing (hộp thoại, tab, menu, ô chọn...) theo giao diện sáng / tối. */
    private static class ThemeColors extends DefaultMetalTheme {
        private final boolean dk;

        ThemeColors(boolean dk) { this.dk = dk; }

        private ColorUIResource c(int light, int dark) { return new ColorUIResource(dk ? dark : light); }

        @Override public String getName() { return dk ? "ChatNow Dark" : "ChatNow Light"; }
        @Override protected ColorUIResource getPrimary1()   { return c(0x2F80ED, 0x3B82F6); }
        @Override protected ColorUIResource getPrimary2()   { return c(0x93C5FD, 0x2B4A7A); }
        @Override protected ColorUIResource getPrimary3()   { return c(0xDBEAFE, 0x24354F); }
        @Override protected ColorUIResource getSecondary1() { return c(0x9CA3AF, 0x6B7280); }
        @Override protected ColorUIResource getSecondary2() { return c(0xD1D5DB, 0x4B5263); }
        @Override protected ColorUIResource getSecondary3() { return c(0xF4F6FA, 0x1B1F28); }
        @Override protected ColorUIResource getBlack()      { return c(0x1F2937, 0xE5E7EB); }
        @Override protected ColorUIResource getWhite()      { return c(0xFFFFFF, 0x1B1F28); }
    }

    /** Thanh cuộn mỏng, bo tròn, đổi màu theo giao diện. */
    public static class ModernScrollBarUI extends javax.swing.plaf.basic.BasicScrollBarUI {
        public static javax.swing.plaf.ComponentUI createUI(JComponent c) {
            return new ModernScrollBarUI();
        }

        private JButton zero() {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            b.setMinimumSize(new Dimension(0, 0));
            b.setMaximumSize(new Dimension(0, 0));
            return b;
        }

        @Override protected JButton createDecreaseButton(int orientation) { return zero(); }
        @Override protected JButton createIncreaseButton(int orientation) { return zero(); }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
            g.setColor(c.getBackground());
            g.fillRect(r.x, r.y, r.width, r.height);
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            if (r.isEmpty() || !scrollbar.isEnabled()) return;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(isThumbRollover() ? SCROLL_THUMB.darker() : SCROLL_THUMB);
            g2.fillRoundRect(r.x + 2, r.y + 2, r.width - 4, r.height - 4, 10, 10);
            g2.dispose();
        }

        @Override
        public Dimension getPreferredSize(JComponent c) {
            return new Dimension(12, 12);
        }
    }

    public static Color avatarColor(String name) {
        return PALETTE[Math.abs(name.hashCode()) % PALETTE.length];
    }

    // ------------------------------------------------------------------ Avatar
    /** Ảnh đại diện tùy chỉnh, khóa theo username (do server gửi xuống). Không có = dùng chữ cái đầu. */
    public static final Map<String, BufferedImage> AVATARS = new ConcurrentHashMap<>();

    static void paintCircleImage(Graphics2D g2, BufferedImage img, int x, int y, int size) {
        BufferedImage buf = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D b = buf.createGraphics();
        b.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        b.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        b.fill(new Ellipse2D.Float(0, 0, size, size));
        b.setComposite(AlphaComposite.SrcIn);
        b.drawImage(img, 0, 0, size, size, null);
        b.dispose();
        g2.drawImage(buf, x, y, null);
    }

    public static class AvatarIcon implements Icon {
        private final int size;
        private final String key;
        private final String letter;
        private final Color color;
        private final boolean useCache;

        AvatarIcon(String key, String label, String colorKey, int size, boolean useCache) {
            this.size = size;
            this.key = key == null ? "?" : key;
            String l = label == null || label.isEmpty() ? this.key : label;
            this.letter = l.substring(0, 1).toUpperCase();
            this.color = avatarColor(colorKey == null || colorKey.isEmpty() ? this.key : colorKey);
            this.useCache = useCache;
        }

        @Override public int getIconWidth()  { return size; }
        @Override public int getIconHeight() { return size; }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            BufferedImage img = useCache ? AVATARS.get(key) : null;
            if (img != null) {
                paintCircleImage(g2, img, x, y, size);
            } else {
                g2.setColor(color);
                g2.fillOval(x, y, size, size);
                g2.setColor(Color.WHITE);
                g2.setFont(BOLD.deriveFont(size * 0.42f));
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(letter, x + (size - fm.stringWidth(letter)) / 2,
                        y + (size - fm.getHeight()) / 2 + fm.getAscent());
            }
            g2.dispose();
        }
    }

    /** Ảnh đại diện của người dùng (ảnh tùy chỉnh nếu có, ngược lại là chữ cái đầu). */
    public static Icon avatar(String username, int size) {
        return new AvatarIcon(username, username, username, size, true);
    }

    public static Icon avatar(String username, String label, int size) {
        return new AvatarIcon(username, label, username, size, true);
    }

    /** Ảnh chữ cái đầu, không tra ảnh tùy chỉnh (dùng cho nhóm chat). */
    public static Icon initialAvatar(String name, int size) {
        return new AvatarIcon(name, name, name, size, false);
    }

    /** Ảnh nhóm chat: ảnh tùy chỉnh theo id phòng (khóa "#id") hoặc chữ cái đầu của tên nhóm. */
    public static Icon roomAvatar(long roomId, String name, int size) {
        return new AvatarIcon("#" + roomId, name, name, size, true);
    }

    /** Icon tròn từ một ảnh bất kỳ (dùng cho xem trước). */
    public static Icon imageIcon(final BufferedImage img, final int size) {
        return new Icon() {
            @Override public int getIconWidth()  { return size; }
            @Override public int getIconHeight() { return size; }
            @Override
            public void paintIcon(Component c, Graphics g, int x, int y) {
                Graphics2D g2 = (Graphics2D) g.create();
                paintCircleImage(g2, img, x, y, size);
                g2.dispose();
            }
        };
    }

    // ------------------------------------------------------------------ Hình ảnh của ứng dụng
    private static BufferedImage appIconImg;

    private static BufferedImage drawDefaultIcon(int s) {
        BufferedImage img = new BufferedImage(s, s, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setPaint(new GradientPaint(0, 0, PRIMARY, s, s, new Color(0x9B51E0)));
        g.fillRoundRect(0, 0, s, s, s / 4, s / 4);
        g.setColor(Color.WHITE);
        int bw = s * 62 / 100, bh = s * 44 / 100, bx = (s - bw) / 2, by = s * 24 / 100;
        g.fillRoundRect(bx, by, bw, bh, bh / 2, bh / 2);
        int[] px = {bx + bw / 5, bx + bw * 2 / 5, bx + bw / 8};
        int[] py = {by + bh - 2, by + bh - 2, by + bh + s * 14 / 100};
        g.fillPolygon(px, py, 3);
        g.setColor(PRIMARY);
        int d = Math.max(2, s / 11);
        for (int i = 0; i < 3; i++) g.fillOval(bx + bw / 4 + i * (bw / 4) - d / 2, by + bh / 2 - d / 2, d, d);
        g.dispose();
        return img;
    }

    /**
     * Biểu tượng của ứng dụng (icon cửa sổ, thanh tác vụ, logo).
     * Nếu có file logo.png (đặt trong thư mục src của project hoặc cạnh chương trình) thì dùng file đó,
     * ngược lại dùng biểu tượng bong bóng chat được vẽ sẵn.
     */
    public static synchronized BufferedImage appIcon() {
        if (appIconImg == null) {
            BufferedImage custom = null;
            try {
                // ưu tiên file logo.png nằm cạnh chương trình (thư mục chạy), sau đó mới tới logo.png trong .jar / src
                java.io.File f = new java.io.File("logo.png");
                if (f.isFile()) {
                    custom = ImageIO.read(f);
                } else {
                    java.io.InputStream in = Theme.class.getResourceAsStream("/logo.png");
                    if (in != null) {
                        custom = ImageIO.read(in);
                        in.close();
                    }
                }
            } catch (Exception ignored) { }
            appIconImg = custom != null ? custom : drawDefaultIcon(256);
        }
        return appIconImg;
    }

    /** Logo của ứng dụng thu nhỏ về khung size x size (giữ tỉ lệ). */
    public static Icon logoIcon(int size) {
        BufferedImage src = appIcon();
        double k = Math.min((double) size / src.getWidth(), (double) size / src.getHeight());
        int w = Math.max(1, (int) Math.round(src.getWidth() * k)), h = Math.max(1, (int) Math.round(src.getHeight() * k));
        BufferedImage out = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawImage(src, (size - w) / 2, (size - h) / 2, w, h, null);
        g.dispose();
        return new ImageIcon(out);
    }

    // ------------------------------------------------------------------ Panels
    public static class RoundedPanel extends JPanel {
        private final int arc;
        private Color bg;
        private boolean border;

        public RoundedPanel(int arc, Color bg, boolean border) {
            this.arc = arc;
            this.bg = bg;
            this.border = border;
            setOpaque(false);
        }

        public void setBg(Color c) { bg = c; repaint(); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(bg != null ? bg : SURFACE);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
            if (border) {
                g2.setColor(BORDER);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static JPanel card() {
        RoundedPanel p = new RoundedPanel(16, null, true);
        p.setBorder(new EmptyBorder(14, 16, 14, 16));
        return p;
    }

    // ------------------------------------------------------------------ Button
    public static class RoundButton extends JButton {
        private final Color base;
        private boolean over;

        public RoundButton(String text, Color bg, Color fg) {
            super(text);
            this.base = bg;
            setForeground(fg);
            setFont(BOLD);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setBorder(new EmptyBorder(8, 16, 8, 16));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { over = true; repaint(); }
                @Override public void mouseExited(MouseEvent e)  { over = false; repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color b0 = base != null ? base : NEUTRAL;
            Color hover = (base == null && dark) ? b0.brighter() : b0.darker();
            Color c = !isEnabled() ? DISABLED : (over ? hover : b0);
            g2.setColor(c);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static RoundButton primaryButton(String text) { return new RoundButton(text, PRIMARY, Color.WHITE); }
    public static RoundButton dangerButton(String text)  { return new RoundButton(text, DANGER, Color.WHITE); }
    public static RoundButton lightButton(String text)   { return new RoundButton(text, null, TEXT); }
    public static RoundButton successButton(String text) { return new RoundButton(text, SUCCESS, Color.WHITE); }

    // ------------------------------------------------------------------ Text fields
    private static void paintField(Graphics g, JTextComponent c, String hint) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(c.isEnabled() ? INPUT_BG : HEADER_BG);
        g2.fillRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 14, 14);
        g2.setColor(c.hasFocus() ? PRIMARY : BORDER);
        g2.drawRoundRect(0, 0, c.getWidth() - 1, c.getHeight() - 1, 14, 14);
        g2.dispose();
    }

    private static void paintHint(Graphics g, JTextComponent c, String hint) {
        if (hint != null && c.getDocument().getLength() == 0) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(new Color(0x9CA3AF));
            g2.setFont(c.getFont());
            Insets in = c.getInsets();
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(hint, in.left, (c.getHeight() - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }
    }

    public static class RoundField extends JTextField {
        private String hint;

        public RoundField(String hint, int columns) {
            super(columns);
            this.hint = hint;
            setOpaque(false);
            setFont(FONT);
            setForeground(TEXT);
            setCaretColor(TEXT);
            setBorder(new EmptyBorder(8, 12, 8, 12));
            addFocusListener(new java.awt.event.FocusAdapter() {
                @Override public void focusGained(java.awt.event.FocusEvent e) { repaint(); }
                @Override public void focusLost(java.awt.event.FocusEvent e)   { repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            paintField(g, this, hint);
            super.paintComponent(g);
            paintHint(g, this, hint);
        }
    }

    public static class RoundPassword extends JPasswordField {
        private String hint;

        public RoundPassword(String hint, int columns) {
            super(columns);
            this.hint = hint;
            setOpaque(false);
            setFont(FONT);
            setForeground(TEXT);
            setCaretColor(TEXT);
            setBorder(new EmptyBorder(8, 12, 8, 12));
            addFocusListener(new java.awt.event.FocusAdapter() {
                @Override public void focusGained(java.awt.event.FocusEvent e) { repaint(); }
                @Override public void focusLost(java.awt.event.FocusEvent e)   { repaint(); }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            paintField(g, this, hint);
            super.paintComponent(g);
            paintHint(g, this, hint);
        }
    }

    // ------------------------------------------------------------------ Table
    public static void styleTable(JTable t) {
        t.setRowHeight(32);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setFont(FONT);
        t.setForeground(TEXT);
        t.setBackground(SURFACE);
        t.setSelectionBackground(SELECT);
        t.setSelectionForeground(TEXT);
        t.setFillsViewportHeight(true);
        t.setAutoCreateRowSorter(true);
        DefaultTableCellRenderer cell = new DefaultTableCellRenderer();
        cell.setBorder(new EmptyBorder(0, 10, 0, 10));
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tb, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tb, v, sel, false, r, c);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                setBackground(sel ? SELECT : (r % 2 == 0 ? SURFACE : ROW_ALT));
                setForeground(TEXT);
                return this;
            }
        });
        JTableHeader h = t.getTableHeader();
        h.setReorderingAllowed(false);
        h.setPreferredSize(new Dimension(0, 36));
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tb, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tb, v, false, false, r, c);
                setBackground(HEADER_BG);
                setForeground(TEXT);
                setFont(BOLD);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                return this;
            }
        });
    }

    public static JScrollPane scroll(Component c) {
        JScrollPane sp = new JScrollPane(c);
        sp.setBorder(BorderFactory.createLineBorder(BORDER));
        sp.getViewport().setBackground(SURFACE);
        return sp;
    }

    // ------------------------------------------------------------------ Dialog helpers
    public static void info(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Thông báo", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void error(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Lỗi", JOptionPane.ERROR_MESSAGE);
    }

    public static boolean confirm(Component parent, String msg) {
        return JOptionPane.showConfirmDialog(parent, msg, "Xác nhận", JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION;
    }

    /** Hộp thoại nhập liệu nhiều trường. Trả về null nếu bấm Hủy. */
    public static String[] form(Component parent, String title, String[] labels, String[] init, boolean[] password) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(new EmptyBorder(6, 6, 6, 6));
        JTextComponent[] fields = new JTextComponent[labels.length];
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4, 4, 4, 4);
        gc.fill = GridBagConstraints.HORIZONTAL;
        for (int i = 0; i < labels.length; i++) {
            gc.gridx = 0; gc.gridy = i; gc.weightx = 0;
            JLabel l = new JLabel(labels[i]);
            l.setFont(BOLD);
            p.add(l, gc);
            gc.gridx = 1; gc.weightx = 1;
            boolean pw = password != null && password[i];
            fields[i] = pw ? new RoundPassword(null, 22) : new RoundField(null, 22);
            if (init != null && init[i] != null) fields[i].setText(init[i]);
            p.add(fields[i], gc);
        }
        int r = JOptionPane.showConfirmDialog(parent, p, title, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return null;
        String[] out = new String[labels.length];
        for (int i = 0; i < out.length; i++) out[i] = fields[i].getText().trim();
        return out;
    }
}
